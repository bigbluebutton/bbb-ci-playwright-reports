require.define({"ep_etherpad-lite/static/js/ace2_inner.js": {"(module ep_etherpad-lite/static/js/ace2_inner.js)": function (require, exports, module) {'use strict';

/**
 * Copyright 2009 Google Inc.
 * Copyright 2020 John McLear - The Etherpad Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let documentAttributeManager;

const AttributeMap = require('./AttributeMap');
const browser = require('./vendors/browser');
const padutils = require('./pad_utils').padutils;
const Ace2Common = require('./ace2_common');
const $ = require('./rjquery').$;

const isNodeText = Ace2Common.isNodeText;
const getAssoc = Ace2Common.getAssoc;
const setAssoc = Ace2Common.setAssoc;
const noop = Ace2Common.noop;
const hooks = require('./pluginfw/hooks');

function Ace2Inner(editorInfo, cssManagers) {
  const makeChangesetTracker = require('./changesettracker').makeChangesetTracker;
  const colorutils = require('./colorutils').colorutils;
  const makeContentCollector = require('./contentcollector').makeContentCollector;
  const domline = require('./domline').domline;
  const AttribPool = require('./AttributePool');
  const Changeset = require('./Changeset');
  const ChangesetUtils = require('./ChangesetUtils');
  const linestylefilter = require('./linestylefilter').linestylefilter;
  const SkipList = require('./skiplist');
  const undoModule = require('./undomodule').undoModule;
  const AttributeManager = require('./AttributeManager');
  const Scroll = require('./scroll');
  const DEBUG = false;

  const THE_TAB = '    '; // 4
  const MAX_LIST_LEVEL = 16;

  const FORMATTING_STYLES = ['bold', 'italic', 'underline', 'strikethrough'];
  const SELECT_BUTTON_CLASS = 'selected';

  let thisAuthor = '';

  let disposed = false;

  const focus = () => {
    window.focus();
  };

  const outerWin = window.parent;
  const outerDoc = outerWin.document;
  const sideDiv = outerDoc.getElementById('sidediv');
  const lineMetricsDiv = outerDoc.getElementById('linemetricsdiv');
  const sideDivInner = outerDoc.getElementById('sidedivinner');
  const appendNewSideDivLine = () => {
    const lineDiv = outerDoc.createElement('div');
    sideDivInner.appendChild(lineDiv);
    const lineSpan = outerDoc.createElement('span');
    lineSpan.classList.add('line-number');
    lineSpan.appendChild(outerDoc.createTextNode(sideDivInner.children.length));
    lineDiv.appendChild(lineSpan);
  };
  appendNewSideDivLine();

  const scroll = Scroll.init(outerWin);

  let outsideKeyDown = noop;
  let outsideKeyPress = (e) => true;
  let outsideNotifyDirty = noop;

  /**
   * Document representation.
   */
  const rep = {
    /**
     * The contents of the document. Each entry in this skip list is an object representing a
     * line (actually paragraph) of text. The line objects are created by createDomLineEntry().
     */
    lines: new SkipList(),
    /**
     * Start of the selection. Represented as an array of two non-negative numbers that point to the
     * first character of the selection: [zeroBasedLineNumber, zeroBasedColumnNumber]. Notes:
     *   - There is an implicit newline character (not actually stored) at the end of every line.
     *     Because of this, a selection that starts at the end of a line (column number equals the
     *     number of characters in the line, not including the implicit newline) is not equivalent
     *     to a selection that starts at the beginning of the next line. The same goes for the
     *     selection end.
     *   - If there are N lines, [N, 0] is valid for the start of the selection. [N, 0] indicates
     *     that the selection starts just after the implicit newline at the end of the document's
     *     last line (if the document has any lines). The same goes for the end of the selection.
     *   - If a line starts with a line marker, a selection that starts at the beginning of the line
     *     may start either immediately before (column = 0) or immediately after (column = 1) the
     *     line marker, and the two are considered to be semantically equivalent. For safety, all
     *     code should be written to accept either but only produce selections that start after the
     *     line marker (the column number should be 1, not 0, when there is a line marker). The same
     *     goes for the end of the selection.
     */
    selStart: null,
    /**
     * End of the selection. Represented as an array of two non-negative numbers that point to the
     * character just after the end of the selection: [zeroBasedLineNumber, zeroBasedColumnNumber].
     * See the above notes for selStart.
     */
    selEnd: null,
    /**
     * Whether the selection extends "backwards", so that the focus point (controlled with the arrow
     * keys) is at the beginning. This is not supported in IE, though native IE selections have that
     * behavior (which we try not to interfere with). Must be false if selection is collapsed!
     */
    selFocusAtStart: false,
    alltext: '',
    alines: [],
    apool: new AttribPool(),
  };

  // lines, alltext, alines, and DOM are set up in init()
  if (undoModule.enabled) {
    undoModule.apool = rep.apool;
  }

  let isEditable = true;
  let doesWrap = true;
  let hasLineNumbers = true;
  let isStyled = true;

  let console = (DEBUG && window.console);

  if (!window.console) {
    const names = [
      'log',
      'debug',
      'info',
      'warn',
      'error',
      'assert',
      'dir',
      'dirxml',
      'group',
      'groupEnd',
      'time',
      'timeEnd',
      'count',
      'trace',
      'profile',
      'profileEnd',
    ];
    console = {};
    for (const name of names) console[name] = noop;
  }

  const scheduler = parent; // hack for opera required

  const performDocumentReplaceRange = (start, end, newText) => {
    if (start === undefined) start = rep.selStart;
    if (end === undefined) end = rep.selEnd;

    // start[0]: <--- start[1] --->CCCCCCCCCCC\n
    //           CCCCCCCCCCCCCCCCCCCC\n
    //           CCCC\n
    // end[0]:   <CCC end[1] CCC>-------\n
    const builder = Changeset.builder(rep.lines.totalWidth());
    ChangesetUtils.buildKeepToStartOfRange(rep, builder, start);
    ChangesetUtils.buildRemoveRange(rep, builder, start, end);
    builder.insert(newText, [
      ['author', thisAuthor],
    ], rep.apool);
    const cs = builder.toString();

    performDocumentApplyChangeset(cs);
  };

  const changesetTracker = makeChangesetTracker(scheduler, rep.apool, {
    withCallbacks: (operationName, f) => {
      inCallStackIfNecessary(operationName, () => {
        fastIncorp(1);
        f(
            {
              setDocumentAttributedText: (atext) => {
                setDocAText(atext);
              },
              applyChangesetToDocument: (changeset, preferInsertionAfterCaret) => {
                const oldEventType = currentCallStack.editEvent.eventType;
                currentCallStack.startNewEvent('nonundoable');

                performDocumentApplyChangeset(changeset, preferInsertionAfterCaret);

                currentCallStack.startNewEvent(oldEventType);
              },
            });
      });
    },
  });

  const authorInfos = {}; // presence of key determines if author is present in doc
  const getAuthorInfos = () => authorInfos;
  editorInfo.ace_getAuthorInfos = getAuthorInfos;

  const setAuthorStyle = (author, info) => {
    const authorSelector = getAuthorColorClassSelector(getAuthorClassName(author));

    const authorStyleSet = hooks.callAll('aceSetAuthorStyle', {
      dynamicCSS: cssManagers.inner,
      outerDynamicCSS: cssManagers.outer,
      parentDynamicCSS: cssManagers.parent,
      info,
      author,
      authorSelector,
    });

    // Prevent default behaviour if any hook says so
    if (authorStyleSet.some((it) => it)) {
      return;
    }

    if (!info) {
      cssManagers.inner.removeSelectorStyle(authorSelector);
      cssManagers.parent.removeSelectorStyle(authorSelector);
    } else if (info.bgcolor) {
      let bgcolor = info.bgcolor;
      if ((typeof info.fade) === 'number') {
        bgcolor = fadeColor(bgcolor, info.fade);
      }
      const textColor =
          colorutils.textColorFromBackgroundColor(bgcolor, parent.parent.clientVars.skinName);
      const styles = [
        cssManagers.inner.selectorStyle(authorSelector),
        cssManagers.parent.selectorStyle(authorSelector),
      ];
      for (const style of styles) {
        style.backgroundColor = bgcolor;
        style.color = textColor;
        style['padding-top'] = '3px';
        style['padding-bottom'] = '4px';
      }
    }
  };

  const setAuthorInfo = (author, info) => {
    if (!author) return; // author ID not set for some reason
    if ((typeof author) !== 'string') {
      // Potentially caused by: https://github.com/ether/etherpad-lite/issues/2802");
      throw new Error(`setAuthorInfo: author (${author}) is not a string`);
    }
    if (!info) {
      delete authorInfos[author];
    } else {
      authorInfos[author] = info;
    }
    setAuthorStyle(author, info);
  };

  const getAuthorClassName = (author) => `author-${author.replace(/[^a-y0-9]/g, (c) => {
    if (c === '.') return '-';
    return `z${c.charCodeAt(0)}z`;
  })}`;

  const className2Author = (className) => {
    if (className.substring(0, 7) === 'author-') {
      return className.substring(7).replace(/[a-y0-9]+|-|z.+?z/g, (cc) => {
        if (cc === '-') { return '.'; } else if (cc.charAt(0) === 'z') {
          return String.fromCharCode(Number(cc.slice(1, -1)));
        } else {
          return cc;
        }
      });
    }
    return null;
  };

  const getAuthorColorClassSelector = (oneClassName) => `.authorColors .${oneClassName}`;

  const fadeColor = (colorCSS, fadeFrac) => {
    let color = colorutils.css2triple(colorCSS);
    color = colorutils.blend(color, [1, 1, 1], fadeFrac);
    return colorutils.triple2css(color);
  };

  editorInfo.ace_getRep = () => rep;

  editorInfo.ace_getAuthor = () => thisAuthor;

  const _nonScrollableEditEvents = {
    applyChangesToBase: 1,
  };

  for (const eventType of hooks.callAll('aceRegisterNonScrollableEditEvents')) {
    _nonScrollableEditEvents[eventType] = 1;
  }

  const isScrollableEditEvent = (eventType) => !_nonScrollableEditEvents[eventType];

  let currentCallStack = null;

  const inCallStack = (type, action) => {
    if (disposed) return;

    const newEditEvent = (eventType) => ({
      eventType,
      backset: null,
    });

    const submitOldEvent = (evt) => {
      if (rep.selStart && rep.selEnd) {
        const selStartChar = rep.lines.offsetOfIndex(rep.selStart[0]) + rep.selStart[1];
        const selEndChar = rep.lines.offsetOfIndex(rep.selEnd[0]) + rep.selEnd[1];
        evt.selStart = selStartChar;
        evt.selEnd = selEndChar;
        evt.selFocusAtStart = rep.selFocusAtStart;
      }
      if (undoModule.enabled) {
        let undoWorked = false;
        try {
          if (isPadLoading(evt.eventType)) {
            undoModule.clearHistory();
          } else if (evt.eventType === 'nonundoable') {
            if (evt.changeset) {
              undoModule.reportExternalChange(evt.changeset);
            }
          } else {
            undoModule.reportEvent(evt);
          }
          undoWorked = true;
        } finally {
          if (!undoWorked) {
            undoModule.enabled = false; // for safety
          }
        }
      }
    };

    const startNewEvent = (eventType, dontSubmitOld) => {
      const oldEvent = currentCallStack.editEvent;
      if (!dontSubmitOld) {
        submitOldEvent(oldEvent);
      }
      currentCallStack.editEvent = newEditEvent(eventType);
      return oldEvent;
    };

    currentCallStack = {
      type,
      docTextChanged: false,
      selectionAffected: false,
      userChangedSelection: false,
      domClean: false,
      isUserChange: false,
      // is this a "user change" type of call-stack
      repChanged: false,
      editEvent: newEditEvent(type),
      startNewEvent,
    };
    let cleanExit = false;
    let result;
    try {
      result = action();

      hooks.callAll('aceEditEvent', {
        callstack: currentCallStack,
        editorInfo,
        rep,
        documentAttributeManager,
      });

      cleanExit = true;
    } finally {
      const cs = currentCallStack;
      if (cleanExit) {
        submitOldEvent(cs.editEvent);
        if (cs.domClean && cs.type !== 'setup') {
          if (cs.selectionAffected) {
            updateBrowserSelectionFromRep();
          }
          if ((cs.docTextChanged || cs.userChangedSelection) && isScrollableEditEvent(cs.type)) {
            scrollSelectionIntoView();
          }
          if (cs.docTextChanged && cs.type.indexOf('importText') < 0) {
            outsideNotifyDirty();
          }
        }
      } else if (currentCallStack.type === 'idleWorkTimer') {
        idleWorkTimer.atLeast(1000);
      }
      currentCallStack = null;
    }
    return result;
  };
  editorInfo.ace_inCallStack = inCallStack;

  const inCallStackIfNecessary = (type, action) => {
    if (!currentCallStack) {
      inCallStack(type, action);
    } else {
      action();
    }
  };
  editorInfo.ace_inCallStackIfNecessary = inCallStackIfNecessary;

  const dispose = () => {
    disposed = true;
    if (idleWorkTimer) idleWorkTimer.never();
    teardown();
  };

  const setWraps = (newVal) => {
    doesWrap = newVal;
    document.body.classList.toggle('doesWrap', doesWrap);
    scheduler.setTimeout(() => {
      inCallStackIfNecessary('setWraps', () => {
        fastIncorp(7);
        recreateDOM();
        fixView();
      });
    }, 0);
  };

  const setStyled = (newVal) => {
    const oldVal = isStyled;
    isStyled = !!newVal;

    if (newVal !== oldVal) {
      if (!newVal) {
        // clear styles
        inCallStackIfNecessary('setStyled', () => {
          fastIncorp(12);
          const clearStyles = [];
          for (const k of Object.keys(STYLE_ATTRIBS)) {
            clearStyles.push([k, '']);
          }
          performDocumentApplyAttributesToCharRange(0, rep.alltext.length, clearStyles);
        });
      }
    }
  };

  const setTextFace = (face) => {
    document.body.style.fontFamily = face;
    lineMetricsDiv.style.fontFamily = face;
  };

  const recreateDOM = () => {
    // precond: normalized
    recolorLinesInRange(0, rep.alltext.length);
  };

  const setEditable = (newVal) => {
    isEditable = newVal;
    document.body.contentEditable = isEditable ? 'true' : 'false';
    document.body.classList.toggle('static', !isEditable);
  };

  const enforceEditability = () => setEditable(isEditable);

  const importText = (text, undoable, dontProcess) => {
    let lines;
    if (dontProcess) {
      if (text.charAt(text.length - 1) !== '\n') {
        throw new Error('new raw text must end with newline');
      }
      if (/[\r\t\xa0]/.exec(text)) {
        throw new Error('new raw text must not contain CR, tab, or nbsp');
      }
      lines = text.substring(0, text.length - 1).split('\n');
    } else {
      lines = text.split('\n').map(textify);
    }
    let newText = '\n';
    if (lines.length > 0) {
      newText = `${lines.join('\n')}\n`;
    }

    inCallStackIfNecessary(`importText${undoable ? 'Undoable' : ''}`, () => {
      setDocText(newText);
    });

    if (dontProcess && rep.alltext !== text) {
      throw new Error('mismatch error setting raw text in importText');
    }
  };

  const importAText = (atext, apoolJsonObj, undoable) => {
    atext = Changeset.cloneAText(atext);
    if (apoolJsonObj) {
      const wireApool = (new AttribPool()).fromJsonable(apoolJsonObj);
      atext.attribs = Changeset.moveOpsToNewPool(atext.attribs, wireApool, rep.apool);
    }
    inCallStackIfNecessary(`importText${undoable ? 'Undoable' : ''}`, () => {
      setDocAText(atext);
    });
  };

  const setDocAText = (atext) => {
    if (atext.text === '') {
      /*
       * The server is fine with atext.text being an empty string, but the front
       * end is not, and crashes.
       *
       * It is not clear if this is a problem in the server or in the client
       * code, and this is a client-side hack fix. The underlying problem needs
       * to be investigated.
       *
       * See for reference:
       * - https://github.com/ether/etherpad-lite/issues/3861
       */
      atext.text = '\n';
    }

    fastIncorp(8);

    const oldLen = rep.lines.totalWidth();
    const numLines = rep.lines.length();
    const upToLastLine = rep.lines.offsetOfIndex(numLines - 1);
    const lastLineLength = rep.lines.atIndex(numLines - 1).text.length;
    const assem = Changeset.smartOpAssembler();
    const o = new Changeset.Op('-');
    o.chars = upToLastLine;
    o.lines = numLines - 1;
    assem.append(o);
    o.chars = lastLineLength;
    o.lines = 0;
    assem.append(o);
    for (const op of Changeset.opsFromAText(atext)) assem.append(op);
    const newLen = oldLen + assem.getLengthChange();
    const changeset = Changeset.checkRep(
        Changeset.pack(oldLen, newLen, assem.toString(), atext.text.slice(0, -1)));
    performDocumentApplyChangeset(changeset);

    performSelectionChange(
        [0, rep.lines.atIndex(0).lineMarker], [0, rep.lines.atIndex(0).lineMarker]);

    idleWorkTimer.atMost(100);

    if (rep.alltext !== atext.text) {
      throw new Error('mismatch error setting raw text in setDocAText');
    }
  };

  const setDocText = (text) => {
    setDocAText(Changeset.makeAText(text));
  };

  const getDocText = () => {
    const alltext = rep.alltext;
    let len = alltext.length;
    if (len > 0) len--; // final extra newline
    return alltext.substring(0, len);
  };

  const exportText = () => {
    if (currentCallStack && !currentCallStack.domClean) {
      inCallStackIfNecessary('exportText', () => {
        fastIncorp(2);
      });
    }
    return getDocText();
  };

  const editorChangedSize = () => fixView();

  const setOnKeyPress = (handler) => {
    outsideKeyPress = handler;
  };

  const setOnKeyDown = (handler) => {
    outsideKeyDown = handler;
  };

  const setNotifyDirty = (handler) => {
    outsideNotifyDirty = handler;
  };

  const CMDS = {
    clearauthorship: (prompt) => {
      if ((!(rep.selStart && rep.selEnd)) || isCaret()) {
        if (prompt) {
          prompt();
        } else {
          performDocumentApplyAttributesToCharRange(0, rep.alltext.length, [
            ['author', ''],
          ]);
        }
      } else {
        setAttributeOnSelection('author', '');
      }
    },
  };

  const execCommand = (cmd, ...args) => {
    cmd = cmd.toLowerCase();
    if (CMDS[cmd]) {
      inCallStackIfNecessary(cmd, () => {
        fastIncorp(9);
        CMDS[cmd](...args);
      });
    }
  };

  const replaceRange = (start, end, text) => {
    inCallStackIfNecessary('replaceRange', () => {
      fastIncorp(9);
      performDocumentReplaceRange(start, end, text);
    });
  };

  editorInfo.ace_callWithAce = (fn, callStack, normalize) => {
    let wrapper = () => fn(editorInfo);

    if (normalize !== undefined) {
      const wrapper1 = wrapper;
      wrapper = () => {
        editorInfo.ace_fastIncorp(9);
        wrapper1();
      };
    }

    if (callStack !== undefined) {
      return editorInfo.ace_inCallStack(callStack, wrapper);
    } else {
      return wrapper();
    }
  };

  /**
   * This methed exposes a setter for some ace properties
   * @param key the name of the parameter
   * @param value the value to set to
   */
  editorInfo.ace_setProperty = (key, value) => {
    // These properties are exposed
    const setters = {
      wraps: setWraps,
      showsauthorcolors: (val) => document.body.classList.toggle('authorColors', !!val),
      showsuserselections: (val) => document.body.classList.toggle('userSelections', !!val),
      showslinenumbers: (value) => {
        hasLineNumbers = !!value;
        sideDiv.parentNode.classList.toggle('line-numbers-hidden', !hasLineNumbers);
        fixView();
      },
      userauthor: (value) => {
        thisAuthor = String(value);
        documentAttributeManager.author = thisAuthor;
      },
      styled: setStyled,
      textface: setTextFace,
      rtlistrue: (value) => {
        document.body.classList.toggle('rtl', value);
        document.body.classList.toggle('ltr', !value);
        document.documentElement.dir = value ? 'rtl' : 'ltr';
      },
    };

    const setter = setters[key.toLowerCase()];

    // check if setter is present
    if (setter !== undefined) {
      setter(value);
    }
  };

  editorInfo.ace_setBaseText = (txt) => {
    changesetTracker.setBaseText(txt);
  };
  editorInfo.ace_setBaseAttributedText = (atxt, apoolJsonObj) => {
    changesetTracker.setBaseAttributedText(atxt, apoolJsonObj);
  };
  editorInfo.ace_applyChangesToBase = (c, optAuthor, apoolJsonObj) => {
    changesetTracker.applyChangesToBase(c, optAuthor, apoolJsonObj);
  };
  editorInfo.ace_prepareUserChangeset = () => changesetTracker.prepareUserChangeset();
  editorInfo.ace_applyPreparedChangesetToBase = () => {
    changesetTracker.applyPreparedChangesetToBase();
  };
  editorInfo.ace_setUserChangeNotificationCallback = (f) => {
    changesetTracker.setUserChangeNotificationCallback(f);
  };
  editorInfo.ace_setAuthorInfo = (author, info) => {
    setAuthorInfo(author, info);
  };

  editorInfo.ace_getDocument = () => document;

  const now = () => Date.now();

  const newTimeLimit = (ms) => {
    const startTime = now();
    let exceededAlready = false;
    let printedTrace = false;
    const isTimeUp = () => {
      if (exceededAlready) {
        if ((!printedTrace)) {
          printedTrace = true;
        }
        return true;
      }
      const elapsed = now() - startTime;
      if (elapsed > ms) {
        exceededAlready = true;
        return true;
      } else {
        return false;
      }
    };

    isTimeUp.elapsed = () => now() - startTime;
    return isTimeUp;
  };


  const makeIdleAction = (func) => {
    let scheduledTimeout = null;
    let scheduledTime = 0;

    const unschedule = () => {
      if (scheduledTimeout) {
        scheduler.clearTimeout(scheduledTimeout);
        scheduledTimeout = null;
      }
    };

    const reschedule = (time) => {
      unschedule();
      scheduledTime = time;
      let delay = time - now();
      if (delay < 0) delay = 0;
      scheduledTimeout = scheduler.setTimeout(callback, delay);
    };

    const callback = () => {
      scheduledTimeout = null;
      // func may reschedule the action
      func();
    };

    return {
      atMost: (ms) => {
        const latestTime = now() + ms;
        if ((!scheduledTimeout) || scheduledTime > latestTime) {
          reschedule(latestTime);
        }
      },
      // atLeast(ms) will schedule the action if not scheduled yet.
      // In other words, "infinity" is replaced by ms, even though
      // it is technically larger.
      atLeast: (ms) => {
        const earliestTime = now() + ms;
        if ((!scheduledTimeout) || scheduledTime < earliestTime) {
          reschedule(earliestTime);
        }
      },
      never: () => {
        unschedule();
      },
    };
  };

  const fastIncorp = (n) => {
    // normalize but don't do any lexing or anything
    incorporateUserChanges();
  };
  editorInfo.ace_fastIncorp = fastIncorp;

  const idleWorkTimer = makeIdleAction(() => {
    if (inInternationalComposition) {
      // don't do idle input incorporation during international input composition
      idleWorkTimer.atLeast(500);
      return;
    }

    inCallStackIfNecessary('idleWorkTimer', () => {
      const isTimeUp = newTimeLimit(250);

      let finishedImportantWork = false;
      let finishedWork = false;

      try {
        incorporateUserChanges();

        if (isTimeUp()) return;

        updateLineNumbers(); // update line numbers if any time left
        if (isTimeUp()) return;
        finishedImportantWork = true;
        finishedWork = true;
      } finally {
        if (finishedWork) {
          idleWorkTimer.atMost(1000);
        } else if (finishedImportantWork) {
          // if we've finished highlighting the view area,
          // more highlighting could be counter-productive,
          // e.g. if the user just opened a triple-quote and will soon close it.
          idleWorkTimer.atMost(500);
        } else {
          let timeToWait = Math.round(isTimeUp.elapsed() / 2);
          if (timeToWait < 100) timeToWait = 100;
          idleWorkTimer.atMost(timeToWait);
        }
      }
    });
  });

  let _nextId = 1;

  const uniqueId = (n) => {
    // not actually guaranteed to be unique, e.g. if user copy-pastes
    // nodes with ids
    const nid = n.id;
    if (nid) return nid;
    return (n.id = `magicdomid${_nextId++}`);
  };


  const recolorLinesInRange = (startChar, endChar) => {
    if (endChar <= startChar) return;
    if (startChar < 0 || startChar >= rep.lines.totalWidth()) return;
    let lineEntry = rep.lines.atOffset(startChar); // rounds down to line boundary
    let lineStart = rep.lines.offsetOfEntry(lineEntry);
    let lineIndex = rep.lines.indexOfEntry(lineEntry);
    let selectionNeedsResetting = false;
    let firstLine = null;

    // tokenFunc function; accesses current value of lineEntry and curDocChar,
    // also mutates curDocChar
    const tokenFunc = (tokenText, tokenClass) => {
      lineEntry.domInfo.appendSpan(tokenText, tokenClass);
    };

    while (lineEntry && lineStart < endChar) {
      const lineEnd = lineStart + lineEntry.width;
      lineEntry.domInfo.clearSpans();
      getSpansForLine(lineEntry, tokenFunc, lineStart);
      lineEntry.domInfo.finishUpdate();

      markNodeClean(lineEntry.lineNode);

      if (rep.selStart && rep.selStart[0] === lineIndex ||
          rep.selEnd && rep.selEnd[0] === lineIndex) {
        selectionNeedsResetting = true;
      }

      if (firstLine == null) firstLine = lineIndex;
      lineStart = lineEnd;
      lineEntry = rep.lines.next(lineEntry);
      lineIndex++;
    }
    if (selectionNeedsResetting) {
      currentCallStack.selectionAffected = true;
    }
  };

  // like getSpansForRange, but for a line, and the func takes (text,class)
  // instead of (width,class); excludes the trailing '\n' from
  // consideration by func


  const getSpansForLine = (lineEntry, textAndClassFunc, lineEntryOffsetHint) => {
    let lineEntryOffset = lineEntryOffsetHint;
    if ((typeof lineEntryOffset) !== 'number') {
      lineEntryOffset = rep.lines.offsetOfEntry(lineEntry);
    }
    const text = lineEntry.text;
    if (text.length === 0) {
      // allow getLineStyleFilter to set line-div styles
      const func = linestylefilter.getLineStyleFilter(
          0, '', textAndClassFunc, rep.apool);
      func('', '');
    } else {
      let filteredFunc = linestylefilter.getFilterStack(text, textAndClassFunc, browser);
      const lineNum = rep.lines.indexOfEntry(lineEntry);
      const aline = rep.alines[lineNum];
      filteredFunc = linestylefilter.getLineStyleFilter(
          text.length, aline, filteredFunc, rep.apool);
      filteredFunc(text, '');
    }
  };

  let observedChanges;

  const clearObservedChanges = () => {
    observedChanges = {
      cleanNodesNearChanges: {},
    };
  };
  clearObservedChanges();

  const getCleanNodeByKey = (key) => {
    let n = document.getElementById(key);
    // copying and pasting can lead to duplicate ids
    while (n && isNodeDirty(n)) {
      n.id = '';
      n = document.getElementById(key);
    }
    return n;
  };

  const observeChangesAroundNode = (node) => {
    // Around this top-level DOM node, look for changes to the document
    // (from how it looks in our representation) and record them in a way
    // that can be used to "normalize" the document (apply the changes to our
    // representation, and put the DOM in a canonical form).
    let cleanNode;
    let hasAdjacentDirtyness;
    if (!isNodeDirty(node)) {
      cleanNode = node;
      const prevSib = cleanNode.previousSibling;
      const nextSib = cleanNode.nextSibling;
      hasAdjacentDirtyness = ((prevSib && isNodeDirty(prevSib)) ||
         (nextSib && isNodeDirty(nextSib)));
    } else {
      // node is dirty, look for clean node above
      let upNode = node.previousSibling;
      while (upNode && isNodeDirty(upNode)) {
        upNode = upNode.previousSibling;
      }
      if (upNode) {
        cleanNode = upNode;
      } else {
        let downNode = node.nextSibling;
        while (downNode && isNodeDirty(downNode)) {
          downNode = downNode.nextSibling;
        }
        if (downNode) {
          cleanNode = downNode;
        }
      }
      if (!cleanNode) {
        // Couldn't find any adjacent clean nodes!
        // Since top and bottom of doc is dirty, the dirty area will be detected.
        return;
      }
      hasAdjacentDirtyness = true;
    }

    if (hasAdjacentDirtyness) {
      // previous or next line is dirty
      observedChanges.cleanNodesNearChanges[`$${uniqueId(cleanNode)}`] = true;
    } else {
      // next and prev lines are clean (if they exist)
      const lineKey = uniqueId(cleanNode);
      const prevSib = cleanNode.previousSibling;
      const nextSib = cleanNode.nextSibling;
      const actualPrevKey = ((prevSib && uniqueId(prevSib)) || null);
      const actualNextKey = ((nextSib && uniqueId(nextSib)) || null);
      const repPrevEntry = rep.lines.prev(rep.lines.atKey(lineKey));
      const repNextEntry = rep.lines.next(rep.lines.atKey(lineKey));
      const repPrevKey = ((repPrevEntry && repPrevEntry.key) || null);
      const repNextKey = ((repNextEntry && repNextEntry.key) || null);
      if (actualPrevKey !== repPrevKey || actualNextKey !== repNextKey) {
        observedChanges.cleanNodesNearChanges[`$${uniqueId(cleanNode)}`] = true;
      }
    }
  };

  const observeChangesAroundSelection = () => {
    if (currentCallStack.observedSelection) return;
    currentCallStack.observedSelection = true;

    const selection = getSelection();

    if (selection) {
      const node1 = topLevel(selection.startPoint.node);
      const node2 = topLevel(selection.endPoint.node);
      if (node1) observeChangesAroundNode(node1);
      if (node2 && node1 !== node2) {
        observeChangesAroundNode(node2);
      }
    }
  };

  const observeSuspiciousNodes = () => {
    // inspired by Firefox bug #473255, where pasting formatted text
    // causes the cursor to jump away, making the new HTML never found.
    if (document.body.getElementsByTagName) {
      const elts = document.body.getElementsByTagName('style');
      for (const elt of elts) {
        const n = topLevel(elt);
        if (n && n.parentNode === document.body) {
          observeChangesAroundNode(n);
        }
      }
    }
  };

  const incorporateUserChanges = () => {
    if (currentCallStack.domClean) return false;

    currentCallStack.isUserChange = true;

    if (DEBUG && window.DONT_INCORP || window.DEBUG_DONT_INCORP) return false;

    // returns true if dom changes were made
    if (!document.body.firstChild) {
      document.body.innerHTML = '<div><!-- --></div>';
    }

    observeChangesAroundSelection();
    observeSuspiciousNodes();
    let dirtyRanges = getDirtyRanges();
    let dirtyRangesCheckOut = true;
    let j = 0;
    let a, b;
    let scrollToTheLeftNeeded = false;

    while (j < dirtyRanges.length) {
      a = dirtyRanges[j][0];
      b = dirtyRanges[j][1];
      if (!((a === 0 || getCleanNodeByKey(rep.lines.atIndex(a - 1).key)) &&
          (b === rep.lines.length() || getCleanNodeByKey(rep.lines.atIndex(b).key)))) {
        dirtyRangesCheckOut = false;
        break;
      }
      j++;
    }
    if (!dirtyRangesCheckOut) {
      for (const bodyNode of document.body.childNodes) {
        if ((bodyNode.tagName) && ((!bodyNode.id) || (!rep.lines.containsKey(bodyNode.id)))) {
          observeChangesAroundNode(bodyNode);
        }
      }
      dirtyRanges = getDirtyRanges();
    }

    clearObservedChanges();

    const selection = getSelection();

    let selStart, selEnd; // each one, if truthy, has [line,char] needed to set selection
    let i = 0;
    const splicesToDo = [];
    let netNumLinesChangeSoFar = 0;
    const toDeleteAtEnd = [];
    const domInsertsNeeded = []; // each entry is [nodeToInsertAfter, [info1, info2, ...]]
    while (i < dirtyRanges.length) {
      const range = dirtyRanges[i];
      a = range[0];
      b = range[1];
      let firstDirtyNode = (((a === 0) && document.body.firstChild) ||
          getCleanNodeByKey(rep.lines.atIndex(a - 1).key).nextSibling);
      firstDirtyNode = (firstDirtyNode && isNodeDirty(firstDirtyNode) && firstDirtyNode);

      let lastDirtyNode = (((b === rep.lines.length()) && document.body.lastChild) ||
          getCleanNodeByKey(rep.lines.atIndex(b).key).previousSibling);

      lastDirtyNode = (lastDirtyNode && isNodeDirty(lastDirtyNode) && lastDirtyNode);
      if (firstDirtyNode && lastDirtyNode) {
        const cc = makeContentCollector(isStyled, browser, rep.apool, className2Author);
        cc.notifySelection(selection);
        const dirtyNodes = [];
        for (let n = firstDirtyNode; n &&
            !(n.previousSibling && n.previousSibling === lastDirtyNode);
          n = n.nextSibling) {
          cc.collectContent(n);
          dirtyNodes.push(n);
        }
        cc.notifyNextNode(lastDirtyNode.nextSibling);
        let lines = cc.getLines();
        if ((lines.length <= 1 || lines[lines.length - 1] !== '') && lastDirtyNode.nextSibling) {
          // dirty region doesn't currently end a line, even taking the following node
          // (or lack of node) into account, so include the following clean node.
          // It could be SPAN or a DIV; basically this is any case where the contentCollector
          // decides it isn't done.
          // Note that this clean node might need to be there for the next dirty range.
          b++;
          const cleanLine = lastDirtyNode.nextSibling;
          cc.collectContent(cleanLine);
          toDeleteAtEnd.push(cleanLine);
          cc.notifyNextNode(cleanLine.nextSibling);
        }

        const ccData = cc.finish();
        const ss = ccData.selStart;
        const se = ccData.selEnd;
        lines = ccData.lines;
        const lineAttribs = ccData.lineAttribs;
        const linesWrapped = ccData.linesWrapped;

        if (linesWrapped > 0) {
          // Chrome decides in its infinite wisdom that it's okay to put the browser's visisble
          // window in the middle of the span. An outcome of this is that the first chars of the
          // string are no longer visible to the user.. Yay chrome.. Move the browser's visible area
          // to the left hand side of the span. Firefox isn't quite so bad, but it's still pretty
          // quirky.
          scrollToTheLeftNeeded = true;
        }

        if (ss[0] >= 0) selStart = [ss[0] + a + netNumLinesChangeSoFar, ss[1]];
        if (se[0] >= 0) selEnd = [se[0] + a + netNumLinesChangeSoFar, se[1]];

        const entries = [];
        const nodeToAddAfter = lastDirtyNode;
        const lineNodeInfos = [];
        for (const lineString of lines) {
          const newEntry = createDomLineEntry(lineString);
          entries.push(newEntry);
          lineNodeInfos.push(newEntry.domInfo);
        }
        domInsertsNeeded.push([nodeToAddAfter, lineNodeInfos]);
        for (const n of dirtyNodes) toDeleteAtEnd.push(n);
        const spliceHints = {};
        if (selStart) spliceHints.selStart = selStart;
        if (selEnd) spliceHints.selEnd = selEnd;
        splicesToDo.push([a + netNumLinesChangeSoFar, b - a, entries, lineAttribs, spliceHints]);
        netNumLinesChangeSoFar += (lines.length - (b - a));
      } else if (b > a) {
        splicesToDo.push([a + netNumLinesChangeSoFar, b - a, [], []]);
      }
      i++;
    }

    const domChanges = (splicesToDo.length > 0);

    for (const splice of splicesToDo) doIncorpLineSplice(...splice);
    for (const ins of domInsertsNeeded) insertDomLines(...ins);
    for (const n of toDeleteAtEnd) n.remove();

    // needed to stop chrome from breaking the ui when long strings without spaces are pasted
    if (scrollToTheLeftNeeded) {
      $('#innerdocbody').scrollLeft(0);
    }

    // if the nodes that define the selection weren't encountered during
    // content collection, figure out where those nodes are now.
    if (selection && !selStart) {
      const selStartFromHook = hooks.callAll('aceStartLineAndCharForPoint', {
        callstack: currentCallStack,
        editorInfo,
        rep,
        root: document.body,
        point: selection.startPoint,
        documentAttributeManager,
      });
      selStart = (selStartFromHook == null || selStartFromHook.length === 0)
        ? getLineAndCharForPoint(selection.startPoint) : selStartFromHook;
    }
    if (selection && !selEnd) {
      const selEndFromHook = hooks.callAll('aceEndLineAndCharForPoint', {
        callstack: currentCallStack,
        editorInfo,
        rep,
        root: document.body,
        point: selection.endPoint,
        documentAttributeManager,
      });
      selEnd = (selEndFromHook == null ||
         selEndFromHook.length === 0)
        ? getLineAndCharForPoint(selection.endPoint) : selEndFromHook;
    }

    // selection from content collection can, in various ways, extend past final
    // BR in firefox DOM, so cap the line
    const numLines = rep.lines.length();
    if (selStart && selStart[0] >= numLines) {
      selStart[0] = numLines - 1;
      selStart[1] = rep.lines.atIndex(selStart[0]).text.length;
    }
    if (selEnd && selEnd[0] >= numLines) {
      selEnd[0] = numLines - 1;
      selEnd[1] = rep.lines.atIndex(selEnd[0]).text.length;
    }

    // update rep if we have a new selection
    // NOTE: IE loses the selection when you click stuff in e.g. the
    // editbar, so removing the selection when it's lost is not a good
    // idea.
    if (selection) repSelectionChange(selStart, selEnd, selection && selection.focusAtStart);
    // update browser selection
    if (selection && (domChanges || isCaret())) {
      // if no DOM changes (not this case), want to treat range selection delicately,
      // e.g. in IE not lose which end of the selection is the focus/anchor;
      // on the other hand, we may have just noticed a press of PageUp/PageDown
      currentCallStack.selectionAffected = true;
    }

    currentCallStack.domClean = true;

    fixView();

    return domChanges;
  };

  const STYLE_ATTRIBS = {
    bold: true,
    italic: true,
    underline: true,
    strikethrough: true,
    list: true,
  };

  const isStyleAttribute = (aname) => !!STYLE_ATTRIBS[aname];

  const isDefaultLineAttribute =
      (aname) => AttributeManager.DEFAULT_LINE_ATTRIBUTES.indexOf(aname) !== -1;

  const insertDomLines = (nodeToAddAfter, infoStructs) => {
    let lastEntry;
    let lineStartOffset;
    for (const info of infoStructs) {
      const node = info.node;
      const key = uniqueId(node);
      let entry;
      if (lastEntry) {
        // optimization to avoid recalculation
        const next = rep.lines.next(lastEntry);
        if (next && next.key === key) {
          entry = next;
          lineStartOffset += lastEntry.width;
        }
      }
      if (!entry) {
        entry = rep.lines.atKey(key);
        lineStartOffset = rep.lines.offsetOfKey(key);
      }
      lastEntry = entry;
      getSpansForLine(entry, (tokenText, tokenClass) => {
        info.appendSpan(tokenText, tokenClass);
      }, lineStartOffset);
      info.prepareForAdd();
      entry.lineMarker = info.lineMarker;
      if (!nodeToAddAfter) {
        document.body.insertBefore(node, document.body.firstChild);
      } else {
        document.body.insertBefore(node, nodeToAddAfter.nextSibling);
      }
      nodeToAddAfter = node;
      info.notifyAdded();
      markNodeClean(node);
    }
  };

  const isCaret = () => (rep.selStart && rep.selEnd &&
                         rep.selStart[0] === rep.selEnd[0] && rep.selStart[1] === rep.selEnd[1]);
  editorInfo.ace_isCaret = isCaret;

  // prereq: isCaret()
  const caretLine = () => rep.selStart[0];

  editorInfo.ace_caretLine = caretLine;

  const caretColumn = () => rep.selStart[1];

  editorInfo.ace_caretColumn = caretColumn;

  const caretDocChar = () => rep.lines.offsetOfIndex(caretLine()) + caretColumn();

  editorInfo.ace_caretDocChar = caretDocChar;

  const handleReturnIndentation = () => {
    // on return, indent to level of previous line
    if (isCaret() && caretColumn() === 0 && caretLine() > 0) {
      const lineNum = caretLine();
      const thisLine = rep.lines.atIndex(lineNum);
      const prevLine = rep.lines.prev(thisLine);
      const prevLineText = prevLine.text;
      let theIndent = /^ *(?:)/.exec(prevLineText)[0];
      const shouldIndent = parent.parent.clientVars.indentationOnNewLine;
      if (shouldIndent && /[[(:{]\s*$/.exec(prevLineText)) {
        theIndent += THE_TAB;
      }
      const cs = Changeset.builder(rep.lines.totalWidth()).keep(
          rep.lines.offsetOfIndex(lineNum), lineNum).insert(
          theIndent, [
            ['author', thisAuthor],
          ], rep.apool).toString();
      performDocumentApplyChangeset(cs);
      performSelectionChange([lineNum, theIndent.length], [lineNum, theIndent.length]);
    }
  };

  const getPointForLineAndChar = (lineAndChar) => {
    const line = lineAndChar[0];
    let charsLeft = lineAndChar[1];
    const lineEntry = rep.lines.atIndex(line);
    charsLeft -= lineEntry.lineMarker;
    if (charsLeft < 0) {
      charsLeft = 0;
    }
    const lineNode = lineEntry.lineNode;
    let n = lineNode;
    let after = false;
    if (charsLeft === 0) {
      return {
        node: lineNode,
        index: 0,
        maxIndex: 1,
      };
    }
    while (!(n === lineNode && after)) {
      if (after) {
        if (n.nextSibling) {
          n = n.nextSibling;
          after = false;
        } else { n = n.parentNode; }
      } else if (isNodeText(n)) {
        const len = n.nodeValue.length;
        if (charsLeft <= len) {
          return {
            node: n,
            index: charsLeft,
            maxIndex: len,
          };
        }
        charsLeft -= len;
        after = true;
      } else if (n.firstChild) { n = n.firstChild; } else { after = true; }
    }
    return {
      node: lineNode,
      index: 1,
      maxIndex: 1,
    };
  };

  const nodeText = (n) => n.textContent || n.nodeValue || '';

  const getLineAndCharForPoint = (point) => {
    // Turn DOM node selection into [line,char] selection.
    // This method has to work when the DOM is not pristine,
    // assuming the point is not in a dirty node.
    if (point.node === document.body) {
      if (point.index === 0) {
        return [0, 0];
      } else {
        const N = rep.lines.length();
        const ln = rep.lines.atIndex(N - 1);
        return [N - 1, ln.text.length];
      }
    } else {
      let n = point.node;
      let col = 0;
      // if this part fails, it probably means the selection node
      // was dirty, and we didn't see it when collecting dirty nodes.
      if (isNodeText(n)) {
        col = point.index;
      } else if (point.index > 0) {
        col = nodeText(n).length;
      }
      let parNode, prevSib;
      while ((parNode = n.parentNode) !== document.body) {
        if ((prevSib = n.previousSibling)) {
          n = prevSib;
          col += nodeText(n).length;
        } else {
          n = parNode;
        }
      }
      if (n.firstChild && isBlockElement(n.firstChild)) {
        col += 1; // lineMarker
      }
      const lineEntry = rep.lines.atKey(n.id);
      const lineNum = rep.lines.indexOfEntry(lineEntry);
      return [lineNum, col];
    }
  };
  editorInfo.ace_getLineAndCharForPoint = getLineAndCharForPoint;

  const createDomLineEntry = (lineString) => {
    const info = doCreateDomLine(lineString.length > 0);
    const newNode = info.node;
    return {
      key: uniqueId(newNode),
      text: lineString,
      lineNode: newNode,
      domInfo: info,
      lineMarker: 0,
    };
  };

  const performDocumentApplyChangeset = (changes, insertsAfterSelection) => {
    const domAndRepSplice = (startLine, deleteCount, newLineStrings) => {
      const keysToDelete = [];
      if (deleteCount > 0) {
        let entryToDelete = rep.lines.atIndex(startLine);
        for (let i = 0; i < deleteCount; i++) {
          keysToDelete.push(entryToDelete.key);
          entryToDelete = rep.lines.next(entryToDelete);
        }
      }

      const lineEntries = newLineStrings.map(createDomLineEntry);

      doRepLineSplice(startLine, deleteCount, lineEntries);

      let nodeToAddAfter;
      if (startLine > 0) {
        nodeToAddAfter = getCleanNodeByKey(rep.lines.atIndex(startLine - 1).key);
      } else { nodeToAddAfter = null; }

      insertDomLines(nodeToAddAfter, lineEntries.map((entry) => entry.domInfo));

      for (const k of keysToDelete) {
        const n = document.getElementById(k);
        n.parentNode.removeChild(n);
      }

      if (
        (rep.selStart &&
          rep.selStart[0] >= startLine &&
          rep.selStart[0] <= startLine + deleteCount) ||
         (rep.selEnd && rep.selEnd[0] >= startLine && rep.selEnd[0] <= startLine + deleteCount)) {
        currentCallStack.selectionAffected = true;
      }
    };

    doRepApplyChangeset(changes, insertsAfterSelection);

    let requiredSelectionSetting = null;
    if (rep.selStart && rep.selEnd) {
      const selStartChar = rep.lines.offsetOfIndex(rep.selStart[0]) + rep.selStart[1];
      const selEndChar = rep.lines.offsetOfIndex(rep.selEnd[0]) + rep.selEnd[1];
      const result =
          Changeset.characterRangeFollow(changes, selStartChar, selEndChar, insertsAfterSelection);
      requiredSelectionSetting = [result[0], result[1], rep.selFocusAtStart];
    }

    const linesMutatee = {
      splice: (start, numRemoved, ...args) => {
        domAndRepSplice(start, numRemoved, args.map((s) => s.slice(0, -1)));
      },
      get: (i) => `${rep.lines.atIndex(i).text}\n`,
      length: () => rep.lines.length(),
    };

    Changeset.mutateTextLines(changes, linesMutatee);

    if (requiredSelectionSetting) {
      performSelectionChange(
          lineAndColumnFromChar(requiredSelectionSetting[0]),
          lineAndColumnFromChar(requiredSelectionSetting[1]),
          requiredSelectionSetting[2]);
    }
  };

  const doRepApplyChangeset = (changes, insertsAfterSelection) => {
    Changeset.checkRep(changes);

    if (Changeset.oldLen(changes) !== rep.alltext.length) {
      const errMsg = `${Changeset.oldLen(changes)}/${rep.alltext.length}`;
      throw new Error(`doRepApplyChangeset length mismatch: ${errMsg}`);
    }

    const editEvent = currentCallStack.editEvent;
    if (editEvent.eventType === 'nonundoable') {
      if (!editEvent.changeset) {
        editEvent.changeset = changes;
      } else {
        editEvent.changeset = Changeset.compose(editEvent.changeset, changes, rep.apool);
      }
    } else {
      const inverseChangeset = Changeset.inverse(changes, {
        get: (i) => `${rep.lines.atIndex(i).text}\n`,
        length: () => rep.lines.length(),
      }, rep.alines, rep.apool);

      if (!editEvent.backset) {
        editEvent.backset = inverseChangeset;
      } else {
        editEvent.backset = Changeset.compose(inverseChangeset, editEvent.backset, rep.apool);
      }
    }

    Changeset.mutateAttributionLines(changes, rep.alines, rep.apool);

    if (changesetTracker.isTracking()) {
      changesetTracker.composeUserChangeset(changes);
    }
  };

  /**
   * Converts the position of a char (index in String) into a [row, col] tuple
   */
  const lineAndColumnFromChar = (x) => {
    const lineEntry = rep.lines.atOffset(x);
    const lineStart = rep.lines.offsetOfEntry(lineEntry);
    const lineNum = rep.lines.indexOfEntry(lineEntry);
    return [lineNum, x - lineStart];
  };

  const performDocumentReplaceCharRange = (startChar, endChar, newText) => {
    if (startChar === endChar && newText.length === 0) {
      return;
    }
    // Requires that the replacement preserve the property that the
    // internal document text ends in a newline.  Given this, we
    // rewrite the splice so that it doesn't touch the very last
    // char of the document.
    if (endChar === rep.alltext.length) {
      if (startChar === endChar) {
        // an insert at end
        startChar--;
        endChar--;
        newText = `\n${newText.substring(0, newText.length - 1)}`;
      } else if (newText.length === 0) {
        // a delete at end
        startChar--;
        endChar--;
      } else {
        // a replace at end
        endChar--;
        newText = newText.substring(0, newText.length - 1);
      }
    }
    performDocumentReplaceRange(
        lineAndColumnFromChar(startChar), lineAndColumnFromChar(endChar), newText);
  };

  const performDocumentApplyAttributesToCharRange = (start, end, attribs) => {
    end = Math.min(end, rep.alltext.length - 1);
    documentAttributeManager.setAttributesOnRange(
        lineAndColumnFromChar(start), lineAndColumnFromChar(end), attribs);
  };

  editorInfo.ace_performDocumentApplyAttributesToCharRange =
      performDocumentApplyAttributesToCharRange;

  const setAttributeOnSelection = (attributeName, attributeValue) => {
    if (!(rep.selStart && rep.selEnd)) return;

    documentAttributeManager.setAttributesOnRange(rep.selStart, rep.selEnd, [
      [attributeName, attributeValue],
    ]);
  };
  editorInfo.ace_setAttributeOnSelection = setAttributeOnSelection;

  const getAttributeOnSelection = (attributeName, prevChar) => {
    if (!(rep.selStart && rep.selEnd)) return;
    const isNotSelection = (rep.selStart[0] === rep.selEnd[0] && rep.selEnd[1] === rep.selStart[1]);
    if (isNotSelection) {
      if (prevChar) {
        // If it's not the start of the line
        if (rep.selStart[1] !== 0) {
          rep.selStart[1]--;
        }
      }
    }

    const withIt = new AttributeMap(rep.apool).set(attributeName, 'true').toString();
    const withItRegex = new RegExp(`${withIt.replace(/\*/g, '\\*')}(\\*|$)`);
    const hasIt = (attribs) => withItRegex.test(attribs);

    const rangeHasAttrib = (selStart, selEnd) => {
      // if range is collapsed -> no attribs in range
      if (selStart[1] === selEnd[1] && selStart[0] === selEnd[0]) return false;

      if (selStart[0] !== selEnd[0]) { // -> More than one line selected
        let hasAttrib = true;

        // from selStart to the end of the first line
        hasAttrib = hasAttrib &&
            rangeHasAttrib(selStart, [selStart[0], rep.lines.atIndex(selStart[0]).text.length]);

        // for all lines in between
        for (let n = selStart[0] + 1; n < selEnd[0]; n++) {
          hasAttrib = hasAttrib && rangeHasAttrib([n, 0], [n, rep.lines.atIndex(n).text.length]);
        }

        // for the last, potentially partial, line
        hasAttrib = hasAttrib && rangeHasAttrib([selEnd[0], 0], [selEnd[0], selEnd[1]]);

        return hasAttrib;
      }

      // Logic tells us we now have a range on a single line

      const lineNum = selStart[0];
      const start = selStart[1];
      const end = selEnd[1];
      let hasAttrib = true;

      let indexIntoLine = 0;
      for (const op of Changeset.deserializeOps(rep.alines[lineNum])) {
        const opStartInLine = indexIntoLine;
        const opEndInLine = opStartInLine + op.chars;
        if (!hasIt(op.attribs)) {
          // does op overlap selection?
          if (!(opEndInLine <= start || opStartInLine >= end)) {
            // since it's overlapping but hasn't got the attrib -> range hasn't got it
            hasAttrib = false;
            break;
          }
        }
        indexIntoLine = opEndInLine;
      }

      return hasAttrib;
    };
    return rangeHasAttrib(rep.selStart, rep.selEnd);
  };

  editorInfo.ace_getAttributeOnSelection = getAttributeOnSelection;

  const toggleAttributeOnSelection = (attributeName) => {
    if (!(rep.selStart && rep.selEnd)) return;

    let selectionAllHasIt = true;
    const withIt = new AttributeMap(rep.apool).set(attributeName, 'true').toString();
    const withItRegex = new RegExp(`${withIt.replace(/\*/g, '\\*')}(\\*|$)`);

    const hasIt = (attribs) => withItRegex.test(attribs);

    const selStartLine = rep.selStart[0];
    const selEndLine = rep.selEnd[0];
    for (let n = selStartLine; n <= selEndLine; n++) {
      let indexIntoLine = 0;
      let selectionStartInLine = 0;
      if (documentAttributeManager.lineHasMarker(n)) {
        selectionStartInLine = 1; // ignore "*" used as line marker
      }
      let selectionEndInLine = rep.lines.atIndex(n).text.length; // exclude newline
      if (n === selStartLine) {
        selectionStartInLine = rep.selStart[1];
      }
      if (n === selEndLine) {
        selectionEndInLine = rep.selEnd[1];
      }
      for (const op of Changeset.deserializeOps(rep.alines[n])) {
        const opStartInLine = indexIntoLine;
        const opEndInLine = opStartInLine + op.chars;
        if (!hasIt(op.attribs)) {
          // does op overlap selection?
          if (!(opEndInLine <= selectionStartInLine || opStartInLine >= selectionEndInLine)) {
            selectionAllHasIt = false;
            break;
          }
        }
        indexIntoLine = opEndInLine;
      }
      if (!selectionAllHasIt) {
        break;
      }
    }


    const attributeValue = selectionAllHasIt ? '' : 'true';
    documentAttributeManager.setAttributesOnRange(
        rep.selStart, rep.selEnd, [[attributeName, attributeValue]]);
    if (attribIsFormattingStyle(attributeName)) {
      updateStyleButtonState(attributeName, !selectionAllHasIt); // italic, bold, ...
    }
  };
  editorInfo.ace_toggleAttributeOnSelection = toggleAttributeOnSelection;

  const performDocumentReplaceSelection = (newText) => {
    if (!(rep.selStart && rep.selEnd)) return;
    performDocumentReplaceRange(rep.selStart, rep.selEnd, newText);
  };

  // Change the abstract representation of the document to have a different set of lines.
  // Must be called after rep.alltext is set.
  const doRepLineSplice = (startLine, deleteCount, newLineEntries) => {
    for (const entry of newLineEntries) entry.width = entry.text.length + 1;

    const startOldChar = rep.lines.offsetOfIndex(startLine);
    const endOldChar = rep.lines.offsetOfIndex(startLine + deleteCount);

    rep.lines.splice(startLine, deleteCount, newLineEntries);
    currentCallStack.docTextChanged = true;
    currentCallStack.repChanged = true;
    const newText = newLineEntries.map((e) => `${e.text}\n`).join('');

    rep.alltext = rep.alltext.substring(0, startOldChar) +
       newText + rep.alltext.substring(endOldChar, rep.alltext.length);
  };

  const doIncorpLineSplice = (startLine, deleteCount, newLineEntries, lineAttribs, hints) => {
    const startOldChar = rep.lines.offsetOfIndex(startLine);
    const endOldChar = rep.lines.offsetOfIndex(startLine + deleteCount);

    const oldRegionStart = rep.lines.offsetOfIndex(startLine);

    let selStartHintChar, selEndHintChar;
    if (hints && hints.selStart) {
      selStartHintChar =
          rep.lines.offsetOfIndex(hints.selStart[0]) + hints.selStart[1] - oldRegionStart;
    }
    if (hints && hints.selEnd) {
      selEndHintChar = rep.lines.offsetOfIndex(hints.selEnd[0]) + hints.selEnd[1] - oldRegionStart;
    }

    const newText = newLineEntries.map((e) => `${e.text}\n`).join('');
    const oldText = rep.alltext.substring(startOldChar, endOldChar);
    const oldAttribs = rep.alines.slice(startLine, startLine + deleteCount).join('');
    const newAttribs = `${lineAttribs.join('|1+1')}|1+1`; // not valid in a changeset
    const analysis =
        analyzeChange(oldText, newText, oldAttribs, newAttribs, selStartHintChar, selEndHintChar);
    const commonStart = analysis[0];
    let commonEnd = analysis[1];
    let shortOldText = oldText.substring(commonStart, oldText.length - commonEnd);
    let shortNewText = newText.substring(commonStart, newText.length - commonEnd);
    let spliceStart = startOldChar + commonStart;
    let spliceEnd = endOldChar - commonEnd;
    let shiftFinalNewlineToBeforeNewText = false;

    // adjust the splice to not involve the final newline of the document;
    // be very defensive
    if (shortOldText.charAt(shortOldText.length - 1) === '\n' &&
        shortNewText.charAt(shortNewText.length - 1) === '\n') {
      // replacing text that ends in newline with text that also ends in newline
      // (still, after analysis, somehow)
      shortOldText = shortOldText.slice(0, -1);
      shortNewText = shortNewText.slice(0, -1);
      spliceEnd--;
      commonEnd++;
    }
    if (shortOldText.length === 0 &&
        spliceStart === rep.alltext.length &&
        shortNewText.length > 0) {
      // inserting after final newline, bad
      spliceStart--;
      spliceEnd--;
      shortNewText = `\n${shortNewText.slice(0, -1)}`;
      shiftFinalNewlineToBeforeNewText = true;
    }
    if (spliceEnd === rep.alltext.length &&
      shortOldText.length > 0 &&
      shortNewText.length === 0) {
      // deletion at end of rep.alltext
      if (rep.alltext.charAt(spliceStart - 1) === '\n') {
        // (if not then what the heck?  it will definitely lead
        // to a rep.alltext without a final newline)
        spliceStart--;
        spliceEnd--;
      }
    }

    if (!(shortOldText.length === 0 && shortNewText.length === 0)) {
      const oldDocText = rep.alltext;
      const oldLen = oldDocText.length;

      const spliceStartLine = rep.lines.indexOfOffset(spliceStart);
      const spliceStartLineStart = rep.lines.offsetOfIndex(spliceStartLine);

      const startBuilder = () => {
        const builder = Changeset.builder(oldLen);
        builder.keep(spliceStartLineStart, spliceStartLine);
        builder.keep(spliceStart - spliceStartLineStart);
        return builder;
      };

      const eachAttribRun = (attribs, func /* (startInNewText, endInNewText, attribs)*/) => {
        let textIndex = 0;
        const newTextStart = commonStart;
        const newTextEnd = newText.length - commonEnd - (shiftFinalNewlineToBeforeNewText ? 1 : 0);
        for (const op of Changeset.deserializeOps(attribs)) {
          const nextIndex = textIndex + op.chars;
          if (!(nextIndex <= newTextStart || textIndex >= newTextEnd)) {
            func(Math.max(newTextStart, textIndex), Math.min(newTextEnd, nextIndex), op.attribs);
          }
          textIndex = nextIndex;
        }
      };

      const justApplyStyles = (shortNewText === shortOldText);
      let theChangeset;

      if (justApplyStyles) {
        // create changeset that clears the incorporated styles on
        // the existing text.  we compose this with the
        // changeset the applies the styles found in the DOM.
        // This allows us to incorporate, e.g., Safari's native "unbold".
        const incorpedAttribClearer = cachedStrFunc(
            (oldAtts) => Changeset.mapAttribNumbers(oldAtts, (n) => {
              const k = rep.apool.getAttribKey(n);
              if (isStyleAttribute(k)) {
                return rep.apool.putAttrib([k, '']);
              }
              return false;
            }));

        const builder1 = startBuilder();
        if (shiftFinalNewlineToBeforeNewText) {
          builder1.keep(1, 1);
        }
        eachAttribRun(oldAttribs, (start, end, attribs) => {
          builder1.keepText(newText.substring(start, end), incorpedAttribClearer(attribs));
        });
        const clearer = builder1.toString();

        const builder2 = startBuilder();
        if (shiftFinalNewlineToBeforeNewText) {
          builder2.keep(1, 1);
        }
        eachAttribRun(newAttribs, (start, end, attribs) => {
          builder2.keepText(newText.substring(start, end), attribs);
        });
        const styler = builder2.toString();

        theChangeset = Changeset.compose(clearer, styler, rep.apool);
      } else {
        const builder = startBuilder();

        const spliceEndLine = rep.lines.indexOfOffset(spliceEnd);
        const spliceEndLineStart = rep.lines.offsetOfIndex(spliceEndLine);
        if (spliceEndLineStart > spliceStart) {
          builder.remove(spliceEndLineStart - spliceStart, spliceEndLine - spliceStartLine);
          builder.remove(spliceEnd - spliceEndLineStart);
        } else {
          builder.remove(spliceEnd - spliceStart);
        }

        let isNewTextMultiauthor = false;
        const authorizer = cachedStrFunc((oldAtts) => {
          const attribs = AttributeMap.fromString(oldAtts, rep.apool);
          if (!isNewTextMultiauthor || !attribs.has('author')) attribs.set('author', thisAuthor);
          return attribs.toString();
        });

        let foundDomAuthor = '';
        eachAttribRun(newAttribs, (start, end, attribs) => {
          const a = AttributeMap.fromString(attribs, rep.apool).get('author');
          if (a && a !== foundDomAuthor) {
            if (!foundDomAuthor) {
              foundDomAuthor = a;
            } else {
              isNewTextMultiauthor = true; // multiple authors in DOM!
            }
          }
        });

        if (shiftFinalNewlineToBeforeNewText) {
          builder.insert('\n', authorizer(''));
        }

        eachAttribRun(newAttribs, (start, end, attribs) => {
          builder.insert(newText.substring(start, end), authorizer(attribs));
        });
        theChangeset = builder.toString();
      }

      doRepApplyChangeset(theChangeset);
    }

    // do this no matter what, because we need to get the right
    // line keys into the rep.
    doRepLineSplice(startLine, deleteCount, newLineEntries);
  };

  const cachedStrFunc = (func) => {
    const cache = {};
    return (s) => {
      if (!cache[s]) {
        cache[s] = func(s);
      }
      return cache[s];
    };
  };

  const analyzeChange = (
    oldText, newText, oldAttribs, newAttribs, optSelStartHint, optSelEndHint) => {
    // we need to take into account both the styles attributes & attributes defined by
    // the plugins, so basically we can ignore only the default line attribs used by
    // Etherpad
    const incorpedAttribFilter = (anum) => !isDefaultLineAttribute(rep.apool.getAttribKey(anum));

    const attribRuns = (attribs) => {
      const lengs = [];
      const atts = [];
      for (const op of Changeset.deserializeOps(attribs)) {
        lengs.push(op.chars);
        atts.push(op.attribs);
      }
      return [lengs, atts];
    };

    const attribIterator = (runs, backward) => {
      const lengs = runs[0];
      const atts = runs[1];
      let i = (backward ? lengs.length - 1 : 0);
      let j = 0;
      const next = () => {
        while (j >= lengs[i]) {
          if (backward) i--;
          else i++;
          j = 0;
        }
        const a = atts[i];
        j++;
        return a;
      };
      return next;
    };

    const oldLen = oldText.length;
    const newLen = newText.length;
    const minLen = Math.min(oldLen, newLen);

    const oldARuns = attribRuns(Changeset.filterAttribNumbers(oldAttribs, incorpedAttribFilter));
    const newARuns = attribRuns(Changeset.filterAttribNumbers(newAttribs, incorpedAttribFilter));

    let commonStart = 0;
    const oldStartIter = attribIterator(oldARuns, false);
    const newStartIter = attribIterator(newARuns, false);
    while (commonStart < minLen) {
      if (oldText.charAt(commonStart) === newText.charAt(commonStart) &&
      oldStartIter() === newStartIter()) {
        commonStart++;
      } else { break; }
    }

    let commonEnd = 0;
    const oldEndIter = attribIterator(oldARuns, true);
    const newEndIter = attribIterator(newARuns, true);
    while (commonEnd < minLen) {
      if (commonEnd === 0) {
        // assume newline in common
        oldEndIter();
        newEndIter();
        commonEnd++;
      } else if (
        oldText.charAt(oldLen - 1 - commonEnd) === newText.charAt(newLen - 1 - commonEnd) &&
          oldEndIter() === newEndIter()) {
        commonEnd++;
      } else { break; }
    }

    let hintedCommonEnd = -1;
    if ((typeof optSelEndHint) === 'number') {
      hintedCommonEnd = newLen - optSelEndHint;
    }


    if (commonStart + commonEnd > oldLen) {
      // ambiguous insertion
      const minCommonEnd = oldLen - commonStart;
      const maxCommonEnd = commonEnd;
      if (hintedCommonEnd >= minCommonEnd && hintedCommonEnd <= maxCommonEnd) {
        commonEnd = hintedCommonEnd;
      } else {
        commonEnd = minCommonEnd;
      }
      commonStart = oldLen - commonEnd;
    }
    if (commonStart + commonEnd > newLen) {
      // ambiguous deletion
      const minCommonEnd = newLen - commonStart;
      const maxCommonEnd = commonEnd;
      if (hintedCommonEnd >= minCommonEnd && hintedCommonEnd <= maxCommonEnd) {
        commonEnd = hintedCommonEnd;
      } else {
        commonEnd = minCommonEnd;
      }
      commonStart = newLen - commonEnd;
    }

    return [commonStart, commonEnd];
  };

  const equalLineAndChars = (a, b) => {
    if (!a) return !b;
    if (!b) return !a;
    return (a[0] === b[0] && a[1] === b[1]);
  };

  const performSelectionChange = (selectStart, selectEnd, focusAtStart) => {
    if (repSelectionChange(selectStart, selectEnd, focusAtStart)) {
      currentCallStack.selectionAffected = true;
    }
  };
  editorInfo.ace_performSelectionChange = performSelectionChange;

  // Change the abstract representation of the document to have a different selection.
  // Should not rely on the line representation.  Should not affect the DOM.


  const repSelectionChange = (selectStart, selectEnd, focusAtStart) => {
    focusAtStart = !!focusAtStart;

    const newSelFocusAtStart = (focusAtStart && ((!selectStart) ||
        (!selectEnd) ||
        (selectStart[0] !== selectEnd[0]) ||
        (selectStart[1] !== selectEnd[1])));

    if ((!equalLineAndChars(rep.selStart, selectStart)) ||
        (!equalLineAndChars(rep.selEnd, selectEnd)) ||
        (rep.selFocusAtStart !== newSelFocusAtStart)) {
      rep.selStart = selectStart;
      rep.selEnd = selectEnd;
      rep.selFocusAtStart = newSelFocusAtStart;
      currentCallStack.repChanged = true;

      // select the formatting buttons when there is the style applied on selection
      selectFormattingButtonIfLineHasStyleApplied(rep);

      hooks.callAll('aceSelectionChanged', {
        rep,
        callstack: currentCallStack,
        documentAttributeManager,
      });

      // we scroll when user places the caret at the last line of the pad
      // when this settings is enabled
      const docTextChanged = currentCallStack.docTextChanged;
      if (!docTextChanged) {
        const isScrollableEvent = !isPadLoading(currentCallStack.type) &&
            isScrollableEditEvent(currentCallStack.type);
        const innerHeight = getInnerHeight();
        scroll.scrollWhenCaretIsInTheLastLineOfViewportWhenNecessary(
            rep, isScrollableEvent, innerHeight * 2);
      }

      return true;
    }
    return false;
  };

  const isPadLoading = (t) => t === 'setup' || t === 'setBaseText' || t === 'importText';

  const updateStyleButtonState = (attribName, hasStyleOnRepSelection) => {
    const $formattingButton = parent.parent.$(`[data-key="${attribName}"]`).find('a');
    $formattingButton.toggleClass(SELECT_BUTTON_CLASS, hasStyleOnRepSelection);
  };

  const attribIsFormattingStyle = (attribName) => FORMATTING_STYLES.indexOf(attribName) !== -1;

  const selectFormattingButtonIfLineHasStyleApplied = (rep) => {
    for (const style of FORMATTING_STYLES) {
      const hasStyleOnRepSelection =
          documentAttributeManager.hasAttributeOnSelectionOrCaretPosition(style);
      updateStyleButtonState(style, hasStyleOnRepSelection);
    }
  };

  const doCreateDomLine =
      (nonEmpty) => domline.createDomLine(nonEmpty, doesWrap, browser, document);

  const textify =
      (str) => str.replace(/[\n\r ]/g, ' ').replace(/\xa0/g, ' ').replace(/\t/g, '        ');

  const _blockElems = {
    div: 1,
    p: 1,
    pre: 1,
    li: 1,
    ol: 1,
    ul: 1,
  };

  for (const element of hooks.callAll('aceRegisterBlockElements')) _blockElems[element] = 1;

  const isBlockElement = (n) => !!_blockElems[(n.tagName || '').toLowerCase()];
  editorInfo.ace_isBlockElement = isBlockElement;

  const getDirtyRanges = () => {
    // based on observedChanges, return a list of ranges of original lines
    // that need to be removed or replaced with new user content to incorporate
    // the user's changes into the line representation.  ranges may be zero-length,
    // indicating inserted content.  for example, [0,0] means content was inserted
    // at the top of the document, while [3,4] means line 3 was deleted, modified,
    // or replaced with one or more new lines of content. ranges do not touch.

    const cleanNodeForIndexCache = {};
    const N = rep.lines.length(); // old number of lines


    const cleanNodeForIndex = (i) => {
      // if line (i) in the un-updated line representation maps to a clean node
      // in the document, return that node.
      // if (i) is out of bounds, return true. else return false.
      if (cleanNodeForIndexCache[i] === undefined) {
        let result;
        if (i < 0 || i >= N) {
          result = true; // truthy, but no actual node
        } else {
          const key = rep.lines.atIndex(i).key;
          result = (getCleanNodeByKey(key) || false);
        }
        cleanNodeForIndexCache[i] = result;
      }
      return cleanNodeForIndexCache[i];
    };
    const isConsecutiveCache = {};

    const isConsecutive = (i) => {
      if (isConsecutiveCache[i] === undefined) {
        isConsecutiveCache[i] = (() => {
          // returns whether line (i) and line (i-1), assumed to be map to clean DOM nodes,
          // or document boundaries, are consecutive in the changed DOM
          const a = cleanNodeForIndex(i - 1);
          const b = cleanNodeForIndex(i);
          if ((!a) || (!b)) return false; // violates precondition
          if ((a === true) && (b === true)) return !document.body.firstChild;
          if ((a === true) && b.previousSibling) return false;
          if ((b === true) && a.nextSibling) return false;
          if ((a === true) || (b === true)) return true;
          return a.nextSibling === b;
        })();
      }
      return isConsecutiveCache[i];
    };

    // returns whether line (i) in the un-updated representation maps to a clean node,
    // or is outside the bounds of the document
    const isClean = (i) => !!cleanNodeForIndex(i);

    // list of pairs, each representing a range of lines that is clean and consecutive
    // in the changed DOM.  lines (-1) and (N) are always clean, but may or may not
    // be consecutive with lines in the document.  pairs are in sorted order.
    const cleanRanges = [
      [-1, N + 1],
    ];

    // returns index of cleanRange containing i, or -1 if none
    const rangeForLine = (i) => {
      for (const [idx, r] of cleanRanges.entries()) {
        if (i < r[0]) return -1;
        if (i < r[1]) return idx;
      }
      return -1;
    };

    const removeLineFromRange = (rng, line) => {
      // rng is index into cleanRanges, line is line number
      // precond: line is in rng
      const a = cleanRanges[rng][0];
      const b = cleanRanges[rng][1];
      if ((a + 1) === b) cleanRanges.splice(rng, 1);
      else if (line === a) cleanRanges[rng][0]++;
      else if (line === (b - 1)) cleanRanges[rng][1]--;
      else cleanRanges.splice(rng, 1, [a, line], [line + 1, b]);
    };

    const splitRange = (rng, pt) => {
      // precond: pt splits cleanRanges[rng] into two non-empty ranges
      const a = cleanRanges[rng][0];
      const b = cleanRanges[rng][1];
      cleanRanges.splice(rng, 1, [a, pt], [pt, b]);
    };

    const correctedLines = {};

    const correctlyAssignLine = (line) => {
      if (correctedLines[line]) return true;
      correctedLines[line] = true;
      // "line" is an index of a line in the un-updated rep.
      // returns whether line was already correctly assigned (i.e. correctly
      // clean or dirty, according to cleanRanges, and if clean, correctly
      // attached or not attached (i.e. in the same range as) the prev and next lines).
      const rng = rangeForLine(line);
      const lineClean = isClean(line);
      if (rng < 0) {
        if (lineClean) {
          // somehow lost clean line
        }
        return true;
      }
      if (!lineClean) {
        // a clean-range includes this dirty line, fix it
        removeLineFromRange(rng, line);
        return false;
      } else {
        // line is clean, but could be wrongly connected to a clean line
        // above or below
        const a = cleanRanges[rng][0];
        const b = cleanRanges[rng][1];
        let didSomething = false;
        // we'll leave non-clean adjacent nodes in the clean range for the caller to
        // detect and deal with.  we deal with whether the range should be split
        // just above or just below this line.
        if (a < line && isClean(line - 1) && !isConsecutive(line)) {
          splitRange(rng, line);
          didSomething = true;
        }
        if (b > (line + 1) && isClean(line + 1) && !isConsecutive(line + 1)) {
          splitRange(rng, line + 1);
          didSomething = true;
        }
        return !didSomething;
      }
    };

    const detectChangesAroundLine = (line, reqInARow) => {
      // make sure cleanRanges is correct about line number "line" and the surrounding
      // lines; only stops checking at end of document or after no changes need
      // making for several consecutive lines. note that iteration is over old lines,
      // so this operation takes time proportional to the number of old lines
      // that are changed or missing, not the number of new lines inserted.
      let correctInARow = 0;
      let currentIndex = line;
      while (correctInARow < reqInARow && currentIndex >= 0) {
        if (correctlyAssignLine(currentIndex)) {
          correctInARow++;
        } else { correctInARow = 0; }
        currentIndex--;
      }
      correctInARow = 0;
      currentIndex = line;
      while (correctInARow < reqInARow && currentIndex < N) {
        if (correctlyAssignLine(currentIndex)) {
          correctInARow++;
        } else { correctInARow = 0; }
        currentIndex++;
      }
    };

    if (N === 0) {
      if (!isConsecutive(0)) {
        splitRange(0, 0);
      }
    } else {
      detectChangesAroundLine(0, 1);
      detectChangesAroundLine(N - 1, 1);

      for (const k of Object.keys(observedChanges.cleanNodesNearChanges)) {
        const key = k.substring(1);
        if (rep.lines.containsKey(key)) {
          const line = rep.lines.indexOfKey(key);
          detectChangesAroundLine(line, 2);
        }
      }
    }

    const dirtyRanges = [];
    for (let r = 0; r < cleanRanges.length - 1; r++) {
      dirtyRanges.push([cleanRanges[r][1], cleanRanges[r + 1][0]]);
    }

    return dirtyRanges;
  };

  const markNodeClean = (n) => {
    // clean nodes have knownHTML that matches their innerHTML
    setAssoc(n, 'dirtiness', {nodeId: uniqueId(n), knownHTML: n.innerHTML});
  };

  const isNodeDirty = (n) => {
    if (n.parentNode !== document.body) return true;
    const data = getAssoc(n, 'dirtiness');
    if (!data) return true;
    if (n.id !== data.nodeId) return true;
    if (n.innerHTML !== data.knownHTML) return true;
    return false;
  };

  const handleClick = (evt) => {
    inCallStackIfNecessary('handleClick', () => {
      idleWorkTimer.atMost(200);
    });

    const isLink = (n) => (n.tagName || '').toLowerCase() === 'a' && n.href;

    // only want to catch left-click
    if ((!evt.ctrlKey) && (evt.button !== 2) && (evt.button !== 3)) {
      // find A tag with HREF
      let n = evt.target;
      while (n && n.parentNode && !isLink(n)) {
        n = n.parentNode;
      }
      if (n && isLink(n)) {
        try {
          window.open(n.href, '_blank', 'noopener,noreferrer');
        } catch (e) {
          // absorb "user canceled" error in IE for certain prompts
        }
        evt.preventDefault();
      }
    }

    hideEditBarDropdowns();
  };

  const hideEditBarDropdowns = () => {
    window.parent.parent.padeditbar.toggleDropDown('none');
  };

  const renumberList = (lineNum) => {
    // 1-check we are in a list
    let type = getLineListType(lineNum);
    if (!type) {
      return null;
    }
    type = /([a-z]+)[0-9]+/.exec(type);
    if (type[1] === 'indent') {
      return null;
    }

    // 2-find the first line of the list
    while (lineNum - 1 >= 0 && (type = getLineListType(lineNum - 1))) {
      type = /([a-z]+)[0-9]+/.exec(type);
      if (type[1] === 'indent') break;
      lineNum--;
    }

    // 3-renumber every list item of the same level from the beginning, level 1
    // IMPORTANT: never skip a level because there imbrication may be arbitrary
    const builder = Changeset.builder(rep.lines.totalWidth());
    let loc = [0, 0];
    const applyNumberList = (line, level) => {
      // init
      let position = 1;
      let curLevel = level;
      let listType;
      // loop over the lines
      while ((listType = getLineListType(line))) {
        // apply new num
        listType = /([a-z]+)([0-9]+)/.exec(listType);
        curLevel = Number(listType[2]);
        if (isNaN(curLevel) || listType[0] === 'indent') {
          return line;
        } else if (curLevel === level) {
          ChangesetUtils.buildKeepRange(rep, builder, loc, (loc = [line, 0]));
          ChangesetUtils.buildKeepRange(rep, builder, loc, (loc = [line, 1]), [
            ['start', position],
          ], rep.apool);

          position++;
          line++;
        } else if (curLevel < level) {
          return line;// back to parent
        } else {
          line = applyNumberList(line, level + 1);// recursive call
        }
      }
      return line;
    };

    applyNumberList(lineNum, 1);
    const cs = builder.toString();
    if (!Changeset.isIdentity(cs)) {
      performDocumentApplyChangeset(cs);
    }

    // 4-apply the modifications
  };
  editorInfo.ace_renumberList = renumberList;

  const setLineListType = (lineNum, listType) => {
    if (listType === '') {
      documentAttributeManager.removeAttributeOnLine(lineNum, listAttributeName);
      documentAttributeManager.removeAttributeOnLine(lineNum, 'start');
    } else {
      documentAttributeManager.setAttributeOnLine(lineNum, listAttributeName, listType);
    }

    // if the list has been removed, it is necessary to renumber
    // starting from the *next* line because the list may have been
    // separated. If it returns null, it means that the list was not cut, try
    // from the current one.
    if (renumberList(lineNum + 1) == null) {
      renumberList(lineNum);
    }
  };

  const doReturnKey = () => {
    if (!(rep.selStart && rep.selEnd)) {
      return;
    }

    const lineNum = rep.selStart[0];
    let listType = getLineListType(lineNum);

    if (listType) {
      const text = rep.lines.atIndex(lineNum).text;
      listType = /([a-z]+)([0-9]+)/.exec(listType);
      const type = listType[1];
      const level = Number(listType[2]);

      // detect empty list item; exclude indentation
      if (text === '*' && type !== 'indent') {
        // if not already on the highest level
        if (level > 1) {
          setLineListType(lineNum, type + (level - 1));// automatically decrease the level
        } else {
          setLineListType(lineNum, '');// remove the list
          renumberList(lineNum + 1);// trigger renumbering of list that may be right after
        }
      } else if (lineNum + 1 <= rep.lines.length()) {
        performDocumentReplaceSelection('\n');
        setLineListType(lineNum + 1, type + level);
      }
    } else {
      performDocumentReplaceSelection('\n');
      handleReturnIndentation();
    }
  };
  editorInfo.ace_doReturnKey = doReturnKey;

  const doIndentOutdent = (isOut) => {
    if (!((rep.selStart && rep.selEnd) ||
          (rep.selStart[0] === rep.selEnd[0] &&
           rep.selStart[1] === rep.selEnd[1] &&
           rep.selEnd[1] > 1)) &&
        isOut !== true) {
      return false;
    }

    const firstLine = rep.selStart[0];
    const lastLine = Math.max(firstLine, rep.selEnd[0] - ((rep.selEnd[1] === 0) ? 1 : 0));
    const mods = [];
    for (let n = firstLine; n <= lastLine; n++) {
      let listType = getLineListType(n);
      let t = 'indent';
      let level = 0;
      if (listType) {
        listType = /([a-z]+)([0-9]+)/.exec(listType);
        if (listType) {
          t = listType[1];
          level = Number(listType[2]);
        }
      }
      const newLevel = Math.max(0, Math.min(MAX_LIST_LEVEL, level + (isOut ? -1 : 1)));
      if (level !== newLevel) {
        mods.push([n, (newLevel > 0) ? t + newLevel : '']);
      }
    }

    for (const mod of mods) setLineListType(mod[0], mod[1]);
    return true;
  };
  editorInfo.ace_doIndentOutdent = doIndentOutdent;

  const doTabKey = (shiftDown) => {
    if (!doIndentOutdent(shiftDown)) {
      performDocumentReplaceSelection(THE_TAB);
    }
  };

  const doDeleteKey = (optEvt) => {
    const evt = optEvt || {};
    let handled = false;
    if (rep.selStart) {
      if (isCaret()) {
        const lineNum = caretLine();
        const col = caretColumn();
        const lineEntry = rep.lines.atIndex(lineNum);
        const lineText = lineEntry.text;
        const lineMarker = lineEntry.lineMarker;
        if (evt.metaKey && col > lineMarker) {
          // cmd-backspace deletes to start of line (if not already at start)
          performDocumentReplaceRange([lineNum, lineMarker], [lineNum, col], '');
          handled = true;
        } else if (/^ +$/.exec(lineText.substring(lineMarker, col))) {
          const col2 = col - lineMarker;
          const tabSize = THE_TAB.length;
          const toDelete = ((col2 - 1) % tabSize) + 1;
          performDocumentReplaceRange([lineNum, col - toDelete], [lineNum, col], '');
          handled = true;
        }
      }
      if (!handled) {
        if (isCaret()) {
          const theLine = caretLine();
          const lineEntry = rep.lines.atIndex(theLine);
          if (caretColumn() <= lineEntry.lineMarker) {
            // delete at beginning of line
            const prevLineListType = (theLine > 0 ? getLineListType(theLine - 1) : '');
            const thisLineListType = getLineListType(theLine);
            const prevLineEntry = (theLine > 0 && rep.lines.atIndex(theLine - 1));
            const prevLineBlank = (prevLineEntry &&
                prevLineEntry.text.length === prevLineEntry.lineMarker);

            const thisLineHasMarker = documentAttributeManager.lineHasMarker(theLine);

            if (thisLineListType) {
              // this line is a list
              if (prevLineBlank && !prevLineListType) {
                // previous line is blank, remove it
                performDocumentReplaceRange(
                    [theLine - 1, prevLineEntry.text.length], [theLine, 0], '');
              } else {
                // delistify
                performDocumentReplaceRange([theLine, 0], [theLine, lineEntry.lineMarker], '');
              }
            } else if (thisLineHasMarker && prevLineEntry) {
              // If the line has any attributes assigned, remove them by removing the marker '*'
              performDocumentReplaceRange(
                  [theLine - 1, prevLineEntry.text.length], [theLine, lineEntry.lineMarker], '');
            } else if (theLine > 0) {
              // remove newline
              performDocumentReplaceRange(
                  [theLine - 1, prevLineEntry.text.length], [theLine, 0], '');
            }
          } else {
            const docChar = caretDocChar();
            if (docChar > 0) {
              if (evt.metaKey || evt.ctrlKey || evt.altKey) {
                // delete as many unicode "letters or digits" in a row as possible;
                // always delete one char, delete further even if that first char
                // isn't actually a word char.
                let deleteBackTo = docChar - 1;
                while (deleteBackTo > lineEntry.lineMarker &&
                  isWordChar(rep.alltext.charAt(deleteBackTo - 1))) {
                  deleteBackTo--;
                }
                performDocumentReplaceCharRange(deleteBackTo, docChar, '');
              } else {
                // normal delete
                performDocumentReplaceCharRange(docChar - 1, docChar, '');
              }
            }
          }
        } else {
          performDocumentReplaceSelection('');
        }
      }
    }
    // if the list has been removed, it is necessary to renumber
    // starting from the *next* line because the list may have been
    // separated. If it returns null, it means that the list was not cut, try
    // from the current one.
    const line = caretLine();
    if (line !== -1 && renumberList(line + 1) == null) {
      renumberList(line);
    }
  };

  const isWordChar = (c) => padutils.wordCharRegex.test(c);
  editorInfo.ace_isWordChar = isWordChar;

  const handleKeyEvent = (evt) => {
    if (!isEditable) return;
    const {type, charCode, keyCode, which, altKey, shiftKey} = evt;

    // Don't take action based on modifier keys going up and down.
    // Modifier keys do not generate "keypress" events.
    // 224 is the command-key under Mac Firefox.
    // 91 is the Windows key in IE; it is ASCII for open-bracket but isn't the keycode for that key
    // 20 is capslock in IE.
    const isModKey = !charCode && (type === 'keyup' || type === 'keydown') &&
        (keyCode === 16 || keyCode === 17 || keyCode === 18 ||
         keyCode === 20 || keyCode === 224 || keyCode === 91);
    if (isModKey) return;

    // If the key is a keypress and the browser is opera and the key is enter,
    // do nothign at all as this fires twice.
    if (keyCode === 13 && browser.opera && type === 'keypress') {
      // This stops double enters in Opera but double Tabs still show on single
      // tab keypress, adding keyCode == 9 to this doesn't help as the event is fired twice
      return;
    }

    const isTypeForSpecialKey = browser.safari || browser.chrome || browser.firefox
      ? type === 'keydown' : type === 'keypress';
    const isTypeForCmdKey = browser.safari || browser.chrome || browser.firefox
      ? type === 'keydown' : type === 'keypress';

    let stopped = false;

    inCallStackIfNecessary('handleKeyEvent', function () {
      if (type === 'keypress' || (isTypeForSpecialKey && keyCode === 13 /* return*/)) {
        // in IE, special keys don't send keypress, the keydown does the action
        if (!outsideKeyPress(evt)) {
          evt.preventDefault();
          stopped = true;
        }
      } else if (evt.key === 'Dead') {
        // If it's a dead key we don't want to do any Etherpad behavior.
        stopped = true;
        return true;
      } else if (type === 'keydown') {
        outsideKeyDown(evt);
      }
      let specialHandled = false;
      if (!stopped) {
        const specialHandledInHook = hooks.callAll('aceKeyEvent', {
          callstack: currentCallStack,
          editorInfo,
          rep,
          documentAttributeManager,
          evt,
        });

        // if any hook returned true, set specialHandled with true
        if (specialHandledInHook) {
          specialHandled = specialHandledInHook.indexOf(true) !== -1;
        }

        const padShortcutEnabled = parent.parent.clientVars.padShortcutEnabled;
        if (!specialHandled && isTypeForSpecialKey &&
            altKey && keyCode === 120 &&
            padShortcutEnabled.altF9) {
          // Alt F9 focuses on the File Menu and/or editbar.
          // Note that while most editors use Alt F10 this is not desirable
          // As ubuntu cannot use Alt F10....
          // Focus on the editbar.
          // -- TODO: Move Focus back to previous state (we know it so we can use it)
          const firstEditbarElement = parent.parent.$('#editbar')
              .children('ul').first().children().first()
              .children().first().children().first();
          $(this).trigger('blur');
          firstEditbarElement.trigger('focus');
          evt.preventDefault();
        }
        if (!specialHandled && type === 'keydown' &&
            altKey && keyCode === 67 &&
            padShortcutEnabled.altC) {
          // Alt c focuses on the Chat window
          $(this).trigger('blur');
          parent.parent.chat.show();
          parent.parent.$('#chatinput').trigger('focus');
          evt.preventDefault();
        }
        if (!specialHandled && type === 'keydown' &&
            evt.ctrlKey && shiftKey && keyCode === 50 &&
            padShortcutEnabled.cmdShift2) {
          // Control-Shift-2 shows a gritter popup showing a line author
          const lineNumber = rep.selEnd[0];
          const alineAttrs = rep.alines[lineNumber];
          const apool = rep.apool;

          // TODO: support selection ranges
          // TODO: Still work when authorship colors have been cleared
          // TODO: i18n
          // TODO: There appears to be a race condition or so.
          const authorIds = new Set();
          if (alineAttrs) {
            for (const op of Changeset.deserializeOps(alineAttrs)) {
              const authorId = AttributeMap.fromString(op.attribs, apool).get('author');
              if (authorId) authorIds.add(authorId);
            }
          }
          const idToName = new Map(parent.parent.pad.userList().map((a) => [a.userId, a.name]));
          const myId = parent.parent.clientVars.userId;
          const authors =
              [...authorIds].map((id) => id === myId ? 'me' : idToName.get(id) || 'unknown');

          parent.parent.$.gritter.add({
            title: 'Line Authors',
            text:
                authors.length === 0 ? 'No author information is available'
                : authors.length === 1 ? `The author of this line is ${authors[0]}`
                : `The authors of this line are ${authors.join(' & ')}`,
            sticky: false,
            time: '4000',
          });
        }
        if (!specialHandled && isTypeForSpecialKey &&
            keyCode === 8 &&
            padShortcutEnabled.delete) {
          // "delete" key; in mozilla, if we're at the beginning of a line, normalize now,
          // or else deleting a blank line can take two delete presses.
          // --
          // we do deletes completely customly now:
          //  - allows consistent (and better) meta-delete behavior
          //  - normalizing and then allowing default behavior confused IE
          //  - probably eliminates a few minor quirks
          fastIncorp(3);
          evt.preventDefault();
          doDeleteKey(evt);
          specialHandled = true;
        }
        if (!specialHandled && isTypeForSpecialKey &&
            keyCode === 13 &&
            padShortcutEnabled.return) {
          // return key, handle specially;
          // note that in mozilla we need to do an incorporation for proper return behavior anyway.
          fastIncorp(4);
          evt.preventDefault();
          doReturnKey();
          scheduler.setTimeout(() => {
            outerWin.scrollBy(-100, 0);
          }, 0);
          specialHandled = true;
        }
        if (!specialHandled && isTypeForSpecialKey &&
            keyCode === 27 &&
            padShortcutEnabled.esc) {
          // prevent esc key;
          // in mozilla versions 14-19 avoid reconnecting pad.

          fastIncorp(4);
          evt.preventDefault();
          specialHandled = true;

          // close all gritters when the user hits escape key
          parent.parent.$.gritter.removeAll();
        }
        if (!specialHandled && isTypeForCmdKey &&
            /* Do a saved revision on ctrl S */
            (evt.metaKey || evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === 's' &&
            !evt.altKey &&
            padShortcutEnabled.cmdS) {
          evt.preventDefault();
          const originalBackground = parent.parent.$('#revisionlink').css('background');
          parent.parent.$('#revisionlink').css({background: 'lightyellow'});
          scheduler.setTimeout(() => {
            parent.parent.$('#revisionlink').css({background: originalBackground});
          }, 1000);
          /* The parent.parent part of this is BAD and I feel bad..  It may break something */
          parent.parent.pad.collabClient.sendMessage({type: 'SAVE_REVISION'});
          specialHandled = true;
        }
        if (!specialHandled && isTypeForSpecialKey &&
            // tab
            keyCode === 9 &&
            !(evt.metaKey || evt.ctrlKey) &&
            padShortcutEnabled.tab) {
          fastIncorp(5);
          evt.preventDefault();
          doTabKey(evt.shiftKey);
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-Z (undo)
            (evt.metaKey || evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === 'z' &&
            !evt.altKey &&
            padShortcutEnabled.cmdZ) {
          fastIncorp(6);
          evt.preventDefault();
          if (evt.shiftKey) {
            doUndoRedo('redo');
          } else {
            doUndoRedo('undo');
          }
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-Y (redo)
            (evt.metaKey || evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === 'y' &&
            padShortcutEnabled.cmdY) {
          fastIncorp(10);
          evt.preventDefault();
          doUndoRedo('redo');
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-B (bold)
            (evt.metaKey || evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === 'b' &&
            padShortcutEnabled.cmdB) {
          fastIncorp(13);
          evt.preventDefault();
          toggleAttributeOnSelection('bold');
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-I (italic)
            (evt.metaKey || evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === 'i' &&
            padShortcutEnabled.cmdI) {
          fastIncorp(14);
          evt.preventDefault();
          toggleAttributeOnSelection('italic');
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-U (underline)
            (evt.metaKey || evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === 'u' &&
            padShortcutEnabled.cmdU) {
          fastIncorp(15);
          evt.preventDefault();
          toggleAttributeOnSelection('underline');
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-5 (strikethrough)
            (evt.metaKey || evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === '5' &&
            evt.altKey !== true &&
            padShortcutEnabled.cmd5) {
          fastIncorp(13);
          evt.preventDefault();
          toggleAttributeOnSelection('strikethrough');
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-shift-L (unorderedlist)
            (evt.metaKey || evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === 'l' &&
            evt.shiftKey &&
            padShortcutEnabled.cmdShiftL) {
          fastIncorp(9);
          evt.preventDefault();
          doInsertUnorderedList();
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-shift-N and cmd-shift-1 (orderedlist)
            (evt.metaKey || evt.ctrlKey) && evt.shiftKey &&
            ((String.fromCharCode(which).toLowerCase() === 'n' && padShortcutEnabled.cmdShiftN) ||
             (String.fromCharCode(which) === '1' && padShortcutEnabled.cmdShift1))) {
          fastIncorp(9);
          evt.preventDefault();
          doInsertOrderedList();
          specialHandled = true;
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-shift-C (clearauthorship)
            (evt.metaKey || evt.ctrlKey) && evt.shiftKey &&
            String.fromCharCode(which).toLowerCase() === 'c' &&
            padShortcutEnabled.cmdShiftC) {
          fastIncorp(9);
          evt.preventDefault();
          CMDS.clearauthorship();
        }
        if (!specialHandled && isTypeForCmdKey &&
            // cmd-H (backspace)
            (evt.ctrlKey) && String.fromCharCode(which).toLowerCase() === 'h' &&
            padShortcutEnabled.cmdH) {
          fastIncorp(20);
          evt.preventDefault();
          doDeleteKey();
          specialHandled = true;
        }
        if (evt.ctrlKey === true && evt.which === 36 &&
            // Control Home send to Y = 0
            padShortcutEnabled.ctrlHome) {
          scroll.setScrollY(0);
        }
        if ((evt.which === 33 || evt.which === 34) && type === 'keydown' && !evt.ctrlKey) {
          // This is required, browsers will try to do normal default behavior on
          // page up / down and the default behavior SUCKS
          evt.preventDefault();
          const oldVisibleLineRange = scroll.getVisibleLineRange(rep);
          let topOffset = rep.selStart[0] - oldVisibleLineRange[0];
          if (topOffset < 0) {
            topOffset = 0;
          }

          const isPageDown = evt.which === 34;
          const isPageUp = evt.which === 33;

          scheduler.setTimeout(() => {
            // the visible lines IE 1,10
            const newVisibleLineRange = scroll.getVisibleLineRange(rep);
            // total count of lines in pad IE 10
            const linesCount = rep.lines.length();
            // How many lines are in the viewport right now?
            const numberOfLinesInViewport = newVisibleLineRange[1] - newVisibleLineRange[0];

            if (isPageUp && padShortcutEnabled.pageUp) {
              // move to the bottom line +1 in the viewport (essentially skipping over a page)
              rep.selEnd[0] -= numberOfLinesInViewport;
              // move to the bottom line +1 in the viewport (essentially skipping over a page)
              rep.selStart[0] -= numberOfLinesInViewport;
            }

            // if we hit page down
            if (isPageDown && padShortcutEnabled.pageDown) {
              // If the new viewpoint position is actually further than where we are right now
              if (rep.selEnd[0] >= oldVisibleLineRange[0]) {
                // dont go further in the page down than what's visible IE go from 0 to 50
                //  if 50 is visible on screen but dont go below that else we miss content
                rep.selStart[0] = oldVisibleLineRange[1] - 1;
                // dont go further in the page down than what's visible IE go from 0 to 50
                // if 50 is visible on screen but dont go below that else we miss content
                rep.selEnd[0] = oldVisibleLineRange[1] - 1;
              }
            }

            // ensure min and max
            if (rep.selEnd[0] < 0) {
              rep.selEnd[0] = 0;
            }
            if (rep.selStart[0] < 0) {
              rep.selStart[0] = 0;
            }
            if (rep.selEnd[0] >= linesCount) {
              rep.selEnd[0] = linesCount - 1;
            }
            updateBrowserSelectionFromRep();
            // get the current caret selection, can't use rep. here because that only gives
            // us the start position not the current
            const myselection = document.getSelection();
            // get the carets selection offset in px IE 214
            let caretOffsetTop = myselection.focusNode.parentNode.offsetTop ||
                myselection.focusNode.offsetTop;

            // sometimes the first selection is -1 which causes problems
            // (Especially with ep_page_view)
            // so use focusNode.offsetTop value.
            if (caretOffsetTop === -1) caretOffsetTop = myselection.focusNode.offsetTop;
            // set the scrollY offset of the viewport on the document
            scroll.setScrollY(caretOffsetTop);
          }, 200);
        }
      }

      if (type === 'keydown') {
        idleWorkTimer.atLeast(500);
      } else if (type === 'keypress') {
        // OPINION ASKED.  What's going on here? :D
        if (!specialHandled) {
          idleWorkTimer.atMost(0);
        } else {
          idleWorkTimer.atLeast(500);
        }
      } else if (type === 'keyup') {
        const wait = 0;
        idleWorkTimer.atLeast(wait);
        idleWorkTimer.atMost(wait);
      }

      // Is part of multi-keystroke international character on Firefox Mac
      const isFirefoxHalfCharacter =
          (browser.firefox && evt.altKey && charCode === 0 && keyCode === 0);

      // Is part of multi-keystroke international character on Safari Mac
      const isSafariHalfCharacter =
          (browser.safari && evt.altKey && keyCode === 229);

      if (thisKeyDoesntTriggerNormalize || isFirefoxHalfCharacter || isSafariHalfCharacter) {
        idleWorkTimer.atLeast(3000); // give user time to type
        // if this is a keydown, e.g., the keyup shouldn't trigger a normalize
        thisKeyDoesntTriggerNormalize = true;
      }

      if (!specialHandled && !thisKeyDoesntTriggerNormalize && !inInternationalComposition &&
          type !== 'keyup') {
        observeChangesAroundSelection();
      }

      if (type === 'keyup') {
        thisKeyDoesntTriggerNormalize = false;
      }
    });
  };

  let thisKeyDoesntTriggerNormalize = false;

  const doUndoRedo = (which) => {
    // precond: normalized DOM
    if (undoModule.enabled) {
      let whichMethod;
      if (which === 'undo') whichMethod = 'performUndo';
      if (which === 'redo') whichMethod = 'performRedo';
      if (whichMethod) {
        const oldEventType = currentCallStack.editEvent.eventType;
        currentCallStack.startNewEvent(which);
        undoModule[whichMethod]((backset, selectionInfo) => {
          if (backset) {
            performDocumentApplyChangeset(backset);
          }
          if (selectionInfo) {
            performSelectionChange(
                lineAndColumnFromChar(selectionInfo.selStart),
                lineAndColumnFromChar(selectionInfo.selEnd),
                selectionInfo.selFocusAtStart);
          }
          const oldEvent = currentCallStack.startNewEvent(oldEventType, true);
          return oldEvent;
        });
      }
    }
  };
  editorInfo.ace_doUndoRedo = doUndoRedo;

  const setSelection = (selection) => {
    const copyPoint = (pt) => ({
      node: pt.node,
      index: pt.index,
      maxIndex: pt.maxIndex,
    });
    let isCollapsed;

    const pointToRangeBound = (pt) => {
      const p = copyPoint(pt);
      // Make sure Firefox cursor is deep enough; fixes cursor jumping when at top level,
      // and also problem where cut/copy of a whole line selected with fake arrow-keys
      // copies the next line too.
      if (isCollapsed) {
        const diveDeep = () => {
          while (p.node.childNodes.length > 0) {
            if (p.index === 0) {
              p.node = p.node.firstChild;
              p.maxIndex = nodeMaxIndex(p.node);
            } else if (p.index === p.maxIndex) {
              p.node = p.node.lastChild;
              p.maxIndex = nodeMaxIndex(p.node);
              p.index = p.maxIndex;
            } else { break; }
          }
        };
        // now fix problem where cursor at end of text node at end of span-like element
        // with background doesn't seem to show up...
        if (isNodeText(p.node) && p.index === p.maxIndex) {
          let n = p.node;
          while (!n.nextSibling && n !== document.body && n.parentNode !== document.body) {
            n = n.parentNode;
          }
          if (n.nextSibling &&
              !(typeof n.nextSibling.tagName === 'string' &&
                n.nextSibling.tagName.toLowerCase() === 'br') &&
              n !== p.node && n !== document.body && n.parentNode !== document.body) {
            // found a parent, go to next node and dive in
            p.node = n.nextSibling;
            p.maxIndex = nodeMaxIndex(p.node);
            p.index = 0;
            diveDeep();
          }
        }
        // try to make sure insertion point is styled;
        // also fixes other FF problems
        if (!isNodeText(p.node)) {
          diveDeep();
        }
      }
      if (isNodeText(p.node)) {
        return {
          container: p.node,
          offset: p.index,
        };
      } else {
        // p.index in {0,1}
        return {
          container: p.node.parentNode,
          offset: childIndex(p.node) + p.index,
        };
      }
    };
    const browserSelection = window.getSelection();
    if (browserSelection) {
      browserSelection.removeAllRanges();
      if (selection) {
        isCollapsed = (selection.startPoint.node === selection.endPoint.node &&
                       selection.startPoint.index === selection.endPoint.index);
        const start = pointToRangeBound(selection.startPoint);
        const end = pointToRangeBound(selection.endPoint);

        if (!isCollapsed && selection.focusAtStart &&
            browserSelection.collapse && browserSelection.extend) {
          // can handle "backwards"-oriented selection, shift-arrow-keys move start
          // of selection
          browserSelection.collapse(end.container, end.offset);
          browserSelection.extend(start.container, start.offset);
        } else {
          const range = document.createRange();
          range.setStart(start.container, start.offset);
          range.setEnd(end.container, end.offset);
          browserSelection.removeAllRanges();
          browserSelection.addRange(range);
        }
      }
    }
  };

  const updateBrowserSelectionFromRep = () => {
    // requires normalized DOM!
    const selStart = rep.selStart;
    const selEnd = rep.selEnd;

    if (!(selStart && selEnd)) {
      setSelection(null);
      return;
    }

    const selection = {};

    const ss = [selStart[0], selStart[1]];
    selection.startPoint = getPointForLineAndChar(ss);

    const se = [selEnd[0], selEnd[1]];
    selection.endPoint = getPointForLineAndChar(se);

    selection.focusAtStart = !!rep.selFocusAtStart;
    setSelection(selection);
  };
  editorInfo.ace_updateBrowserSelectionFromRep = updateBrowserSelectionFromRep;
  editorInfo.ace_focus = focus;
  editorInfo.ace_importText = importText;
  editorInfo.ace_importAText = importAText;
  editorInfo.ace_exportText = exportText;
  editorInfo.ace_editorChangedSize = editorChangedSize;
  editorInfo.ace_setOnKeyPress = setOnKeyPress;
  editorInfo.ace_setOnKeyDown = setOnKeyDown;
  editorInfo.ace_setNotifyDirty = setNotifyDirty;
  editorInfo.ace_dispose = dispose;
  editorInfo.ace_setEditable = setEditable;
  editorInfo.ace_execCommand = execCommand;
  editorInfo.ace_replaceRange = replaceRange;
  editorInfo.ace_getAuthorInfos = getAuthorInfos;
  editorInfo.ace_performDocumentReplaceRange = performDocumentReplaceRange;
  editorInfo.ace_performDocumentReplaceCharRange = performDocumentReplaceCharRange;
  editorInfo.ace_setSelection = setSelection;

  const nodeMaxIndex = (nd) => {
    if (isNodeText(nd)) return nd.nodeValue.length;
    else return 1;
  };

  const getSelection = () => {
    // returns null, or a structure containing startPoint and endPoint,
    // each of which has node (a magicdom node), index, and maxIndex.  If the node
    // is a text node, maxIndex is the length of the text; else maxIndex is 1.
    // index is between 0 and maxIndex, inclusive.
    const browserSelection = window.getSelection();
    if (!browserSelection || browserSelection.type === 'None' ||
        browserSelection.rangeCount === 0) {
      return null;
    }
    const range = browserSelection.getRangeAt(0);

    const isInBody = (n) => {
      while (n && !(n.tagName && n.tagName.toLowerCase() === 'body')) {
        n = n.parentNode;
      }
      return !!n;
    };

    const pointFromRangeBound = (container, offset) => {
      if (!isInBody(container)) {
        // command-click in Firefox selects whole document, HEAD and BODY!
        return {
          node: document.body,
          index: 0,
          maxIndex: 1,
        };
      }
      const n = container;
      const childCount = n.childNodes.length;
      if (isNodeText(n)) {
        return {
          node: n,
          index: offset,
          maxIndex: n.nodeValue.length,
        };
      } else if (childCount === 0) {
        return {
          node: n,
          index: 0,
          maxIndex: 1,
        };
      // treat point between two nodes as BEFORE the second (rather than after the first)
      // if possible; this way point at end of a line block-element is treated as
      // at beginning of next line
      } else if (offset === childCount) {
        const nd = n.childNodes.item(childCount - 1);
        const max = nodeMaxIndex(nd);
        return {
          node: nd,
          index: max,
          maxIndex: max,
        };
      } else {
        const nd = n.childNodes.item(offset);
        const max = nodeMaxIndex(nd);
        return {
          node: nd,
          index: 0,
          maxIndex: max,
        };
      }
    };
    const selection = {
      startPoint: pointFromRangeBound(range.startContainer, range.startOffset),
      endPoint: pointFromRangeBound(range.endContainer, range.endOffset),
      focusAtStart:
          (range.startContainer !== range.endContainer || range.startOffset !== range.endOffset) &&
          browserSelection.anchorNode &&
          browserSelection.anchorNode === range.endContainer &&
          browserSelection.anchorOffset === range.endOffset,
    };

    if (selection.startPoint.node.ownerDocument !== window.document) {
      return null;
    }

    return selection;
  };

  const childIndex = (n) => {
    let idx = 0;
    while (n.previousSibling) {
      idx++;
      n = n.previousSibling;
    }
    return idx;
  };

  const fixView = () => {
    // calling this method repeatedly should be fast
    if (getInnerWidth() === 0 || getInnerHeight() === 0) {
      return;
    }

    enforceEditability();

    $(sideDiv).addClass('sidedivdelayed');
  };

  const _teardownActions = [];

  const teardown = () => { for (const a of _teardownActions) a(); };

  let inInternationalComposition = null;
  editorInfo.ace_getInInternationalComposition = () => inInternationalComposition;

  const bindTheEventHandlers = () => {
    $(document).on('keydown', handleKeyEvent);
    $(document).on('keypress', handleKeyEvent);
    $(document).on('keyup', handleKeyEvent);
    $(document).on('click', handleClick);
    // dropdowns on edit bar need to be closed on clicks on both pad inner and pad outer
    $(outerDoc).on('click', hideEditBarDropdowns);

    // If non-nullish, pasting on a link should be suppressed.
    let suppressPasteOnLink = null;

    $(document.body).on('auxclick', (e) => {
      if (e.originalEvent.button === 1 && (e.target.a || e.target.localName === 'a')) {
        // The user middle-clicked on a link. Usually users do this to open a link in a new tab, but
        // in X11 (Linux) this will instead paste the contents of the primary selection at the mouse
        // cursor. Users almost certainly do not want to paste when middle-clicking on a link, so
        // tell the 'paste' event handler to suppress the paste. This is done by starting a
        // short-lived timer that suppresses paste (when the target is a link) until either the
        // paste event arrives or the timer fires.
        //
        // Why it is implemented this way:
        //   * Users want to be able to paste on a link via Ctrl-V, the Edit menu, or the context
        //     menu (https://github.com/ether/etherpad-lite/issues/2775) so we cannot simply
        //     suppress all paste actions when the target is a link.
        //   * Non-X11 systems do not paste when the user middle-clicks, so the paste suppression
        //     must be self-resetting.
        //   * On non-X11 systems, middle click should continue to open the link in a new tab.
        //     Suppressing the middle click here in the 'auxclick' handler (via e.preventDefault())
        //     would break that behavior.
        suppressPasteOnLink = scheduler.setTimeout(() => { suppressPasteOnLink = null; }, 0);
      }
    });

    $(document.body).on('paste', (e) => {
      if (suppressPasteOnLink != null && (e.target.a || e.target.localName === 'a')) {
        scheduler.clearTimeout(suppressPasteOnLink);
        suppressPasteOnLink = null;
        e.preventDefault();
        return;
      }

      // Call paste hook
      hooks.callAll('acePaste', {
        editorInfo,
        rep,
        documentAttributeManager,
        e,
      });
    });

    // We reference document here, this is because if we don't this will expose a bug
    // in Google Chrome.  This bug will cause the last character on the last line to
    // not fire an event when dropped into..
    $(document).on('drop', (e) => {
      if (e.target.a || e.target.localName === 'a') {
        e.preventDefault();
      }

      // Bug fix: when user drags some content and drop it far from its origin, we
      // need to merge the changes into a single changeset. So mark origin with <style>,
      // in order to make content be observed by incorporateUserChanges() (see
      // observeSuspiciousNodes() for more info)
      const selection = getSelection();
      if (selection) {
        const firstLineSelected = topLevel(selection.startPoint.node);
        const lastLineSelected = topLevel(selection.endPoint.node);

        const lineBeforeSelection = firstLineSelected.previousSibling;
        const lineAfterSelection = lastLineSelected.nextSibling;

        const neighbor = lineBeforeSelection || lineAfterSelection;
        neighbor.appendChild(document.createElement('style'));
      }

      // Call drop hook
      hooks.callAll('aceDrop', {
        editorInfo,
        rep,
        documentAttributeManager,
        e,
      });
    });

    $(document.documentElement).on('compositionstart', () => {
      if (inInternationalComposition) return;
      inInternationalComposition = new Promise((resolve) => {
        $(document.documentElement).one('compositionend', () => {
          inInternationalComposition = null;
          resolve();
        });
      });
    });
  };

  const topLevel = (n) => {
    if ((!n) || n === document.body) return null;
    while (n.parentNode !== document.body) {
      n = n.parentNode;
    }
    return n;
  };

  const getSelectionPointX = (point) => {
    // doesn't work in wrap-mode
    const node = point.node;
    const index = point.index;
    const leftOf = (n) => n.offsetLeft;
    const rightOf = (n) => n.offsetLeft + n.offsetWidth;

    if (!isNodeText(node)) {
      if (index === 0) return leftOf(node);
      else return rightOf(node);
    } else {
      // we can get bounds of element nodes, so look for those.
      // allow consecutive text nodes for robustness.
      let charsToLeft = index;
      let charsToRight = node.nodeValue.length - index;
      let n;
      for (n = node.previousSibling; n && isNodeText(n); n = n.previousSibling) {
        charsToLeft += n.nodeValue;
      }
      const leftEdge = (n ? rightOf(n) : leftOf(node.parentNode));
      for (n = node.nextSibling; n && isNodeText(n); n = n.nextSibling) charsToRight += n.nodeValue;
      const rightEdge = (n ? leftOf(n) : rightOf(node.parentNode));
      const frac = (charsToLeft / (charsToLeft + charsToRight));
      const pixLoc = leftEdge + frac * (rightEdge - leftEdge);
      return Math.round(pixLoc);
    }
  };

  const getInnerHeight = () => {
    const h = browser.opera ? outerWin.innerHeight : outerDoc.documentElement.clientHeight;
    if (h) return h;

    // deal with case where iframe is hidden, hope that
    // style.height of iframe container is set in px
    return Number(editorInfo.frame.parentNode.style.height.replace(/[^0-9]/g, '') || 0);
  };

  const getInnerWidth = () => outerDoc.documentElement.clientWidth;

  const scrollXHorizontallyIntoView = (pixelX) => {
    const distInsideLeft = pixelX - outerWin.scrollX;
    const distInsideRight = outerWin.scrollX + getInnerWidth() - pixelX;
    if (distInsideLeft < 0) {
      outerWin.scrollBy(distInsideLeft, 0);
    } else if (distInsideRight < 0) {
      outerWin.scrollBy(-distInsideRight + 1, 0);
    }
  };

  const scrollSelectionIntoView = () => {
    if (!rep.selStart) return;
    fixView();
    const innerHeight = getInnerHeight();
    scroll.scrollNodeVerticallyIntoView(rep, innerHeight);
    if (!doesWrap) {
      const browserSelection = getSelection();
      if (browserSelection) {
        const focusPoint =
            browserSelection.focusAtStart ? browserSelection.startPoint : browserSelection.endPoint;
        const selectionPointX = getSelectionPointX(focusPoint);
        scrollXHorizontallyIntoView(selectionPointX);
        fixView();
      }
    }
  };

  const listAttributeName = 'list';

  const getLineListType = (lineNum) => documentAttributeManager
      .getAttributeOnLine(lineNum, listAttributeName);
  editorInfo.ace_getLineListType = getLineListType;


  const doInsertList = (type) => {
    if (!(rep.selStart && rep.selEnd)) {
      return;
    }

    const firstLine = rep.selStart[0];
    const lastLine = Math.max(firstLine, rep.selEnd[0] - ((rep.selEnd[1] === 0) ? 1 : 0));

    let allLinesAreList = true;
    for (let n = firstLine; n <= lastLine; n++) {
      const listType = getLineListType(n);
      if (!listType || listType.slice(0, type.length) !== type) {
        allLinesAreList = false;
        break;
      }
    }

    const mods = [];
    for (let n = firstLine; n <= lastLine; n++) {
      let level = 0;
      let togglingOn = true;
      const listType = /([a-z]+)([0-9]+)/.exec(getLineListType(n));

      // Used to outdent if ol is removed
      if (allLinesAreList) {
        togglingOn = false;
      }

      if (listType) {
        level = Number(listType[2]);
      }
      const t = getLineListType(n);

      if (t === listType) togglingOn = false;

      if (togglingOn) {
        mods.push([n, allLinesAreList ? `indent${level}` : (t ? type + level : `${type}1`)]);
      } else {
        // scrap the entire indentation and list type
        if (level === 1) { // if outdending but are the first item in the list then outdent
          setLineListType(n, ''); // outdent
        }
        // else change to indented not bullet
        if (level > 1) {
          setLineListType(n, ''); // remove bullet
          setLineListType(n, `indent${level}`); // in/outdent
        }
      }
    }

    for (const mod of mods) setLineListType(mod[0], mod[1]);
  };

  const doInsertUnorderedList = () => {
    doInsertList('bullet');
  };
  const doInsertOrderedList = () => {
    doInsertList('number');
  };
  editorInfo.ace_doInsertUnorderedList = doInsertUnorderedList;
  editorInfo.ace_doInsertOrderedList = doInsertOrderedList;


  // We apply the height of a line in the doc body, to the corresponding sidediv line number
  const updateLineNumbers = () => {
    // Refs #4228, to avoid layout trashing, we need to first calculate all the heights,
    // and then apply at once all new height to div elements
    const lineOffsets = [];

    // To place the line number on the same Z point as the first character of the first line
    // we need to know the line height including the margins of the firstChild within the line
    // This is somewhat computationally expensive as it looks at the first element within
    // the line.  Alternative, cheaper approaches are welcome.
    // Original Issue: https://github.com/ether/etherpad-lite/issues/4527
    const lineHeights = [];

    // 24 is the default line height within Etherpad - There may be quirks here such as
    // none text elements (images/embeds etc) where the line height will be greater
    // but as it's non-text type the line-height/margins might not be present and it
    // could be that this breaks a theme that has a different default line height..
    // So instead of using an integer here we get the value from the Editor CSS.
    const innerdocbodyStyles = getComputedStyle(document.body);
    const defaultLineHeight = parseInt(innerdocbodyStyles['line-height']);

    for (const docLine of document.body.children) {
      let h;
      const nextDocLine = docLine.nextElementSibling;
      if (nextDocLine) {
        if (lineOffsets.length === 0) {
          // It's the first line. For line number alignment purposes, its
          // height is taken to be the top offset of the next line. If we
          // didn't do this special case, we would miss out on any top margin
          // included on the first line. The default stylesheet doesn't add
          // extra margins/padding, but plugins might.
          h = nextDocLine.offsetTop - parseInt(
              window.getComputedStyle(document.body)
                  .getPropertyValue('padding-top').split('px')[0]);
        } else {
          h = nextDocLine.offsetTop - docLine.offsetTop;
        }
      } else {
        // last line
        h = (docLine.clientHeight || docLine.offsetHeight);
      }
      lineOffsets.push(h);

      if (docLine.clientHeight !== defaultLineHeight) {
        // line is wrapped OR has a larger line height within so we will do additional
        // computation to figure out the line-height of the first element and
        // use that for displaying the side div line number inline with the first line
        // of content -- This is used in ep_headings, ep_font_size etc. where the line
        // height is increased.
        const elementStyle = window.getComputedStyle(docLine.firstChild);
        const lineHeight = parseInt(elementStyle.getPropertyValue('line-height'));
        const marginBottom = parseInt(elementStyle.getPropertyValue('margin-bottom'));
        lineHeights.push(lineHeight + marginBottom);
      } else {
        lineHeights.push(defaultLineHeight);
      }
    }

    let newNumLines = rep.lines.length();
    if (newNumLines < 1) newNumLines = 1;
    while (sideDivInner.children.length < newNumLines) appendNewSideDivLine();
    while (sideDivInner.children.length > newNumLines) sideDivInner.lastElementChild.remove();
    for (const [i, sideDivLine] of Array.prototype.entries.call(sideDivInner.children)) {
      sideDivLine.style.height = `${lineOffsets[i]}px`;
      sideDivLine.style.lineHeight = `${lineHeights[i]}px`;
    }
  };


  // Init documentAttributeManager
  documentAttributeManager = new AttributeManager(rep, performDocumentApplyChangeset);

  editorInfo.ace_performDocumentApplyAttributesToRange =
      (...args) => documentAttributeManager.setAttributesOnRange(...args);

  this.init = async () => {
    await $.ready;
    inCallStack('setup', () => {
      if (browser.firefox) $(document.body).addClass('mozilla');
      if (browser.safari) $(document.body).addClass('safari');
      document.body.classList.toggle('authorColors', true);
      document.body.classList.toggle('doesWrap', doesWrap);

      enforceEditability();

      // set up dom and rep
      while (document.body.firstChild) document.body.removeChild(document.body.firstChild);
      const oneEntry = createDomLineEntry('');
      doRepLineSplice(0, rep.lines.length(), [oneEntry]);
      insertDomLines(null, [oneEntry.domInfo]);
      rep.alines = Changeset.splitAttributionLines(
          Changeset.makeAttribution('\n'), '\n');

      bindTheEventHandlers();
    });

    hooks.callAll('aceInitialized', {
      editorInfo,
      rep,
      documentAttributeManager,
    });
  };
}

exports.init = async (editorInfo, cssManagers) => {
  const editor = new Ace2Inner(editorInfo, cssManagers);
  await editor.init();
};
}}["(module ep_etherpad-lite/static/js/ace2_inner.js)"],
"ep_etherpad-lite/static/js/vendors/browser.js": {"(module ep_etherpad-lite/static/js/vendors/browser.js)": function (require, exports, module) {// WARNING: This file may have been modified from original.
// TODO: Check requirement of this file, this afaik was to cover weird edge cases
// that have probably been fixed in browsers.

/*!
  * Bowser - a browser detector
  * https://github.com/ded/bowser
  * MIT License | (c) Dustin Diaz 2015
  */

!function (name, definition) {
  if (typeof module != 'undefined' && module.exports) module.exports = definition()
  else if (typeof define == 'function' && define.amd) define(definition)
  else this[name] = definition()
}('bowser', function () {
  /**
    * See useragents.js for examples of navigator.userAgent
    */

  var t = true

  function detect(ua) {

    function getFirstMatch(regex) {
      var match = ua.match(regex);
      return (match && match.length > 1 && match[1]) || '';
    }

    function getSecondMatch(regex) {
      var match = ua.match(regex);
      return (match && match.length > 1 && match[2]) || '';
    }

    var iosdevice = getFirstMatch(/(ipod|iphone|ipad)/i).toLowerCase()
      , likeAndroid = /like android/i.test(ua)
      , android = !likeAndroid && /android/i.test(ua)
      , chromeos = /CrOS/.test(ua)
      , silk = /silk/i.test(ua)
      , sailfish = /sailfish/i.test(ua)
      , tizen = /tizen/i.test(ua)
      , webos = /(web|hpw)os/i.test(ua)
      , windowsphone = /windows phone/i.test(ua)
      , windows = !windowsphone && /windows/i.test(ua)
      , mac = !iosdevice && !silk && /macintosh/i.test(ua)
      , linux = !android && !sailfish && !tizen && !webos && /linux/i.test(ua)
      , edgeVersion = getFirstMatch(/edge\/(\d+(\.\d+)?)/i)
      , versionIdentifier = getFirstMatch(/version\/(\d+(\.\d+)?)/i)
      , tablet = /tablet/i.test(ua)
      , mobile = !tablet && /[^-]mobi/i.test(ua)
      , result

    if (/opera|opr/i.test(ua)) {
      result = {
        name: 'Opera'
      , opera: t
      , version: versionIdentifier || getFirstMatch(/(?:opera|opr)[\s\/](\d+(\.\d+)?)/i)
      }
    }
    else if (/yabrowser/i.test(ua)) {
      result = {
        name: 'Yandex Browser'
      , yandexbrowser: t
      , version: versionIdentifier || getFirstMatch(/(?:yabrowser)[\s\/](\d+(\.\d+)?)/i)
      }
    }
    else if (windowsphone) {
      result = {
        name: 'Windows Phone'
      , windowsphone: t
      }
      if (edgeVersion) {
        result.msedge = t
        result.version = edgeVersion
      }
      else {
        result.msie = t
        result.version = getFirstMatch(/iemobile\/(\d+(\.\d+)?)/i)
      }
    }
    else if (/msie|trident/i.test(ua)) {
      result = {
        name: 'Internet Explorer'
      , msie: t
      , version: getFirstMatch(/(?:msie |rv:)(\d+(\.\d+)?)/i)
      }
    } else if (chromeos) {
      result = {
        name: 'Chrome'
      , chromeos: t
      , chromeBook: t
      , chrome: t
      , version: getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.\d+)?)/i)
      }
    } else if (/chrome.+? edge/i.test(ua)) {
      result = {
        name: 'Microsoft Edge'
      , msedge: t
      , version: edgeVersion
      }
    }
    else if (/chrome|crios|crmo/i.test(ua)) {
      result = {
        name: 'Chrome'
      , chrome: t
      , version: getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.\d+)?)/i)
      }
    }
    else if (iosdevice) {
      result = {
        name : iosdevice == 'iphone' ? 'iPhone' : iosdevice == 'ipad' ? 'iPad' : 'iPod'
      }
      // WTF: version is not part of user agent in web apps
      if (versionIdentifier) {
        result.version = versionIdentifier
      }
    }
    else if (sailfish) {
      result = {
        name: 'Sailfish'
      , sailfish: t
      , version: getFirstMatch(/sailfish\s?browser\/(\d+(\.\d+)?)/i)
      }
    }
    else if (/seamonkey\//i.test(ua)) {
      result = {
        name: 'SeaMonkey'
      , seamonkey: t
      , version: getFirstMatch(/seamonkey\/(\d+(\.\d+)?)/i)
      }
    }
    else if (/firefox|iceweasel/i.test(ua)) {
      result = {
        name: 'Firefox'
      , firefox: t
      , version: getFirstMatch(/(?:firefox|iceweasel)[ \/](\d+(\.\d+)?)/i)
      }
      if (/\((mobile|tablet);[^\)]*rv:[\d\.]+\)/i.test(ua)) {
        result.firefoxos = t
      }
    }
    else if (silk) {
      result =  {
        name: 'Amazon Silk'
      , silk: t
      , version : getFirstMatch(/silk\/(\d+(\.\d+)?)/i)
      }
    }
    else if (android) {
      result = {
        name: 'Android'
      , version: versionIdentifier
      }
    }
    else if (/phantom/i.test(ua)) {
      result = {
        name: 'PhantomJS'
      , phantom: t
      , version: getFirstMatch(/phantomjs\/(\d+(\.\d+)?)/i)
      }
    }
    else if (/blackberry|\bbb\d+/i.test(ua) || /rim\stablet/i.test(ua)) {
      result = {
        name: 'BlackBerry'
      , blackberry: t
      , version: versionIdentifier || getFirstMatch(/blackberry[\d]+\/(\d+(\.\d+)?)/i)
      }
    }
    else if (webos) {
      result = {
        name: 'WebOS'
      , webos: t
      , version: versionIdentifier || getFirstMatch(/w(?:eb)?osbrowser\/(\d+(\.\d+)?)/i)
      };
      /touchpad\//i.test(ua) && (result.touchpad = t)
    }
    else if (/bada/i.test(ua)) {
      result = {
        name: 'Bada'
      , bada: t
      , version: getFirstMatch(/dolfin\/(\d+(\.\d+)?)/i)
      };
    }
    else if (tizen) {
      result = {
        name: 'Tizen'
      , tizen: t
      , version: getFirstMatch(/(?:tizen\s?)?browser\/(\d+(\.\d+)?)/i) || versionIdentifier
      };
    }
    else if (/safari/i.test(ua)) {
      result = {
        name: 'Safari'
      , safari: t
      , version: versionIdentifier
      }
    }
    else {
      result = {
        name: getFirstMatch(/^(.*)\/(.*) /),
        version: getSecondMatch(/^(.*)\/(.*) /)
     };
   }

    // set webkit or gecko flag for browsers based on these engines
    if (!result.msedge && /(apple)?webkit/i.test(ua)) {
      result.name = result.name || "Webkit"
      result.webkit = t
      if (!result.version && versionIdentifier) {
        result.version = versionIdentifier
      }
    } else if (!result.opera && /gecko\//i.test(ua)) {
      result.name = result.name || "Gecko"
      result.gecko = t
      result.version = result.version || getFirstMatch(/gecko\/(\d+(\.\d+)?)/i)
    }

    // set OS flags for platforms that have multiple browsers
    if (!result.msedge && (android || result.silk)) {
      result.android = t
    } else if (iosdevice) {
      result[iosdevice] = t
      result.ios = t
    } else if (windows) {
      result.windows = t
    } else if (mac) {
      result.mac = t
    } else if (linux) {
      result.linux = t
    }

    // OS version extraction
    var osVersion = '';
    if (result.windowsphone) {
      osVersion = getFirstMatch(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i);
    } else if (iosdevice) {
      osVersion = getFirstMatch(/os (\d+([_\s]\d+)*) like mac os x/i);
      osVersion = osVersion.replace(/[_\s]/g, '.');
    } else if (android) {
      osVersion = getFirstMatch(/android[ \/-](\d+(\.\d+)*)/i);
    } else if (result.webos) {
      osVersion = getFirstMatch(/(?:web|hpw)os\/(\d+(\.\d+)*)/i);
    } else if (result.blackberry) {
      osVersion = getFirstMatch(/rim\stablet\sos\s(\d+(\.\d+)*)/i);
    } else if (result.bada) {
      osVersion = getFirstMatch(/bada\/(\d+(\.\d+)*)/i);
    } else if (result.tizen) {
      osVersion = getFirstMatch(/tizen[\/\s](\d+(\.\d+)*)/i);
    }
    if (osVersion) {
      result.osversion = osVersion;
    }

    // device type extraction
    var osMajorVersion = osVersion.split('.')[0];
    if (tablet || iosdevice == 'ipad' || (android && (osMajorVersion == 3 || (osMajorVersion == 4 && !mobile))) || result.silk) {
      result.tablet = t
    } else if (mobile || iosdevice == 'iphone' || iosdevice == 'ipod' || android || result.blackberry || result.webos || result.bada) {
      result.mobile = t
    }

    // Graded Browser Support
    // http://developer.yahoo.com/yui/articles/gbs
    if (result.msedge ||
        (result.msie && result.version >= 10) ||
        (result.yandexbrowser && result.version >= 15) ||
        (result.chrome && result.version >= 20) ||
        (result.firefox && result.version >= 20.0) ||
        (result.safari && result.version >= 6) ||
        (result.opera && result.version >= 10.0) ||
        (result.ios && result.osversion && result.osversion.split(".")[0] >= 6) ||
        (result.blackberry && result.version >= 10.1)
        ) {
      result.a = t;
    }
    else if ((result.msie && result.version < 10) ||
        (result.chrome && result.version < 20) ||
        (result.firefox && result.version < 20.0) ||
        (result.safari && result.version < 6) ||
        (result.opera && result.version < 10.0) ||
        (result.ios && result.osversion && result.osversion.split(".")[0] < 6)
        ) {
      result.c = t
    } else result.x = t

    return result
  }

  var bowser = detect(typeof navigator !== 'undefined' ? navigator.userAgent : '')

  bowser.test = function (browserList) {
    for (var i = 0; i < browserList.length; ++i) {
      var browserItem = browserList[i];
      if (typeof browserItem=== 'string') {
        if (browserItem in bowser) {
          return true;
        }
      }
    }
    return false;
  }

  /*
   * Set our detect method to the main bowser object so we can
   * reuse it to test other user agents.
   * This is needed to implement future tests.
   */
  bowser._detect = detect;

  return bowser
});
}}["(module ep_etherpad-lite/static/js/vendors/browser.js)"],
"ep_etherpad-lite/static/js/AttributePool.js": {"(module ep_etherpad-lite/static/js/AttributePool.js)": function (require, exports, module) {'use strict';
/**
 * This code represents the Attribute Pool Object of the original Etherpad.
 * 90% of the code is still like in the original Etherpad
 * Look at https://github.com/ether/pad/blob/master/infrastructure/ace/www/easysync2.js
 * You can find a explanation what a attribute pool is here:
 * https://github.com/ether/etherpad-lite/blob/master/doc/easysync/easysync-notes.txt
 */

/*
 * Copyright 2009 Google Inc., 2011 Peter 'Pita' Martischka (Primary Technology Ltd)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * A `[key, value]` pair of strings describing a text attribute.
 *
 * @typedef {[string, string]} Attribute
 */

/**
 * Maps an attribute's identifier to the attribute.
 *
 * @typedef {Object.<number, Attribute>} NumToAttrib
 */

/**
 * An intermediate representation of the contents of an attribute pool, suitable for serialization
 * via `JSON.stringify` and transmission to another user.
 *
 * @typedef {Object} Jsonable
 * @property {NumToAttrib} numToAttrib - The pool's attributes and their identifiers.
 * @property {number} nextNum - The attribute ID to assign to the next new attribute.
 */

/**
 * Represents an attribute pool, which is a collection of attributes (pairs of key and value
 * strings) along with their identifiers (non-negative integers).
 *
 * The attribute pool enables attribute interning: rather than including the key and value strings
 * in changesets, changesets reference attributes by their identifiers.
 *
 * There is one attribute pool per pad, and it includes every current and historical attribute used
 * in the pad.
 */
class AttributePool {
  constructor() {
    /**
     * Maps an attribute identifier to the attribute's `[key, value]` string pair.
     *
     * TODO: Rename to `_numToAttrib` once all users have been migrated to call `getAttrib` instead
     * of accessing this directly.
     * @private
     * TODO: Convert to an array.
     * @type {NumToAttrib}
     */
    this.numToAttrib = {}; // e.g. {0: ['foo','bar']}

    /**
     * Maps the string representation of an attribute (`String([key, value])`) to its non-negative
     * identifier.
     *
     * TODO: Rename to `_attribToNum` once all users have been migrated to use `putAttrib` instead
     * of accessing this directly.
     * @private
     * TODO: Convert to a `Map` object.
     * @type {Object.<string, number>}
     */
    this.attribToNum = {}; // e.g. {'foo,bar': 0}

    /**
     * The attribute ID to assign to the next new attribute.
     *
     * TODO: This property will not be necessary once `numToAttrib` is converted to an array (just
     * push onto the array).
     *
     * @private
     * @type {number}
     */
    this.nextNum = 0;
  }

  /**
   * @returns {AttributePool} A deep copy of this attribute pool.
   */
  clone() {
    const c = new AttributePool();
    for (const [n, a] of Object.entries(this.numToAttrib)) c.numToAttrib[n] = [a[0], a[1]];
    Object.assign(c.attribToNum, this.attribToNum);
    c.nextNum = this.nextNum;
    return c;
  }

  /**
   * Add an attribute to the attribute set, or query for an existing attribute identifier.
   *
   * @param {Attribute} attrib - The attribute's `[key, value]` pair of strings.
   * @param {boolean} [dontAddIfAbsent=false] - If true, do not insert the attribute into the pool
   *     if the attribute does not already exist in the pool. This can be used to test for
   *     membership in the pool without mutating the pool.
   * @returns {number} The attribute's identifier, or -1 if the attribute is not in the pool.
   */
  putAttrib(attrib, dontAddIfAbsent = false) {
    const str = String(attrib);
    if (str in this.attribToNum) {
      return this.attribToNum[str];
    }
    if (dontAddIfAbsent) {
      return -1;
    }
    const num = this.nextNum++;
    this.attribToNum[str] = num;
    this.numToAttrib[num] = [String(attrib[0] || ''), String(attrib[1] || '')];
    return num;
  }

  /**
   * @param {number} num - The identifier of the attribute to fetch.
   * @returns {Attribute} The attribute with the given identifier, or nullish if there is no such
   *     attribute.
   */
  getAttrib(num) {
    const pair = this.numToAttrib[num];
    if (!pair) {
      return pair;
    }
    return [pair[0], pair[1]]; // return a mutable copy
  }

  /**
   * @param {number} num - The identifier of the attribute to fetch.
   * @returns {string} Eqivalent to `getAttrib(num)[0]` if the attribute exists, otherwise the empty
   *     string.
   */
  getAttribKey(num) {
    const pair = this.numToAttrib[num];
    if (!pair) return '';
    return pair[0];
  }

  /**
   * @param {number} num - The identifier of the attribute to fetch.
   * @returns {string} Eqivalent to `getAttrib(num)[1]` if the attribute exists, otherwise the empty
   *     string.
   */
  getAttribValue(num) {
    const pair = this.numToAttrib[num];
    if (!pair) return '';
    return pair[1];
  }

  /**
   * Executes a callback for each attribute in the pool.
   *
   * @param {Function} func - Callback to call with two arguments: key and value. Its return value
   *     is ignored.
   */
  eachAttrib(func) {
    for (const n of Object.keys(this.numToAttrib)) {
      const pair = this.numToAttrib[n];
      func(pair[0], pair[1]);
    }
  }

  /**
   * @returns {Jsonable} An object that can be passed to `fromJsonable` to reconstruct this
   *     attribute pool. The returned object can be converted to JSON. WARNING: The returned object
   *     has references to internal state (it is not a deep copy). Use the `clone()` method to copy
   *     a pool -- do NOT do `new AttributePool().fromJsonable(pool.toJsonable())` to copy because
   *     the resulting shared state will lead to pool corruption.
   */
  toJsonable() {
    return {
      numToAttrib: this.numToAttrib,
      nextNum: this.nextNum,
    };
  }

  /**
   * Replace the contents of this attribute pool with values from a previous call to `toJsonable`.
   *
   * @param {Jsonable} obj - Object returned by `toJsonable` containing the attributes and their
   *     identifiers. WARNING: This function takes ownership of the object (it does not make a deep
   *     copy). Use the `clone()` method to copy a pool -- do NOT do
   *     `new AttributePool().fromJsonable(pool.toJsonable())` to copy because the resulting shared
   *     state will lead to pool corruption.
   */
  fromJsonable(obj) {
    this.numToAttrib = obj.numToAttrib;
    this.nextNum = obj.nextNum;
    this.attribToNum = {};
    for (const n of Object.keys(this.numToAttrib)) {
      this.attribToNum[String(this.numToAttrib[n])] = Number(n);
    }
    return this;
  }

  /**
   * Asserts that the data in the pool is consistent. Throws if inconsistent.
   */
  check() {
    if (!Number.isInteger(this.nextNum)) throw new Error('nextNum property is not an integer');
    if (this.nextNum < 0) throw new Error('nextNum property is negative');
    for (const prop of ['numToAttrib', 'attribToNum']) {
      const obj = this[prop];
      if (obj == null) throw new Error(`${prop} property is null`);
      if (typeof obj !== 'object') throw new TypeError(`${prop} property is not an object`);
      const keys = Object.keys(obj);
      if (keys.length !== this.nextNum) {
        throw new Error(`${prop} size mismatch (want ${this.nextNum}, got ${keys.length})`);
      }
    }
    for (let i = 0; i < this.nextNum; ++i) {
      const attr = this.numToAttrib[`${i}`];
      if (!Array.isArray(attr)) throw new TypeError(`attrib ${i} is not an array`);
      if (attr.length !== 2) throw new Error(`attrib ${i} is not an array of length 2`);
      const [k, v] = attr;
      if (k == null) throw new TypeError(`attrib ${i} key is null`);
      if (typeof k !== 'string') throw new TypeError(`attrib ${i} key is not a string`);
      if (v == null) throw new TypeError(`attrib ${i} value is null`);
      if (typeof v !== 'string') throw new TypeError(`attrib ${i} value is not a string`);
      const attrStr = String(attr);
      if (this.attribToNum[attrStr] !== i) throw new Error(`attribToNum for ${attrStr} !== ${i}`);
    }
  }
}

module.exports = AttributePool;
}}["(module ep_etherpad-lite/static/js/AttributePool.js)"],
"ep_etherpad-lite/static/js/Changeset.js": {"(module ep_etherpad-lite/static/js/Changeset.js)": function (require, exports, module) {'use strict';

/*
 * Copyright 2009 Google Inc., 2011 Peter 'Pita' Martischka (Primary Technology Ltd)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * This is the Changeset library copied from the old Etherpad with some modifications
 * to use it in node.js. The original can be found at:
 * https://github.com/ether/pad/blob/master/infrastructure/ace/www/easysync2.js
 */

const AttributeMap = require('./AttributeMap');
const AttributePool = require('./AttributePool');
const attributes = require('./attributes');
const {padutils} = require('./pad_utils');

/**
 * A `[key, value]` pair of strings describing a text attribute.
 *
 * @typedef {[string, string]} Attribute
 */

/**
 * A concatenated sequence of zero or more attribute identifiers, each one represented by an
 * asterisk followed by a base-36 encoded attribute number.
 *
 * Examples: '', '*0', '*3*j*z*1q'
 *
 * @typedef {string} AttributeString
 */

/**
 * This method is called whenever there is an error in the sync process.
 *
 * @param {string} msg - Just some message
 */
const error = (msg) => {
  const e = new Error(msg);
  e.easysync = true;
  throw e;
};

/**
 * Assert that a condition is truthy. If the condition is falsy, the `error` function is called to
 * throw an exception.
 *
 * @param {boolean} b - assertion condition
 * @param {string} msg - error message to include in the exception
 * @type {(b: boolean, msg: string) => asserts b}
 */
const assert = (b, msg) => {
  if (!b) error(`Failed assertion: ${msg}`);
};

/**
 * Parses a number from string base 36.
 *
 * @param {string} str - string of the number in base 36
 * @returns {number} number
 */
exports.parseNum = (str) => parseInt(str, 36);

/**
 * Writes a number in base 36 and puts it in a string.
 *
 * @param {number} num - number
 * @returns {string} string
 */
exports.numToString = (num) => num.toString(36).toLowerCase();

/**
 * An operation to apply to a shared document.
 */
class Op {
  /**
   * @param {(''|'='|'+'|'-')} [opcode=''] - Initial value of the `opcode` property.
   */
  constructor(opcode = '') {
    /**
     * The operation's operator:
     *   - '=': Keep the next `chars` characters (containing `lines` newlines) from the base
     *     document.
     *   - '-': Remove the next `chars` characters (containing `lines` newlines) from the base
     *     document.
     *   - '+': Insert `chars` characters (containing `lines` newlines) at the current position in
     *     the document. The inserted characters come from the changeset's character bank.
     *   - '' (empty string): Invalid operator used in some contexts to signifiy the lack of an
     *     operation.
     *
     * @type {(''|'='|'+'|'-')}
     * @public
     */
    this.opcode = opcode;

    /**
     * The number of characters to keep, insert, or delete.
     *
     * @type {number}
     * @public
     */
    this.chars = 0;

    /**
     * The number of characters among the `chars` characters that are newlines. If non-zero, the
     * last character must be a newline.
     *
     * @type {number}
     * @public
     */
    this.lines = 0;

    /**
     * Identifiers of attributes to apply to the text, represented as a repeated (zero or more)
     * sequence of asterisk followed by a non-negative base-36 (lower-case) integer. For example,
     * '*2*1o' indicates that attributes 2 and 60 apply to the text affected by the operation. The
     * identifiers come from the document's attribute pool.
     *
     * For keep ('=') operations, the attributes are merged with the base text's existing
     * attributes:
     *   - A keep op attribute with a non-empty value replaces an existing base text attribute that
     *     has the same key.
     *   - A keep op attribute with an empty value is interpreted as an instruction to remove an
     *     existing base text attribute that has the same key, if one exists.
     *
     * This is the empty string for remove ('-') operations.
     *
     * @type {string}
     * @public
     */
    this.attribs = '';
  }

  toString() {
    if (!this.opcode) throw new TypeError('null op');
    if (typeof this.attribs !== 'string') throw new TypeError('attribs must be a string');
    const l = this.lines ? `|${exports.numToString(this.lines)}` : '';
    return this.attribs + l + this.opcode + exports.numToString(this.chars);
  }
}
exports.Op = Op;

/**
 * Describes changes to apply to a document. Does not include the attribute pool or the original
 * document.
 *
 * @typedef {object} Changeset
 * @property {number} oldLen - The length of the base document.
 * @property {number} newLen - The length of the document after applying the changeset.
 * @property {string} ops - Serialized sequence of operations. Use `deserializeOps` to parse this
 *     string.
 * @property {string} charBank - Characters inserted by insert operations.
 */

/**
 * Returns the required length of the text before changeset can be applied.
 *
 * @param {string} cs - String representation of the Changeset
 * @returns {number} oldLen property
 */
exports.oldLen = (cs) => exports.unpack(cs).oldLen;

/**
 * Returns the length of the text after changeset is applied.
 *
 * @param {string} cs - String representation of the Changeset
 * @returns {number} newLen property
 */
exports.newLen = (cs) => exports.unpack(cs).newLen;

/**
 * Parses a string of serialized changeset operations.
 *
 * @param {string} ops - Serialized changeset operations.
 * @yields {Op}
 * @returns {Generator<Op>}
 */
exports.deserializeOps = function* (ops) {
  // TODO: Migrate to String.prototype.matchAll() once there is enough browser support.
  const regex = /((?:\*[0-9a-z]+)*)(?:\|([0-9a-z]+))?([-+=])([0-9a-z]+)|(.)/g;
  let match;
  while ((match = regex.exec(ops)) != null) {
    if (match[5] === '$') return; // Start of the insert operation character bank.
    if (match[5] != null) error(`invalid operation: ${ops.slice(regex.lastIndex - 1)}`);
    const op = new Op(match[3]);
    op.lines = exports.parseNum(match[2] || '0');
    op.chars = exports.parseNum(match[4]);
    op.attribs = match[1];
    yield op;
  }
};

/**
 * Iterator over a changeset's operations.
 *
 * Note: This class does NOT implement the ECMAScript iterable or iterator protocols.
 *
 * @deprecated Use `deserializeOps` instead.
 */
class OpIter {
  /**
   * @param {string} ops - String encoding the change operations to iterate over.
   */
  constructor(ops) {
    this._gen = exports.deserializeOps(ops);
    this._next = this._gen.next();
  }

  /**
   * @returns {boolean} Whether there are any remaining operations.
   */
  hasNext() {
    return !this._next.done;
  }

  /**
   * Returns the next operation object and advances the iterator.
   *
   * Note: This does NOT implement the ECMAScript iterator protocol.
   *
   * @param {Op} [opOut] - Deprecated. Operation object to recycle for the return value.
   * @returns {Op} The next operation, or an operation with a falsy `opcode` property if there are
   *     no more operations.
   */
  next(opOut = new Op()) {
    if (this.hasNext()) {
      copyOp(this._next.value, opOut);
      this._next = this._gen.next();
    } else {
      clearOp(opOut);
    }
    return opOut;
  }
}

/**
 * Creates an iterator which decodes string changeset operations.
 *
 * @deprecated Use `deserializeOps` instead.
 * @param {string} opsStr - String encoding of the change operations to perform.
 * @returns {OpIter} Operator iterator object.
 */
exports.opIterator = (opsStr) => {
  padutils.warnDeprecated(
      'Changeset.opIterator() is deprecated; use Changeset.deserializeOps() instead');
  return new OpIter(opsStr);
};

/**
 * Cleans an Op object.
 *
 * @param {Op} op - object to clear
 */
const clearOp = (op) => {
  op.opcode = '';
  op.chars = 0;
  op.lines = 0;
  op.attribs = '';
};

/**
 * Creates a new Op object
 *
 * @deprecated Use the `Op` class instead.
 * @param {('+'|'-'|'='|'')} [optOpcode=''] - The operation's operator.
 * @returns {Op}
 */
exports.newOp = (optOpcode) => {
  padutils.warnDeprecated('Changeset.newOp() is deprecated; use the Changeset.Op class instead');
  return new Op(optOpcode);
};

/**
 * Copies op1 to op2
 *
 * @param {Op} op1 - src Op
 * @param {Op} [op2] - dest Op. If not given, a new Op is used.
 * @returns {Op} `op2`
 */
const copyOp = (op1, op2 = new Op()) => Object.assign(op2, op1);

/**
 * Serializes a sequence of Ops.
 *
 * @typedef {object} OpAssembler
 * @property {Function} append -
 * @property {Function} clear -
 * @property {Function} toString -
 */

/**
 * Efficiently merges consecutive operations that are mergeable, ignores no-ops, and drops final
 * pure "keeps". It does not re-order operations.
 *
 * @typedef {object} MergingOpAssembler
 * @property {Function} append -
 * @property {Function} clear -
 * @property {Function} endDocument -
 * @property {Function} toString -
 */

/**
 * Generates operations from the given text and attributes.
 *
 * @param {('-'|'+'|'=')} opcode - The operator to use.
 * @param {string} text - The text to remove/add/keep.
 * @param {(Iterable<Attribute>|AttributeString)} [attribs] - The attributes to insert into the pool
 *     (if necessary) and encode. If an attribute string, no checking is performed to ensure that
 *     the attributes exist in the pool, are in the canonical order, and contain no duplicate keys.
 *     If this is an iterable of attributes, `pool` must be non-null.
 * @param {?AttributePool} pool - Attribute pool. Required if `attribs` is an iterable of
 *     attributes, ignored if `attribs` is an attribute string.
 * @yields {Op} One or two ops (depending on the presense of newlines) that cover the given text.
 * @returns {Generator<Op>}
 */
const opsFromText = function* (opcode, text, attribs = '', pool = null) {
  const op = new Op(opcode);
  op.attribs = typeof attribs === 'string'
    ? attribs : new AttributeMap(pool).update(attribs || [], opcode === '+').toString();
  const lastNewlinePos = text.lastIndexOf('\n');
  if (lastNewlinePos < 0) {
    op.chars = text.length;
    op.lines = 0;
    yield op;
  } else {
    op.chars = lastNewlinePos + 1;
    op.lines = text.match(/\n/g).length;
    yield op;
    const op2 = copyOp(op);
    op2.chars = text.length - (lastNewlinePos + 1);
    op2.lines = 0;
    yield op2;
  }
};

/**
 * Creates an object that allows you to append operations (type Op) and also compresses them if
 * possible. Like MergingOpAssembler, but able to produce conforming exportss from slightly looser
 * input, at the cost of speed. Specifically:
 *   - merges consecutive operations that can be merged
 *   - strips final "="
 *   - ignores 0-length changes
 *   - reorders consecutive + and - (which MergingOpAssembler doesn't do)
 *
 * @typedef {object} SmartOpAssembler
 * @property {Function} append -
 * @property {Function} appendOpWithText -
 * @property {Function} clear -
 * @property {Function} endDocument -
 * @property {Function} getLengthChange -
 * @property {Function} toString -
 */

/**
 * Used to check if a Changeset is valid. This function does not check things that require access to
 * the attribute pool (e.g., attribute order) or original text (e.g., newline positions).
 *
 * @param {string} cs - Changeset to check
 * @returns {string} the checked Changeset
 */
exports.checkRep = (cs) => {
  const unpacked = exports.unpack(cs);
  const oldLen = unpacked.oldLen;
  const newLen = unpacked.newLen;
  const ops = unpacked.ops;
  let charBank = unpacked.charBank;

  const assem = exports.smartOpAssembler();
  let oldPos = 0;
  let calcNewLen = 0;
  for (const o of exports.deserializeOps(ops)) {
    switch (o.opcode) {
      case '=':
        oldPos += o.chars;
        calcNewLen += o.chars;
        break;
      case '-':
        oldPos += o.chars;
        assert(oldPos <= oldLen, `${oldPos} > ${oldLen} in ${cs}`);
        break;
      case '+':
      {
        assert(charBank.length >= o.chars, 'Invalid changeset: not enough chars in charBank');
        const chars = charBank.slice(0, o.chars);
        const nlines = (chars.match(/\n/g) || []).length;
        assert(nlines === o.lines,
            'Invalid changeset: number of newlines in insert op does not match the charBank');
        assert(o.lines === 0 || chars.endsWith('\n'),
            'Invalid changeset: multiline insert op does not end with a newline');
        charBank = charBank.slice(o.chars);
        calcNewLen += o.chars;
        assert(calcNewLen <= newLen, `${calcNewLen} > ${newLen} in ${cs}`);
        break;
      }
      default:
        assert(false, `Invalid changeset: Unknown opcode: ${JSON.stringify(o.opcode)}`);
    }
    assem.append(o);
  }
  calcNewLen += oldLen - oldPos;
  assert(calcNewLen === newLen, 'Invalid changeset: claimed length does not match actual length');
  assert(charBank === '', 'Invalid changeset: excess characters in the charBank');
  assem.endDocument();
  const normalized = exports.pack(oldLen, calcNewLen, assem.toString(), unpacked.charBank);
  assert(normalized === cs, 'Invalid changeset: not in canonical form');
  return cs;
};

/**
 * @returns {SmartOpAssembler}
 */
exports.smartOpAssembler = () => {
  const minusAssem = exports.mergingOpAssembler();
  const plusAssem = exports.mergingOpAssembler();
  const keepAssem = exports.mergingOpAssembler();
  const assem = exports.stringAssembler();
  let lastOpcode = '';
  let lengthChange = 0;

  const flushKeeps = () => {
    assem.append(keepAssem.toString());
    keepAssem.clear();
  };

  const flushPlusMinus = () => {
    assem.append(minusAssem.toString());
    minusAssem.clear();
    assem.append(plusAssem.toString());
    plusAssem.clear();
  };

  const append = (op) => {
    if (!op.opcode) return;
    if (!op.chars) return;

    if (op.opcode === '-') {
      if (lastOpcode === '=') {
        flushKeeps();
      }
      minusAssem.append(op);
      lengthChange -= op.chars;
    } else if (op.opcode === '+') {
      if (lastOpcode === '=') {
        flushKeeps();
      }
      plusAssem.append(op);
      lengthChange += op.chars;
    } else if (op.opcode === '=') {
      if (lastOpcode !== '=') {
        flushPlusMinus();
      }
      keepAssem.append(op);
    }
    lastOpcode = op.opcode;
  };

  /**
   * Generates operations from the given text and attributes.
   *
   * @deprecated Use `opsFromText` instead.
   * @param {('-'|'+'|'=')} opcode - The operator to use.
   * @param {string} text - The text to remove/add/keep.
   * @param {(string|Iterable<Attribute>)} attribs - The attributes to apply to the operations.
   * @param {?AttributePool} pool - Attribute pool. Only required if `attribs` is an iterable of
   *     attribute key, value pairs.
   */
  const appendOpWithText = (opcode, text, attribs, pool) => {
    padutils.warnDeprecated('Changeset.smartOpAssembler().appendOpWithText() is deprecated; ' +
                            'use opsFromText() instead.');
    for (const op of opsFromText(opcode, text, attribs, pool)) append(op);
  };

  const toString = () => {
    flushPlusMinus();
    flushKeeps();
    return assem.toString();
  };

  const clear = () => {
    minusAssem.clear();
    plusAssem.clear();
    keepAssem.clear();
    assem.clear();
    lengthChange = 0;
  };

  const endDocument = () => {
    keepAssem.endDocument();
  };

  const getLengthChange = () => lengthChange;

  return {
    append,
    toString,
    clear,
    endDocument,
    appendOpWithText,
    getLengthChange,
  };
};

/**
 * @returns {MergingOpAssembler}
 */
exports.mergingOpAssembler = () => {
  const assem = exports.opAssembler();
  const bufOp = new Op();

  // If we get, for example, insertions [xxx\n,yyy], those don't merge,
  // but if we get [xxx\n,yyy,zzz\n], that merges to [xxx\nyyyzzz\n].
  // This variable stores the length of yyy and any other newline-less
  // ops immediately after it.
  let bufOpAdditionalCharsAfterNewline = 0;

  /**
   * @param {boolean} [isEndDocument]
   */
  const flush = (isEndDocument) => {
    if (!bufOp.opcode) return;
    if (isEndDocument && bufOp.opcode === '=' && !bufOp.attribs) {
      // final merged keep, leave it implicit
    } else {
      assem.append(bufOp);
      if (bufOpAdditionalCharsAfterNewline) {
        bufOp.chars = bufOpAdditionalCharsAfterNewline;
        bufOp.lines = 0;
        assem.append(bufOp);
        bufOpAdditionalCharsAfterNewline = 0;
      }
    }
    bufOp.opcode = '';
  };

  const append = (op) => {
    if (op.chars <= 0) return;
    if (bufOp.opcode === op.opcode && bufOp.attribs === op.attribs) {
      if (op.lines > 0) {
        // bufOp and additional chars are all mergeable into a multi-line op
        bufOp.chars += bufOpAdditionalCharsAfterNewline + op.chars;
        bufOp.lines += op.lines;
        bufOpAdditionalCharsAfterNewline = 0;
      } else if (bufOp.lines === 0) {
        // both bufOp and op are in-line
        bufOp.chars += op.chars;
      } else {
        // append in-line text to multi-line bufOp
        bufOpAdditionalCharsAfterNewline += op.chars;
      }
    } else {
      flush();
      copyOp(op, bufOp);
    }
  };

  const endDocument = () => {
    flush(true);
  };

  const toString = () => {
    flush();
    return assem.toString();
  };

  const clear = () => {
    assem.clear();
    clearOp(bufOp);
  };
  return {
    append,
    toString,
    clear,
    endDocument,
  };
};

/**
 * @returns {OpAssembler}
 */
exports.opAssembler = () => {
  let serialized = '';

  /**
   * @param {Op} op - Operation to add. Ownership remains with the caller.
   */
  const append = (op) => {
    assert(op instanceof Op, 'argument must be an instance of Op');
    serialized += op.toString();
  };

  const toString = () => serialized;

  const clear = () => {
    serialized = '';
  };
  return {
    append,
    toString,
    clear,
  };
};

/**
 * A custom made String Iterator
 *
 * @typedef {object} StringIterator
 * @property {Function} newlines -
 * @property {Function} peek -
 * @property {Function} remaining -
 * @property {Function} skip -
 * @property {Function} take -
 */

/**
 * @param {string} str - String to iterate over
 * @returns {StringIterator}
 */
exports.stringIterator = (str) => {
  let curIndex = 0;
  // newLines is the number of \n between curIndex and str.length
  let newLines = str.split('\n').length - 1;
  const getnewLines = () => newLines;

  const assertRemaining = (n) => {
    assert(n <= remaining(), `!(${n} <= ${remaining()})`);
  };

  const take = (n) => {
    assertRemaining(n);
    const s = str.substr(curIndex, n);
    newLines -= s.split('\n').length - 1;
    curIndex += n;
    return s;
  };

  const peek = (n) => {
    assertRemaining(n);
    const s = str.substr(curIndex, n);
    return s;
  };

  const skip = (n) => {
    assertRemaining(n);
    curIndex += n;
  };

  const remaining = () => str.length - curIndex;
  return {
    take,
    skip,
    remaining,
    peek,
    newlines: getnewLines,
  };
};

/**
 * A custom made StringBuffer
 *
 * @typedef {object} StringAssembler
 * @property {Function} append -
 * @property {Function} toString -
 */

/**
 * @returns {StringAssembler}
 */
exports.stringAssembler = () => ({
  _str: '',
  clear() { this._str = ''; },
  /**
   * @param {string} x -
   */
  append(x) { this._str += String(x); },
  toString() { return this._str; },
});

/**
 * @typedef {object} StringArrayLike
 * @property {(i: number) => string} get - Returns the line at index `i`.
 * @property {(number|(() => number))} length - The number of lines, or a method that returns the
 *     number of lines.
 * @property {(((start?: number, end?: number) => string[])|undefined)} slice - Like
 *     `Array.prototype.slice()`. Optional if the return value of the `removeLines` method is not
 *     needed.
 * @property {(i: number, d?: number, ...l: string[]) => any} splice - Like
 *     `Array.prototype.splice()`.
 */

/**
 * Class to iterate and modify texts which have several lines. It is used for applying Changesets on
 * arrays of lines.
 *
 * Mutation operations have the same constraints as exports operations with respect to newlines, but
 * not the other additional constraints (i.e. ins/del ordering, forbidden no-ops, non-mergeability,
 * final newline). Can be used to mutate lists of strings where the last char of each string is not
 * actually a newline, but for the purposes of N and L values, the caller should pretend it is, and
 * for things to work right in that case, the input to the `insert` method should be a single line
 * with no newlines.
 */
class TextLinesMutator {
  /**
   * @param {(string[]|StringArrayLike)} lines - Lines to mutate (in place).
   */
  constructor(lines) {
    this._lines = lines;
    /**
     * this._curSplice holds values that will be passed as arguments to this._lines.splice() to
     * insert, delete, or change lines:
     *   - this._curSplice[0] is an index into the this._lines array.
     *   - this._curSplice[1] is the number of lines that will be removed from the this._lines array
     *     starting at the index.
     *   - The other elements represent mutated (changed by ops) lines or new lines (added by ops)
     *     to insert at the index.
     *
     * @type {[number, number?, ...string[]?]}
     */
    this._curSplice = [0, 0];
    this._inSplice = false;
    // position in lines after curSplice is applied:
    this._curLine = 0;
    this._curCol = 0;
    // invariant: if (inSplice) then (curLine is in curSplice[0] + curSplice.length - {2,3}) &&
    //            curLine >= curSplice[0]
    // invariant: if (inSplice && (curLine >= curSplice[0] + curSplice.length - 2)) then
    //            curCol == 0
  }

  /**
   * Get a line from `lines` at given index.
   *
   * @param {number} idx - an index
   * @returns {string}
   */
  _linesGet(idx) {
    if ('get' in this._lines) {
      return this._lines.get(idx);
    } else {
      return this._lines[idx];
    }
  }

  /**
   * Return a slice from `lines`.
   *
   * @param {number} start - the start index
   * @param {number} end - the end index
   * @returns {string[]}
   */
  _linesSlice(start, end) {
    // can be unimplemented if removeLines's return value not needed
    if (this._lines.slice) {
      return this._lines.slice(start, end);
    } else {
      return [];
    }
  }

  /**
   * Return the length of `lines`.
   *
   * @returns {number}
   */
  _linesLength() {
    if (typeof this._lines.length === 'number') {
      return this._lines.length;
    } else {
      return this._lines.length();
    }
  }

  /**
   * Starts a new splice.
   */
  _enterSplice() {
    this._curSplice[0] = this._curLine;
    this._curSplice[1] = 0;
    // TODO(doc) when is this the case?
    //           check all enterSplice calls and changes to curCol
    if (this._curCol > 0) this._putCurLineInSplice();
    this._inSplice = true;
  }

  /**
   * Changes the lines array according to the values in curSplice and resets curSplice. Called via
   * close or TODO(doc).
   */
  _leaveSplice() {
    this._lines.splice(...this._curSplice);
    this._curSplice.length = 2;
    this._curSplice[0] = this._curSplice[1] = 0;
    this._inSplice = false;
  }

  /**
   * Indicates if curLine is already in the splice. This is necessary because the last element in
   * curSplice is curLine when this line is currently worked on (e.g. when skipping or inserting).
   *
   * @returns {boolean} true if curLine is in splice
   */
  _isCurLineInSplice() {
    // The value of `this._curSplice[1]` does not matter when determining the return value because
    // `this._curLine` refers to the line number *after* the splice is applied (so after those lines
    // are deleted).
    return this._curLine - this._curSplice[0] < this._curSplice.length - 2;
  }

  /**
   * Incorporates current line into the splice and marks its old position to be deleted.
   *
   * @returns {number} the index of the added line in curSplice
   */
  _putCurLineInSplice() {
    if (!this._isCurLineInSplice()) {
      this._curSplice.push(this._linesGet(this._curSplice[0] + this._curSplice[1]));
      this._curSplice[1]++;
    }
    // TODO should be the same as this._curSplice.length - 1
    return 2 + this._curLine - this._curSplice[0];
  }

  /**
   * It will skip some newlines by putting them into the splice.
   *
   * @param {number} L -
   * @param {boolean} includeInSplice - Indicates that attributes are present.
   */
  skipLines(L, includeInSplice) {
    if (!L) return;
    if (includeInSplice) {
      if (!this._inSplice) this._enterSplice();
      // TODO(doc) should this count the number of characters that are skipped to check?
      for (let i = 0; i < L; i++) {
        this._curCol = 0;
        this._putCurLineInSplice();
        this._curLine++;
      }
    } else {
      if (this._inSplice) {
        if (L > 1) {
          // TODO(doc) figure out why single lines are incorporated into splice instead of ignored
          this._leaveSplice();
        } else {
          this._putCurLineInSplice();
        }
      }
      this._curLine += L;
      this._curCol = 0;
    }
    // tests case foo in remove(), which isn't otherwise covered in current impl
  }

  /**
   * Skip some characters. Can contain newlines.
   *
   * @param {number} N - number of characters to skip
   * @param {number} L - number of newlines to skip
   * @param {boolean} includeInSplice - indicates if attributes are present
   */
  skip(N, L, includeInSplice) {
    if (!N) return;
    if (L) {
      this.skipLines(L, includeInSplice);
    } else {
      if (includeInSplice && !this._inSplice) this._enterSplice();
      if (this._inSplice) {
        // although the line is put into splice curLine is not increased, because
        // only some chars are skipped, not the whole line
        this._putCurLineInSplice();
      }
      this._curCol += N;
    }
  }

  /**
   * Remove whole lines from lines array.
   *
   * @param {number} L - number of lines to remove
   * @returns {string}
   */
  removeLines(L) {
    if (!L) return '';
    if (!this._inSplice) this._enterSplice();

    /**
     * Gets a string of joined lines after the end of the splice.
     *
     * @param {number} k - number of lines
     * @returns {string} joined lines
     */
    const nextKLinesText = (k) => {
      const m = this._curSplice[0] + this._curSplice[1];
      return this._linesSlice(m, m + k).join('');
    };

    let removed = '';
    if (this._isCurLineInSplice()) {
      if (this._curCol === 0) {
        removed = this._curSplice[this._curSplice.length - 1];
        this._curSplice.length--;
        removed += nextKLinesText(L - 1);
        this._curSplice[1] += L - 1;
      } else {
        removed = nextKLinesText(L - 1);
        this._curSplice[1] += L - 1;
        const sline = this._curSplice.length - 1;
        removed = this._curSplice[sline].substring(this._curCol) + removed;
        this._curSplice[sline] = this._curSplice[sline].substring(0, this._curCol) +
            this._linesGet(this._curSplice[0] + this._curSplice[1]);
        this._curSplice[1] += 1;
      }
    } else {
      removed = nextKLinesText(L);
      this._curSplice[1] += L;
    }
    return removed;
  }

  /**
   * Remove text from lines array.
   *
   * @param {number} N - characters to delete
   * @param {number} L - lines to delete
   * @returns {string}
   */
  remove(N, L) {
    if (!N) return '';
    if (L) return this.removeLines(L);
    if (!this._inSplice) this._enterSplice();
    // although the line is put into splice, curLine is not increased, because
    // only some chars are removed not the whole line
    const sline = this._putCurLineInSplice();
    const removed = this._curSplice[sline].substring(this._curCol, this._curCol + N);
    this._curSplice[sline] = this._curSplice[sline].substring(0, this._curCol) +
        this._curSplice[sline].substring(this._curCol + N);
    return removed;
  }

  /**
   * Inserts text into lines array.
   *
   * @param {string} text - the text to insert
   * @param {number} L - number of newlines in text
   */
  insert(text, L) {
    if (!text) return;
    if (!this._inSplice) this._enterSplice();
    if (L) {
      const newLines = exports.splitTextLines(text);
      if (this._isCurLineInSplice()) {
        const sline = this._curSplice.length - 1;
        /** @type {string} */
        const theLine = this._curSplice[sline];
        const lineCol = this._curCol;
        // Insert the chars up to `curCol` and the first new line.
        this._curSplice[sline] = theLine.substring(0, lineCol) + newLines[0];
        this._curLine++;
        newLines.splice(0, 1);
        // insert the remaining new lines
        this._curSplice.push(...newLines);
        this._curLine += newLines.length;
        // insert the remaining chars from the "old" line (e.g. the line we were in
        // when we started to insert new lines)
        this._curSplice.push(theLine.substring(lineCol));
        this._curCol = 0; // TODO(doc) why is this not set to the length of last line?
      } else {
        this._curSplice.push(...newLines);
        this._curLine += newLines.length;
      }
    } else {
      // There are no additional lines. Although the line is put into splice, curLine is not
      // increased because there may be more chars in the line (newline is not reached).
      const sline = this._putCurLineInSplice();
      if (!this._curSplice[sline]) {
        const err = new Error(
            'curSplice[sline] not populated, actual curSplice contents is ' +
            `${JSON.stringify(this._curSplice)}. Possibly related to ` +
            'https://github.com/ether/etherpad-lite/issues/2802');
        console.error(err.stack || err.toString());
      }
      this._curSplice[sline] = this._curSplice[sline].substring(0, this._curCol) + text +
          this._curSplice[sline].substring(this._curCol);
      this._curCol += text.length;
    }
  }

  /**
   * Checks if curLine (the line we are in when curSplice is applied) is the last line in `lines`.
   *
   * @returns {boolean} indicates if there are lines left
   */
  hasMore() {
    let docLines = this._linesLength();
    if (this._inSplice) {
      docLines += this._curSplice.length - 2 - this._curSplice[1];
    }
    return this._curLine < docLines;
  }

  /**
   * Closes the splice
   */
  close() {
    if (this._inSplice) this._leaveSplice();
  }
}

/**
 * Apply operations to other operations.
 *
 * @param {string} in1 - first Op string
 * @param {string} in2 - second Op string
 * @param {Function} func - Callback that applies an operation to another operation. Will be called
 *     multiple times depending on the number of operations in `in1` and `in2`. `func` has signature
 *     `opOut = f(op1, op2)`:
 *       - `op1` is the current operation from `in1`. `func` is expected to mutate `op1` to
 *         partially or fully consume it, and MUST set `op1.opcode` to the empty string once `op1`
 *         is fully consumed. If `op1` is not fully consumed, `func` will be called again with the
 *         same `op1` value. If `op1` is fully consumed, the next call to `func` will be given the
 *         next operation from `in1`. If there are no more operations in `in1`, `op1.opcode` will be
 *         the empty string.
 *       - `op2` is the current operation from `in2`, to apply to `op1`. Has the same consumption
 *         and advancement semantics as `op1`.
 *       - `opOut` is the result of applying `op2` (before consumption) to `op1` (before
 *         consumption). If there is no result (perhaps `op1` and `op2` cancelled each other out),
 *         either `opOut` must be nullish or `opOut.opcode` must be the empty string.
 * @returns {string} the integrated changeset
 */
const applyZip = (in1, in2, func) => {
  const ops1 = exports.deserializeOps(in1);
  const ops2 = exports.deserializeOps(in2);
  let next1 = ops1.next();
  let next2 = ops2.next();
  const assem = exports.smartOpAssembler();
  while (!next1.done || !next2.done) {
    if (!next1.done && !next1.value.opcode) next1 = ops1.next();
    if (!next2.done && !next2.value.opcode) next2 = ops2.next();
    if (next1.value == null) next1.value = new Op();
    if (next2.value == null) next2.value = new Op();
    if (!next1.value.opcode && !next2.value.opcode) break;
    const opOut = func(next1.value, next2.value);
    if (opOut && opOut.opcode) assem.append(opOut);
  }
  assem.endDocument();
  return assem.toString();
};

/**
 * Parses an encoded changeset.
 *
 * @param {string} cs - The encoded changeset.
 * @returns {Changeset}
 */
exports.unpack = (cs) => {
  const headerRegex = /Z:([0-9a-z]+)([><])([0-9a-z]+)|/;
  const headerMatch = headerRegex.exec(cs);
  if ((!headerMatch) || (!headerMatch[0])) error(`Not a changeset: ${cs}`);
  const oldLen = exports.parseNum(headerMatch[1]);
  const changeSign = (headerMatch[2] === '>') ? 1 : -1;
  const changeMag = exports.parseNum(headerMatch[3]);
  const newLen = oldLen + changeSign * changeMag;
  const opsStart = headerMatch[0].length;
  let opsEnd = cs.indexOf('$');
  if (opsEnd < 0) opsEnd = cs.length;
  return {
    oldLen,
    newLen,
    ops: cs.substring(opsStart, opsEnd),
    charBank: cs.substring(opsEnd + 1),
  };
};

/**
 * Creates an encoded changeset.
 *
 * @param {number} oldLen - The length of the document before applying the changeset.
 * @param {number} newLen - The length of the document after applying the changeset.
 * @param {string} opsStr - Encoded operations to apply to the document.
 * @param {string} bank - Characters for insert operations.
 * @returns {string} The encoded changeset.
 */
exports.pack = (oldLen, newLen, opsStr, bank) => {
  const lenDiff = newLen - oldLen;
  const lenDiffStr = (lenDiff >= 0 ? `>${exports.numToString(lenDiff)}`
    : `<${exports.numToString(-lenDiff)}`);
  const a = [];
  a.push('Z:', exports.numToString(oldLen), lenDiffStr, opsStr, '$', bank);
  return a.join('');
};

/**
 * Applies a Changeset to a string.
 *
 * @param {string} cs - String encoded Changeset
 * @param {string} str - String to which a Changeset should be applied
 * @returns {string}
 */
exports.applyToText = (cs, str) => {
  const unpacked = exports.unpack(cs);
  assert(str.length === unpacked.oldLen, `mismatched apply: ${str.length} / ${unpacked.oldLen}`);
  const bankIter = exports.stringIterator(unpacked.charBank);
  const strIter = exports.stringIterator(str);
  const assem = exports.stringAssembler();
  for (const op of exports.deserializeOps(unpacked.ops)) {
    switch (op.opcode) {
      case '+':
      // op is + and op.lines 0: no newlines must be in op.chars
      // op is + and op.lines >0: op.chars must include op.lines newlines
        if (op.lines !== bankIter.peek(op.chars).split('\n').length - 1) {
          throw new Error(`newline count is wrong in op +; cs:${cs} and text:${str}`);
        }
        assem.append(bankIter.take(op.chars));
        break;
      case '-':
      // op is - and op.lines 0: no newlines must be in the deleted string
      // op is - and op.lines >0: op.lines newlines must be in the deleted string
        if (op.lines !== strIter.peek(op.chars).split('\n').length - 1) {
          throw new Error(`newline count is wrong in op -; cs:${cs} and text:${str}`);
        }
        strIter.skip(op.chars);
        break;
      case '=':
      // op is = and op.lines 0: no newlines must be in the copied string
      // op is = and op.lines >0: op.lines newlines must be in the copied string
        if (op.lines !== strIter.peek(op.chars).split('\n').length - 1) {
          throw new Error(`newline count is wrong in op =; cs:${cs} and text:${str}`);
        }
        assem.append(strIter.take(op.chars));
        break;
    }
  }
  assem.append(strIter.take(strIter.remaining()));
  return assem.toString();
};

/**
 * Applies a changeset on an array of lines.
 *
 * @param {string} cs - the changeset to apply
 * @param {string[]} lines - The lines to which the changeset needs to be applied
 */
exports.mutateTextLines = (cs, lines) => {
  const unpacked = exports.unpack(cs);
  const bankIter = exports.stringIterator(unpacked.charBank);
  const mut = new TextLinesMutator(lines);
  for (const op of exports.deserializeOps(unpacked.ops)) {
    switch (op.opcode) {
      case '+':
        mut.insert(bankIter.take(op.chars), op.lines);
        break;
      case '-':
        mut.remove(op.chars, op.lines);
        break;
      case '=':
        mut.skip(op.chars, op.lines, (!!op.attribs));
        break;
    }
  }
  mut.close();
};

/**
 * Composes two attribute strings (see below) into one.
 *
 * @param {AttributeString} att1 - first attribute string
 * @param {AttributeString} att2 - second attribue string
 * @param {boolean} resultIsMutation -
 * @param {AttributePool} pool - attribute pool
 * @returns {string}
 */
exports.composeAttributes = (att1, att2, resultIsMutation, pool) => {
  // att1 and att2 are strings like "*3*f*1c", asMutation is a boolean.
  // Sometimes attribute (key,value) pairs are treated as attribute presence
  // information, while other times they are treated as operations that
  // mutate a set of attributes, and this affects whether an empty value
  // is a deletion or a change.
  // Examples, of the form (att1Items, att2Items, resultIsMutation) -> result
  // ([], [(bold, )], true) -> [(bold, )]
  // ([], [(bold, )], false) -> []
  // ([], [(bold, true)], true) -> [(bold, true)]
  // ([], [(bold, true)], false) -> [(bold, true)]
  // ([(bold, true)], [(bold, )], true) -> [(bold, )]
  // ([(bold, true)], [(bold, )], false) -> []
  // pool can be null if att2 has no attributes.
  if ((!att1) && resultIsMutation) {
    // In the case of a mutation (i.e. composing two exportss),
    // an att2 composed with an empy att1 is just att2.  If att1
    // is part of an attribution string, then att2 may remove
    // attributes that are already gone, so don't do this optimization.
    return att2;
  }
  if (!att2) return att1;
  return AttributeMap.fromString(att1, pool).updateFromString(att2, !resultIsMutation).toString();
};

/**
 * Function used as parameter for applyZip to apply a Changeset to an attribute.
 *
 * @param {Op} attOp - The op from the sequence that is being operated on, either an attribution
 *     string or the earlier of two exportss being composed.
 * @param {Op} csOp -
 * @param {AttributePool} pool - Can be null if definitely not needed.
 * @returns {Op} The result of applying `csOp` to `attOp`.
 */
const slicerZipperFunc = (attOp, csOp, pool) => {
  const opOut = new Op();
  if (!attOp.opcode) {
    copyOp(csOp, opOut);
    csOp.opcode = '';
  } else if (!csOp.opcode) {
    copyOp(attOp, opOut);
    attOp.opcode = '';
  } else if (attOp.opcode === '-') {
    copyOp(attOp, opOut);
    attOp.opcode = '';
  } else if (csOp.opcode === '+') {
    copyOp(csOp, opOut);
    csOp.opcode = '';
  } else {
    for (const op of [attOp, csOp]) {
      assert(op.chars >= op.lines, `op has more newlines than chars: ${op.toString()}`);
    }
    assert(
        attOp.chars < csOp.chars ? attOp.lines <= csOp.lines
        : attOp.chars > csOp.chars ? attOp.lines >= csOp.lines
        : attOp.lines === csOp.lines,
        'line count mismatch when composing changesets A*B; ' +
        `opA: ${attOp.toString()} opB: ${csOp.toString()}`);
    assert(['+', '='].includes(attOp.opcode), `unexpected opcode in op: ${attOp.toString()}`);
    assert(['-', '='].includes(csOp.opcode), `unexpected opcode in op: ${csOp.toString()}`);
    opOut.opcode = {
      '+': {
        '-': '', // The '-' cancels out (some of) the '+', leaving any remainder for the next call.
        '=': '+',
      },
      '=': {
        '-': '-',
        '=': '=',
      },
    }[attOp.opcode][csOp.opcode];
    const [fullyConsumedOp, partiallyConsumedOp] = [attOp, csOp].sort((a, b) => a.chars - b.chars);
    opOut.chars = fullyConsumedOp.chars;
    opOut.lines = fullyConsumedOp.lines;
    opOut.attribs = csOp.opcode === '-'
      // csOp is a remove op and remove ops normally never have any attributes, so this should
      // normally be the empty string. However, padDiff.js adds attributes to remove ops and needs
      // them preserved so they are copied here.
      ? csOp.attribs
      : exports.composeAttributes(attOp.attribs, csOp.attribs, attOp.opcode === '=', pool);
    partiallyConsumedOp.chars -= fullyConsumedOp.chars;
    partiallyConsumedOp.lines -= fullyConsumedOp.lines;
    if (!partiallyConsumedOp.chars) partiallyConsumedOp.opcode = '';
    fullyConsumedOp.opcode = '';
  }
  return opOut;
};

/**
 * Applies a Changeset to the attribs string of a AText.
 *
 * @param {string} cs - Changeset
 * @param {string} astr - the attribs string of a AText
 * @param {AttributePool} pool - the attibutes pool
 * @returns {string}
 */
exports.applyToAttribution = (cs, astr, pool) => {
  const unpacked = exports.unpack(cs);
  return applyZip(astr, unpacked.ops, (op1, op2) => slicerZipperFunc(op1, op2, pool));
};

/**
 * Applies a changeset to an array of attribute lines.
 *
 * @param {string} cs - The encoded changeset.
 * @param {Array<string>} lines - Attribute lines. Modified in place.
 * @param {AttributePool} pool - Attribute pool.
 */
exports.mutateAttributionLines = (cs, lines, pool) => {
  const unpacked = exports.unpack(cs);
  const csOps = exports.deserializeOps(unpacked.ops);
  let csOpsNext = csOps.next();
  const csBank = unpacked.charBank;
  let csBankIndex = 0;
  // treat the attribution lines as text lines, mutating a line at a time
  const mut = new TextLinesMutator(lines);

  /**
   * The Ops in the current line from `lines`.
   *
   * @type {?Generator<Op>}
   */
  let lineOps = null;
  let lineOpsNext = null;

  const lineOpsHasNext = () => lineOpsNext && !lineOpsNext.done;
  /**
   * Returns false if we are on the last attribute line in `lines` and there is no additional op in
   * that line.
   *
   * @returns {boolean} True if there are more ops to go through.
   */
  const isNextMutOp = () => lineOpsHasNext() || mut.hasMore();

  /**
   * @returns {Op} The next Op from `lineIter`. If there are no more Ops, `lineIter` is reset to
   *     iterate over the next line, which is consumed from `mut`. If there are no more lines,
   *     returns a null Op.
   */
  const nextMutOp = () => {
    if (!lineOpsHasNext() && mut.hasMore()) {
      // There are more attribute lines in `lines` to do AND either we just started so `lineIter` is
      // still null or there are no more ops in current `lineIter`.
      const line = mut.removeLines(1);
      lineOps = exports.deserializeOps(line);
      lineOpsNext = lineOps.next();
    }
    if (!lineOpsHasNext()) return new Op(); // No more ops and no more lines.
    const op = lineOpsNext.value;
    lineOpsNext = lineOps.next();
    return op;
  };
  let lineAssem = null;

  /**
   * Appends an op to `lineAssem`. In case `lineAssem` includes one single newline, adds it to the
   * `lines` mutator.
   */
  const outputMutOp = (op) => {
    if (!lineAssem) {
      lineAssem = exports.mergingOpAssembler();
    }
    lineAssem.append(op);
    if (op.lines <= 0) return;
    assert(op.lines === 1, `Can't have op.lines of ${op.lines} in attribution lines`);
    // ship it to the mut
    mut.insert(lineAssem.toString(), 1);
    lineAssem = null;
  };

  let csOp = new Op();
  let attOp = new Op();
  while (csOp.opcode || !csOpsNext.done || attOp.opcode || isNextMutOp()) {
    if (!csOp.opcode && !csOpsNext.done) {
      // coOp done, but more ops in cs.
      csOp = csOpsNext.value;
      csOpsNext = csOps.next();
    }
    if (!csOp.opcode && !attOp.opcode && !lineAssem && !lineOpsHasNext()) {
      break; // done
    } else if (csOp.opcode === '=' && csOp.lines > 0 && !csOp.attribs && !attOp.opcode &&
               !lineAssem && !lineOpsHasNext()) {
      // Skip multiple lines without attributes; this is what makes small changes not order of the
      // document size.
      mut.skipLines(csOp.lines);
      csOp.opcode = '';
    } else if (csOp.opcode === '+') {
      const opOut = copyOp(csOp);
      if (csOp.lines > 1) {
        // Copy the first line from `csOp` to `opOut`.
        const firstLineLen = csBank.indexOf('\n', csBankIndex) + 1 - csBankIndex;
        csOp.chars -= firstLineLen;
        csOp.lines--;
        opOut.lines = 1;
        opOut.chars = firstLineLen;
      } else {
        // Either one or no newlines in '+' `csOp`, copy to `opOut` and reset `csOp`.
        csOp.opcode = '';
      }
      outputMutOp(opOut);
      csBankIndex += opOut.chars;
    } else {
      if (!attOp.opcode && isNextMutOp()) attOp = nextMutOp();
      const opOut = slicerZipperFunc(attOp, csOp, pool);
      if (opOut.opcode) outputMutOp(opOut);
    }
  }

  assert(!lineAssem, `line assembler not finished:${cs}`);
  mut.close();
};

/**
 * Joins several Attribution lines.
 *
 * @param {string[]} theAlines - collection of Attribution lines
 * @returns {string} joined Attribution lines
 */
exports.joinAttributionLines = (theAlines) => {
  const assem = exports.mergingOpAssembler();
  for (const aline of theAlines) {
    for (const op of exports.deserializeOps(aline)) assem.append(op);
  }
  return assem.toString();
};

exports.splitAttributionLines = (attrOps, text) => {
  const assem = exports.mergingOpAssembler();
  const lines = [];
  let pos = 0;

  const appendOp = (op) => {
    assem.append(op);
    if (op.lines > 0) {
      lines.push(assem.toString());
      assem.clear();
    }
    pos += op.chars;
  };

  for (const op of exports.deserializeOps(attrOps)) {
    let numChars = op.chars;
    let numLines = op.lines;
    while (numLines > 1) {
      const newlineEnd = text.indexOf('\n', pos) + 1;
      assert(newlineEnd > 0, 'newlineEnd <= 0 in splitAttributionLines');
      op.chars = newlineEnd - pos;
      op.lines = 1;
      appendOp(op);
      numChars -= op.chars;
      numLines -= op.lines;
    }
    if (numLines === 1) {
      op.chars = numChars;
      op.lines = 1;
    }
    appendOp(op);
  }

  return lines;
};

/**
 * Splits text into lines.
 *
 * @param {string} text - text to split
 * @returns {string[]}
 */
exports.splitTextLines = (text) => text.match(/[^\n]*(?:\n|[^\n]$)/g);

/**
 * Compose two Changesets.
 *
 * @param {string} cs1 - first Changeset
 * @param {string} cs2 - second Changeset
 * @param {AttributePool} pool - Attribs pool
 * @returns {string}
 */
exports.compose = (cs1, cs2, pool) => {
  const unpacked1 = exports.unpack(cs1);
  const unpacked2 = exports.unpack(cs2);
  const len1 = unpacked1.oldLen;
  const len2 = unpacked1.newLen;
  assert(len2 === unpacked2.oldLen, 'mismatched composition of two changesets');
  const len3 = unpacked2.newLen;
  const bankIter1 = exports.stringIterator(unpacked1.charBank);
  const bankIter2 = exports.stringIterator(unpacked2.charBank);
  const bankAssem = exports.stringAssembler();

  const newOps = applyZip(unpacked1.ops, unpacked2.ops, (op1, op2) => {
    const op1code = op1.opcode;
    const op2code = op2.opcode;
    if (op1code === '+' && op2code === '-') {
      bankIter1.skip(Math.min(op1.chars, op2.chars));
    }
    const opOut = slicerZipperFunc(op1, op2, pool);
    if (opOut.opcode === '+') {
      if (op2code === '+') {
        bankAssem.append(bankIter2.take(opOut.chars));
      } else {
        bankAssem.append(bankIter1.take(opOut.chars));
      }
    }
    return opOut;
  });

  return exports.pack(len1, len3, newOps, bankAssem.toString());
};

/**
 * Returns a function that tests if a string of attributes (e.g. '*3*4') contains a given attribute
 * key,value that is already present in the pool.
 *
 * @param {Attribute} attribPair - `[key, value]` pair of strings.
 * @param {AttributePool} pool - Attribute pool
 * @returns {Function}
 */
exports.attributeTester = (attribPair, pool) => {
  const never = (attribs) => false;
  if (!pool) return never;
  const attribNum = pool.putAttrib(attribPair, true);
  if (attribNum < 0) return never;
  const re = new RegExp(`\\*${exports.numToString(attribNum)}(?!\\w)`);
  return (attribs) => re.test(attribs);
};

/**
 * Creates the identity Changeset of length N.
 *
 * @param {number} N - length of the identity changeset
 * @returns {string}
 */
exports.identity = (N) => exports.pack(N, N, '', '');

/**
 * Creates a Changeset which works on oldFullText and removes text from spliceStart to
 * spliceStart+numRemoved and inserts newText instead. Also gives possibility to add attributes
 * optNewTextAPairs for the new text.
 *
 * @param {string} orig - Original text.
 * @param {number} start - Index into `orig` where characters should be removed and inserted.
 * @param {number} ndel - Number of characters to delete at `start`.
 * @param {string} ins - Text to insert at `start` (after deleting `ndel` characters).
 * @param {string} [attribs] - Optional attributes to apply to the inserted text.
 * @param {AttributePool} [pool] - Attribute pool.
 * @returns {string}
 */
exports.makeSplice = (orig, start, ndel, ins, attribs, pool) => {
  if (start < 0) throw new RangeError(`start index must be non-negative (is ${start})`);
  if (ndel < 0) throw new RangeError(`characters to delete must be non-negative (is ${ndel})`);
  if (start > orig.length) start = orig.length;
  if (ndel > orig.length - start) ndel = orig.length - start;
  const deleted = orig.substring(start, start + ndel);
  const assem = exports.smartOpAssembler();
  const ops = (function* () {
    yield* opsFromText('=', orig.substring(0, start));
    yield* opsFromText('-', deleted);
    yield* opsFromText('+', ins, attribs, pool);
  })();
  for (const op of ops) assem.append(op);
  assem.endDocument();
  return exports.pack(orig.length, orig.length + ins.length - ndel, assem.toString(), ins);
};

/**
 * Transforms a changeset into a list of splices in the form [startChar, endChar, newText] meaning
 * replace text from startChar to endChar with newText.
 *
 * @param {string} cs - Changeset
 * @returns {[number, number, string][]}
 */
const toSplices = (cs) => {
  const unpacked = exports.unpack(cs);
  /** @type {[number, number, string][]} */
  const splices = [];

  let oldPos = 0;
  const charIter = exports.stringIterator(unpacked.charBank);
  let inSplice = false;
  for (const op of exports.deserializeOps(unpacked.ops)) {
    if (op.opcode === '=') {
      oldPos += op.chars;
      inSplice = false;
    } else {
      if (!inSplice) {
        splices.push([oldPos, oldPos, '']);
        inSplice = true;
      }
      if (op.opcode === '-') {
        oldPos += op.chars;
        splices[splices.length - 1][1] += op.chars;
      } else if (op.opcode === '+') {
        splices[splices.length - 1][2] += charIter.take(op.chars);
      }
    }
  }

  return splices;
};

/**
 * @param {string} cs -
 * @param {number} startChar -
 * @param {number} endChar -
 * @param {number} insertionsAfter -
 * @returns {[number, number]}
 */
exports.characterRangeFollow = (cs, startChar, endChar, insertionsAfter) => {
  let newStartChar = startChar;
  let newEndChar = endChar;
  let lengthChangeSoFar = 0;
  for (const splice of toSplices(cs)) {
    const spliceStart = splice[0] + lengthChangeSoFar;
    const spliceEnd = splice[1] + lengthChangeSoFar;
    const newTextLength = splice[2].length;
    const thisLengthChange = newTextLength - (spliceEnd - spliceStart);

    if (spliceStart <= newStartChar && spliceEnd >= newEndChar) {
      // splice fully replaces/deletes range
      // (also case that handles insertion at a collapsed selection)
      if (insertionsAfter) {
        newStartChar = newEndChar = spliceStart;
      } else {
        newStartChar = newEndChar = spliceStart + newTextLength;
      }
    } else if (spliceEnd <= newStartChar) {
      // splice is before range
      newStartChar += thisLengthChange;
      newEndChar += thisLengthChange;
    } else if (spliceStart >= newEndChar) {
      // splice is after range
    } else if (spliceStart >= newStartChar && spliceEnd <= newEndChar) {
      // splice is inside range
      newEndChar += thisLengthChange;
    } else if (spliceEnd < newEndChar) {
      // splice overlaps beginning of range
      newStartChar = spliceStart + newTextLength;
      newEndChar += thisLengthChange;
    } else {
      // splice overlaps end of range
      newEndChar = spliceStart;
    }

    lengthChangeSoFar += thisLengthChange;
  }

  return [newStartChar, newEndChar];
};

/**
 * Iterate over attributes in a changeset and move them from oldPool to newPool.
 *
 * @param {string} cs - Chageset/attribution string to iterate over
 * @param {AttributePool} oldPool - old attributes pool
 * @param {AttributePool} newPool - new attributes pool
 * @returns {string} the new Changeset
 */
exports.moveOpsToNewPool = (cs, oldPool, newPool) => {
  // works on exports or attribution string
  let dollarPos = cs.indexOf('$');
  if (dollarPos < 0) {
    dollarPos = cs.length;
  }
  const upToDollar = cs.substring(0, dollarPos);
  const fromDollar = cs.substring(dollarPos);
  // order of attribs stays the same
  return upToDollar.replace(/\*([0-9a-z]+)/g, (_, a) => {
    const oldNum = exports.parseNum(a);
    const pair = oldPool.getAttrib(oldNum);
    // The attribute might not be in the old pool if the user is viewing the current revision in the
    // timeslider and text is deleted. See: https://github.com/ether/etherpad-lite/issues/3932
    if (!pair) return '';
    const newNum = newPool.putAttrib(pair);
    return `*${exports.numToString(newNum)}`;
  }) + fromDollar;
};

/**
 * Create an attribution inserting a text.
 *
 * @param {string} text - text to insert
 * @returns {string}
 */
exports.makeAttribution = (text) => {
  const assem = exports.smartOpAssembler();
  for (const op of opsFromText('+', text)) assem.append(op);
  return assem.toString();
};

/**
 * Iterates over attributes in exports, attribution string, or attribs property of an op and runs
 * function func on them.
 *
 * @deprecated Use `attributes.decodeAttribString()` instead.
 * @param {string} cs - changeset
 * @param {Function} func - function to call
 */
exports.eachAttribNumber = (cs, func) => {
  padutils.warnDeprecated(
      'Changeset.eachAttribNumber() is deprecated; use attributes.decodeAttribString() instead');
  let dollarPos = cs.indexOf('$');
  if (dollarPos < 0) {
    dollarPos = cs.length;
  }
  const upToDollar = cs.substring(0, dollarPos);

  // WARNING: The following cannot be replaced with a call to `attributes.decodeAttribString()`
  // because that function only works on attribute strings, not serialized operations or changesets.
  upToDollar.replace(/\*([0-9a-z]+)/g, (_, a) => {
    func(exports.parseNum(a));
    return '';
  });
};

/**
 * Filter attributes which should remain in a Changeset. Callable on a exports, attribution string,
 * or attribs property of an op, though it may easily create adjacent ops that can be merged.
 *
 * @param {string} cs - changeset to filter
 * @param {Function} filter - fnc which returns true if an attribute X (int) should be kept in the
 *     Changeset
 * @returns {string}
 */
exports.filterAttribNumbers = (cs, filter) => exports.mapAttribNumbers(cs, filter);

/**
 * Does exactly the same as exports.filterAttribNumbers.
 *
 * @param {string} cs -
 * @param {Function} func -
 * @returns {string}
 */
exports.mapAttribNumbers = (cs, func) => {
  let dollarPos = cs.indexOf('$');
  if (dollarPos < 0) {
    dollarPos = cs.length;
  }
  const upToDollar = cs.substring(0, dollarPos);

  const newUpToDollar = upToDollar.replace(/\*([0-9a-z]+)/g, (s, a) => {
    const n = func(exports.parseNum(a));
    if (n === true) {
      return s;
    } else if ((typeof n) === 'number') {
      return `*${exports.numToString(n)}`;
    } else {
      return '';
    }
  });

  return newUpToDollar + cs.substring(dollarPos);
};

/**
 * Represents text with attributes.
 *
 * @typedef {object} AText
 * @property {string} attribs - Serialized sequence of insert operations that cover the text in
 *     `text`. These operations describe which parts of the text have what attributes.
 * @property {string} text - The text.
 */

/**
 * Create a Changeset going from Identity to a certain state.
 *
 * @param {string} text - text of the final change
 * @param {string} attribs - optional, operations which insert the text and also puts the right
 *     attributes
 * @returns {AText}
 */
exports.makeAText = (text, attribs) => ({
  text,
  attribs: (attribs || exports.makeAttribution(text)),
});

/**
 * Apply a Changeset to a AText.
 *
 * @param {string} cs - Changeset to apply
 * @param {AText} atext -
 * @param {AttributePool} pool - Attribute Pool to add to
 * @returns {AText}
 */
exports.applyToAText = (cs, atext, pool) => ({
  text: exports.applyToText(cs, atext.text),
  attribs: exports.applyToAttribution(cs, atext.attribs, pool),
});

/**
 * Clones a AText structure.
 *
 * @param {AText} atext -
 * @returns {AText}
 */
exports.cloneAText = (atext) => {
  if (!atext) error('atext is null');
  return {
    text: atext.text,
    attribs: atext.attribs,
  };
};

/**
 * Copies a AText structure from atext1 to atext2.
 *
 * @param {AText} atext1 -
 * @param {AText} atext2 -
 */
exports.copyAText = (atext1, atext2) => {
  atext2.text = atext1.text;
  atext2.attribs = atext1.attribs;
};

/**
 * Convert AText to a series of operations. Strips final newline.
 *
 * @param {AText} atext - The AText to convert.
 * @yields {Op}
 * @returns {Generator<Op>}
 */
exports.opsFromAText = function* (atext) {
  // intentionally skips last newline char of atext
  let lastOp = null;
  for (const op of exports.deserializeOps(atext.attribs)) {
    if (lastOp != null) yield lastOp;
    lastOp = op;
  }
  if (lastOp == null) return;
  // exclude final newline
  if (lastOp.lines <= 1) {
    lastOp.lines = 0;
    lastOp.chars--;
  } else {
    const nextToLastNewlineEnd = atext.text.lastIndexOf('\n', atext.text.length - 2) + 1;
    const lastLineLength = atext.text.length - nextToLastNewlineEnd - 1;
    lastOp.lines--;
    lastOp.chars -= (lastLineLength + 1);
    yield copyOp(lastOp);
    lastOp.lines = 0;
    lastOp.chars = lastLineLength;
  }
  if (lastOp.chars) yield lastOp;
};

/**
 * Append the set of operations from atext to an assembler.
 *
 * @deprecated Use `opsFromAText` instead.
 * @param {AText} atext -
 * @param assem - Assembler like SmartOpAssembler TODO add desc
 */
exports.appendATextToAssembler = (atext, assem) => {
  padutils.warnDeprecated(
      'Changeset.appendATextToAssembler() is deprecated; use Changeset.opsFromAText() instead');
  for (const op of exports.opsFromAText(atext)) assem.append(op);
};

/**
 * Creates a clone of a Changeset and it's APool.
 *
 * @param {string} cs -
 * @param {AttributePool} pool -
 * @returns {{translated: string, pool: AttributePool}}
 */
exports.prepareForWire = (cs, pool) => {
  const newPool = new AttributePool();
  const newCs = exports.moveOpsToNewPool(cs, pool, newPool);
  return {
    translated: newCs,
    pool: newPool,
  };
};

/**
 * Checks if a changeset s the identity changeset.
 *
 * @param {string} cs -
 * @returns {boolean}
 */
exports.isIdentity = (cs) => {
  const unpacked = exports.unpack(cs);
  return unpacked.ops === '' && unpacked.oldLen === unpacked.newLen;
};

/**
 * @deprecated Use an AttributeMap instead.
 */
const attribsAttributeValue = (attribs, key, pool) => {
  if (!attribs) return '';
  for (const [k, v] of attributes.attribsFromString(attribs, pool)) {
    if (k === key) return v;
  }
  return '';
};

/**
 * Returns all the values of attributes with a certain key in an Op attribs string.
 *
 * @deprecated Use an AttributeMap instead.
 * @param {Op} op - Op
 * @param {string} key - string to search for
 * @param {AttributePool} pool - attribute pool
 * @returns {string}
 */
exports.opAttributeValue = (op, key, pool) => {
  padutils.warnDeprecated(
      'Changeset.opAttributeValue() is deprecated; use an AttributeMap instead');
  return attribsAttributeValue(op.attribs, key, pool);
};

/**
 * Returns all the values of attributes with a certain key in an attribs string.
 *
 * @deprecated Use an AttributeMap instead.
 * @param {AttributeString} attribs - Attribute string
 * @param {string} key - string to search for
 * @param {AttributePool} pool - attribute pool
 * @returns {string}
 */
exports.attribsAttributeValue = (attribs, key, pool) => {
  padutils.warnDeprecated(
      'Changeset.attribsAttributeValue() is deprecated; use an AttributeMap instead');
  return attribsAttributeValue(attribs, key, pool);
};

/**
 * Incrementally builds a Changeset.
 *
 * @typedef {object} Builder
 * @property {Function} insert -
 * @property {Function} keep -
 * @property {Function} keepText -
 * @property {Function} remove -
 * @property {Function} toString -
 */

/**
 * @param {number} oldLen - Old length
 * @returns {Builder}
 */
exports.builder = (oldLen) => {
  const assem = exports.smartOpAssembler();
  const o = new Op();
  const charBank = exports.stringAssembler();

  const self = {
    /**
     * @param {number} N - Number of characters to keep.
     * @param {number} L - Number of newlines among the `N` characters. If positive, the last
     *     character must be a newline.
     * @param {(string|Attribute[])} attribs - Either [[key1,value1],[key2,value2],...] or '*0*1...'
     *     (no pool needed in latter case).
     * @param {?AttributePool} pool - Attribute pool, only required if `attribs` is a list of
     *     attribute key, value pairs.
     * @returns {Builder} this
     */
    keep: (N, L, attribs, pool) => {
      o.opcode = '=';
      o.attribs = typeof attribs === 'string'
        ? attribs : new AttributeMap(pool).update(attribs || []).toString();
      o.chars = N;
      o.lines = (L || 0);
      assem.append(o);
      return self;
    },

    /**
     * @param {string} text - Text to keep.
     * @param {(string|Attribute[])} attribs - Either [[key1,value1],[key2,value2],...] or '*0*1...'
     *     (no pool needed in latter case).
     * @param {?AttributePool} pool - Attribute pool, only required if `attribs` is a list of
     *     attribute key, value pairs.
     * @returns {Builder} this
     */
    keepText: (text, attribs, pool) => {
      for (const op of opsFromText('=', text, attribs, pool)) assem.append(op);
      return self;
    },

    /**
     * @param {string} text - Text to insert.
     * @param {(string|Attribute[])} attribs - Either [[key1,value1],[key2,value2],...] or '*0*1...'
     *     (no pool needed in latter case).
     * @param {?AttributePool} pool - Attribute pool, only required if `attribs` is a list of
     *     attribute key, value pairs.
     * @returns {Builder} this
     */
    insert: (text, attribs, pool) => {
      for (const op of opsFromText('+', text, attribs, pool)) assem.append(op);
      charBank.append(text);
      return self;
    },

    /**
     * @param {number} N - Number of characters to remove.
     * @param {number} L - Number of newlines among the `N` characters. If positive, the last
     *     character must be a newline.
     * @returns {Builder} this
     */
    remove: (N, L) => {
      o.opcode = '-';
      o.attribs = '';
      o.chars = N;
      o.lines = (L || 0);
      assem.append(o);
      return self;
    },

    toString: () => {
      assem.endDocument();
      const newLen = oldLen + assem.getLengthChange();
      return exports.pack(oldLen, newLen, assem.toString(), charBank.toString());
    },
  };

  return self;
};

/**
 * Constructs an attribute string from a sequence of attributes.
 *
 * @deprecated Use `AttributeMap.prototype.toString()` or `attributes.attribsToString()` instead.
 * @param {string} opcode - The opcode for the Op that will get the resulting attribute string.
 * @param {?(Iterable<Attribute>|AttributeString)} attribs - The attributes to insert into the pool
 *     (if necessary) and encode. If an attribute string, no checking is performed to ensure that
 *     the attributes exist in the pool, are in the canonical order, and contain no duplicate keys.
 *     If this is an iterable of attributes, `pool` must be non-null.
 * @param {AttributePool} pool - Attribute pool. Required if `attribs` is an iterable of attributes,
 *     ignored if `attribs` is an attribute string.
 * @returns {AttributeString}
 */
exports.makeAttribsString = (opcode, attribs, pool) => {
  padutils.warnDeprecated(
      'Changeset.makeAttribsString() is deprecated; ' +
      'use AttributeMap.prototype.toString() or attributes.attribsToString() instead');
  if (!attribs || !['=', '+'].includes(opcode)) return '';
  if (typeof attribs === 'string') return attribs;
  return new AttributeMap(pool).update(attribs, opcode === '+').toString();
};

/**
 * Like "substring" but on a single-line attribution string.
 */
exports.subattribution = (astr, start, optEnd) => {
  const attOps = exports.deserializeOps(astr);
  let attOpsNext = attOps.next();
  const assem = exports.smartOpAssembler();
  let attOp = new Op();
  const csOp = new Op();

  const doCsOp = () => {
    if (!csOp.chars) return;
    while (csOp.opcode && (attOp.opcode || !attOpsNext.done)) {
      if (!attOp.opcode) {
        attOp = attOpsNext.value;
        attOpsNext = attOps.next();
      }
      if (csOp.opcode && attOp.opcode && csOp.chars >= attOp.chars &&
          attOp.lines > 0 && csOp.lines <= 0) {
        csOp.lines++;
      }
      const opOut = slicerZipperFunc(attOp, csOp, null);
      if (opOut.opcode) assem.append(opOut);
    }
  };

  csOp.opcode = '-';
  csOp.chars = start;

  doCsOp();

  if (optEnd === undefined) {
    if (attOp.opcode) {
      assem.append(attOp);
    }
    while (!attOpsNext.done) {
      assem.append(attOpsNext.value);
      attOpsNext = attOps.next();
    }
  } else {
    csOp.opcode = '=';
    csOp.chars = optEnd - start;
    doCsOp();
  }

  return assem.toString();
};

exports.inverse = (cs, lines, alines, pool) => {
  // lines and alines are what the exports is meant to apply to.
  // They may be arrays or objects with .get(i) and .length methods.
  // They include final newlines on lines.

  const linesGet = (idx) => {
    if (lines.get) {
      return lines.get(idx);
    } else {
      return lines[idx];
    }
  };

  /**
   * @param {number} idx -
   * @returns {string}
   */
  const alinesGet = (idx) => {
    if (alines.get) {
      return alines.get(idx);
    } else {
      return alines[idx];
    }
  };

  let curLine = 0;
  let curChar = 0;
  let curLineOps = null;
  let curLineOpsNext = null;
  let curLineOpsLine;
  let curLineNextOp = new Op('+');

  const unpacked = exports.unpack(cs);
  const builder = exports.builder(unpacked.newLen);

  const consumeAttribRuns = (numChars, func /* (len, attribs, endsLine)*/) => {
    if (!curLineOps || curLineOpsLine !== curLine) {
      curLineOps = exports.deserializeOps(alinesGet(curLine));
      curLineOpsNext = curLineOps.next();
      curLineOpsLine = curLine;
      let indexIntoLine = 0;
      while (!curLineOpsNext.done) {
        curLineNextOp = curLineOpsNext.value;
        curLineOpsNext = curLineOps.next();
        if (indexIntoLine + curLineNextOp.chars >= curChar) {
          curLineNextOp.chars -= (curChar - indexIntoLine);
          break;
        }
        indexIntoLine += curLineNextOp.chars;
      }
    }

    while (numChars > 0) {
      if (!curLineNextOp.chars && curLineOpsNext.done) {
        curLine++;
        curChar = 0;
        curLineOpsLine = curLine;
        curLineNextOp.chars = 0;
        curLineOps = exports.deserializeOps(alinesGet(curLine));
        curLineOpsNext = curLineOps.next();
      }
      if (!curLineNextOp.chars) {
        if (curLineOpsNext.done) {
          curLineNextOp = new Op();
        } else {
          curLineNextOp = curLineOpsNext.value;
          curLineOpsNext = curLineOps.next();
        }
      }
      const charsToUse = Math.min(numChars, curLineNextOp.chars);
      func(charsToUse, curLineNextOp.attribs, charsToUse === curLineNextOp.chars &&
          curLineNextOp.lines > 0);
      numChars -= charsToUse;
      curLineNextOp.chars -= charsToUse;
      curChar += charsToUse;
    }

    if (!curLineNextOp.chars && curLineOpsNext.done) {
      curLine++;
      curChar = 0;
    }
  };

  const skip = (N, L) => {
    if (L) {
      curLine += L;
      curChar = 0;
    } else if (curLineOps && curLineOpsLine === curLine) {
      consumeAttribRuns(N, () => {});
    } else {
      curChar += N;
    }
  };

  const nextText = (numChars) => {
    let len = 0;
    const assem = exports.stringAssembler();
    const firstString = linesGet(curLine).substring(curChar);
    len += firstString.length;
    assem.append(firstString);

    let lineNum = curLine + 1;
    while (len < numChars) {
      const nextString = linesGet(lineNum);
      len += nextString.length;
      assem.append(nextString);
      lineNum++;
    }

    return assem.toString().substring(0, numChars);
  };

  const cachedStrFunc = (func) => {
    const cache = {};
    return (s) => {
      if (!cache[s]) {
        cache[s] = func(s);
      }
      return cache[s];
    };
  };

  for (const csOp of exports.deserializeOps(unpacked.ops)) {
    if (csOp.opcode === '=') {
      if (csOp.attribs) {
        const attribs = AttributeMap.fromString(csOp.attribs, pool);
        const undoBackToAttribs = cachedStrFunc((oldAttribsStr) => {
          const oldAttribs = AttributeMap.fromString(oldAttribsStr, pool);
          const backAttribs = new AttributeMap(pool);
          for (const [key, value] of attribs) {
            const oldValue = oldAttribs.get(key) || '';
            if (oldValue !== value) backAttribs.set(key, oldValue);
          }
          // TODO: backAttribs does not restore removed attributes (it is missing attributes that
          // are in oldAttribs but not in attribs). I don't know if that is intentional.
          return backAttribs.toString();
        });
        consumeAttribRuns(csOp.chars, (len, attribs, endsLine) => {
          builder.keep(len, endsLine ? 1 : 0, undoBackToAttribs(attribs));
        });
      } else {
        skip(csOp.chars, csOp.lines);
        builder.keep(csOp.chars, csOp.lines);
      }
    } else if (csOp.opcode === '+') {
      builder.remove(csOp.chars, csOp.lines);
    } else if (csOp.opcode === '-') {
      const textBank = nextText(csOp.chars);
      let textBankIndex = 0;
      consumeAttribRuns(csOp.chars, (len, attribs, endsLine) => {
        builder.insert(textBank.substr(textBankIndex, len), attribs);
        textBankIndex += len;
      });
    }
  }

  return exports.checkRep(builder.toString());
};

// %CLIENT FILE ENDS HERE%
exports.follow = (cs1, cs2, reverseInsertOrder, pool) => {
  const unpacked1 = exports.unpack(cs1);
  const unpacked2 = exports.unpack(cs2);
  const len1 = unpacked1.oldLen;
  const len2 = unpacked2.oldLen;
  assert(len1 === len2, 'mismatched follow - cannot transform cs1 on top of cs2');
  const chars1 = exports.stringIterator(unpacked1.charBank);
  const chars2 = exports.stringIterator(unpacked2.charBank);

  const oldLen = unpacked1.newLen;
  let oldPos = 0;
  let newLen = 0;

  const hasInsertFirst = exports.attributeTester(['insertorder', 'first'], pool);

  const newOps = applyZip(unpacked1.ops, unpacked2.ops, (op1, op2) => {
    const opOut = new Op();
    if (op1.opcode === '+' || op2.opcode === '+') {
      let whichToDo;
      if (op2.opcode !== '+') {
        whichToDo = 1;
      } else if (op1.opcode !== '+') {
        whichToDo = 2;
      } else {
        // both +
        const firstChar1 = chars1.peek(1);
        const firstChar2 = chars2.peek(1);
        const insertFirst1 = hasInsertFirst(op1.attribs);
        const insertFirst2 = hasInsertFirst(op2.attribs);
        if (insertFirst1 && !insertFirst2) {
          whichToDo = 1;
        } else if (insertFirst2 && !insertFirst1) {
          whichToDo = 2;
        } else if (firstChar1 === '\n' && firstChar2 !== '\n') {
          // insert string that doesn't start with a newline first so as not to break up lines
          whichToDo = 2;
        } else if (firstChar1 !== '\n' && firstChar2 === '\n') {
          whichToDo = 1;
        } else if (reverseInsertOrder) {
          // break symmetry:
          whichToDo = 2;
        } else {
          whichToDo = 1;
        }
      }
      if (whichToDo === 1) {
        chars1.skip(op1.chars);
        opOut.opcode = '=';
        opOut.lines = op1.lines;
        opOut.chars = op1.chars;
        opOut.attribs = '';
        op1.opcode = '';
      } else {
        // whichToDo == 2
        chars2.skip(op2.chars);
        copyOp(op2, opOut);
        op2.opcode = '';
      }
    } else if (op1.opcode === '-') {
      if (!op2.opcode) {
        op1.opcode = '';
      } else if (op1.chars <= op2.chars) {
        op2.chars -= op1.chars;
        op2.lines -= op1.lines;
        op1.opcode = '';
        if (!op2.chars) {
          op2.opcode = '';
        }
      } else {
        op1.chars -= op2.chars;
        op1.lines -= op2.lines;
        op2.opcode = '';
      }
    } else if (op2.opcode === '-') {
      copyOp(op2, opOut);
      if (!op1.opcode) {
        op2.opcode = '';
      } else if (op2.chars <= op1.chars) {
        // delete part or all of a keep
        op1.chars -= op2.chars;
        op1.lines -= op2.lines;
        op2.opcode = '';
        if (!op1.chars) {
          op1.opcode = '';
        }
      } else {
        // delete all of a keep, and keep going
        opOut.lines = op1.lines;
        opOut.chars = op1.chars;
        op2.lines -= op1.lines;
        op2.chars -= op1.chars;
        op1.opcode = '';
      }
    } else if (!op1.opcode) {
      copyOp(op2, opOut);
      op2.opcode = '';
    } else if (!op2.opcode) {
      // @NOTE: Critical bugfix for EPL issue #1625. We do not copy op1 here
      // in order to prevent attributes from leaking into result changesets.
      // copyOp(op1, opOut);
      op1.opcode = '';
    } else {
      // both keeps
      opOut.opcode = '=';
      opOut.attribs = followAttributes(op1.attribs, op2.attribs, pool);
      if (op1.chars <= op2.chars) {
        opOut.chars = op1.chars;
        opOut.lines = op1.lines;
        op2.chars -= op1.chars;
        op2.lines -= op1.lines;
        op1.opcode = '';
        if (!op2.chars) {
          op2.opcode = '';
        }
      } else {
        opOut.chars = op2.chars;
        opOut.lines = op2.lines;
        op1.chars -= op2.chars;
        op1.lines -= op2.lines;
        op2.opcode = '';
      }
    }
    switch (opOut.opcode) {
      case '=':
        oldPos += opOut.chars;
        newLen += opOut.chars;
        break;
      case '-':
        oldPos += opOut.chars;
        break;
      case '+':
        newLen += opOut.chars;
        break;
    }
    return opOut;
  });
  newLen += oldLen - oldPos;

  return exports.pack(oldLen, newLen, newOps, unpacked2.charBank);
};

const followAttributes = (att1, att2, pool) => {
  // The merge of two sets of attribute changes to the same text
  // takes the lexically-earlier value if there are two values
  // for the same key.  Otherwise, all key/value changes from
  // both attribute sets are taken.  This operation is the "follow",
  // so a set of changes is produced that can be applied to att1
  // to produce the merged set.
  if ((!att2) || (!pool)) return '';
  if (!att1) return att2;
  const atts = new Map();
  att2.replace(/\*([0-9a-z]+)/g, (_, a) => {
    const [key, val] = pool.getAttrib(exports.parseNum(a));
    atts.set(key, val);
    return '';
  });
  att1.replace(/\*([0-9a-z]+)/g, (_, a) => {
    const [key, val] = pool.getAttrib(exports.parseNum(a));
    if (atts.has(key) && val <= atts.get(key)) atts.delete(key);
    return '';
  });
  // we've only removed attributes, so they're already sorted
  const buf = exports.stringAssembler();
  for (const att of atts) {
    buf.append('*');
    buf.append(exports.numToString(pool.putAttrib(att)));
  }
  return buf.toString();
};

exports.exportedForTestingOnly = {
  TextLinesMutator,
  followAttributes,
  toSplices,
};
}}["(module ep_etherpad-lite/static/js/Changeset.js)"],
"ep_etherpad-lite/static/js/ChangesetUtils.js": {"(module ep_etherpad-lite/static/js/ChangesetUtils.js)": function (require, exports, module) {'use strict';

/**
 * This module contains several helper Functions to build Changesets
 * based on a SkipList
 */

/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
exports.buildRemoveRange = (rep, builder, start, end) => {
  const startLineOffset = rep.lines.offsetOfIndex(start[0]);
  const endLineOffset = rep.lines.offsetOfIndex(end[0]);

  if (end[0] > start[0]) {
    builder.remove(endLineOffset - startLineOffset - start[1], end[0] - start[0]);
    builder.remove(end[1]);
  } else {
    builder.remove(end[1] - start[1]);
  }
};

exports.buildKeepRange = (rep, builder, start, end, attribs, pool) => {
  const startLineOffset = rep.lines.offsetOfIndex(start[0]);
  const endLineOffset = rep.lines.offsetOfIndex(end[0]);

  if (end[0] > start[0]) {
    builder.keep(endLineOffset - startLineOffset - start[1], end[0] - start[0], attribs, pool);
    builder.keep(end[1], 0, attribs, pool);
  } else {
    builder.keep(end[1] - start[1], 0, attribs, pool);
  }
};

exports.buildKeepToStartOfRange = (rep, builder, start) => {
  const startLineOffset = rep.lines.offsetOfIndex(start[0]);

  builder.keep(startLineOffset, start[0]);
  builder.keep(start[1]);
};
}}["(module ep_etherpad-lite/static/js/ChangesetUtils.js)"],
"ep_etherpad-lite/static/js/skiplist.js": {"(module ep_etherpad-lite/static/js/skiplist.js)": function (require, exports, module) {'use strict';

/**
 * This code is mostly from the old Etherpad. Please help us to comment this code.
 * This helps other people to understand this code better and helps them to improve it.
 * TL;DR COMMENTS ON THIS FILE ARE HIGHLY APPRECIATED
 */

/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const _entryWidth = (e) => (e && e.width) || 0;

class Node {
  constructor(entry, levels = 0, downSkips = 1, downSkipWidths = 0) {
    this.key = entry != null ? entry.key : null;
    this.entry = entry;
    this.levels = levels;
    this.upPtrs = Array(levels).fill(null);
    this.downPtrs = Array(levels).fill(null);
    this.downSkips = Array(levels).fill(downSkips);
    this.downSkipWidths = Array(levels).fill(downSkipWidths);
  }

  propagateWidthChange() {
    const oldWidth = this.downSkipWidths[0];
    const newWidth = _entryWidth(this.entry);
    const widthChange = newWidth - oldWidth;
    let n = this;
    let lvl = 0;
    while (lvl < n.levels) {
      n.downSkipWidths[lvl] += widthChange;
      lvl++;
      while (lvl >= n.levels && n.upPtrs[lvl - 1]) {
        n = n.upPtrs[lvl - 1];
      }
    }
    return widthChange;
  }
}

// A "point" object at index x allows modifications immediately after the first x elements of the
// skiplist, such as multiple inserts or deletes. After an insert or delete using point P, the point
// is still valid and points to the same index in the skiplist. Other operations with other points
// invalidate this point.
class Point {
  constructor(skipList, loc) {
    this._skipList = skipList;
    this.loc = loc;
    const numLevels = this._skipList._start.levels;
    let lvl = numLevels - 1;
    let i = -1;
    let ws = 0;
    const nodes = new Array(numLevels);
    const idxs = new Array(numLevels);
    const widthSkips = new Array(numLevels);
    nodes[lvl] = this._skipList._start;
    idxs[lvl] = -1;
    widthSkips[lvl] = 0;
    while (lvl >= 0) {
      let n = nodes[lvl];
      while (n.downPtrs[lvl] && (i + n.downSkips[lvl] < this.loc)) {
        i += n.downSkips[lvl];
        ws += n.downSkipWidths[lvl];
        n = n.downPtrs[lvl];
      }
      nodes[lvl] = n;
      idxs[lvl] = i;
      widthSkips[lvl] = ws;
      lvl--;
      if (lvl >= 0) {
        nodes[lvl] = n;
      }
    }
    this.idxs = idxs;
    this.nodes = nodes;
    this.widthSkips = widthSkips;
  }

  toString() {
    return `Point(${this.loc})`;
  }

  insert(entry) {
    if (entry.key == null) throw new Error('entry.key must not be null');
    if (this._skipList.containsKey(entry.key)) {
      throw new Error(`an entry with key ${entry.key} already exists`);
    }

    const newNode = new Node(entry);
    const pNodes = this.nodes;
    const pIdxs = this.idxs;
    const pLoc = this.loc;
    const widthLoc = this.widthSkips[0] + this.nodes[0].downSkipWidths[0];
    const newWidth = _entryWidth(entry);

    // The new node will have at least level 1
    // With a proability of 0.01^(n-1) the nodes level will be >= n
    while (newNode.levels === 0 || Math.random() < 0.01) {
      const lvl = newNode.levels;
      newNode.levels++;
      if (lvl === pNodes.length) {
        // assume we have just passed the end of this.nodes, and reached one level greater
        // than the skiplist currently supports
        pNodes[lvl] = this._skipList._start;
        pIdxs[lvl] = -1;
        this._skipList._start.levels++;
        this._skipList._end.levels++;
        this._skipList._start.downPtrs[lvl] = this._skipList._end;
        this._skipList._end.upPtrs[lvl] = this._skipList._start;
        this._skipList._start.downSkips[lvl] = this._skipList._keyToNodeMap.size + 1;
        this._skipList._start.downSkipWidths[lvl] = this._skipList._totalWidth;
        this.widthSkips[lvl] = 0;
      }
      const me = newNode;
      const up = pNodes[lvl];
      const down = up.downPtrs[lvl];
      const skip1 = pLoc - pIdxs[lvl];
      const skip2 = up.downSkips[lvl] + 1 - skip1;
      up.downSkips[lvl] = skip1;
      up.downPtrs[lvl] = me;
      me.downSkips[lvl] = skip2;
      me.upPtrs[lvl] = up;
      me.downPtrs[lvl] = down;
      down.upPtrs[lvl] = me;
      const widthSkip1 = widthLoc - this.widthSkips[lvl];
      const widthSkip2 = up.downSkipWidths[lvl] + newWidth - widthSkip1;
      up.downSkipWidths[lvl] = widthSkip1;
      me.downSkipWidths[lvl] = widthSkip2;
    }
    for (let lvl = newNode.levels; lvl < pNodes.length; lvl++) {
      const up = pNodes[lvl];
      up.downSkips[lvl]++;
      up.downSkipWidths[lvl] += newWidth;
    }
    this._skipList._keyToNodeMap.set(newNode.key, newNode);
    this._skipList._totalWidth += newWidth;
  }

  delete() {
    const elem = this.nodes[0].downPtrs[0];
    const elemWidth = _entryWidth(elem.entry);
    for (let i = 0; i < this.nodes.length; i++) {
      if (i < elem.levels) {
        const up = elem.upPtrs[i];
        const down = elem.downPtrs[i];
        const totalSkip = up.downSkips[i] + elem.downSkips[i] - 1;
        up.downPtrs[i] = down;
        down.upPtrs[i] = up;
        up.downSkips[i] = totalSkip;
        const totalWidthSkip = up.downSkipWidths[i] + elem.downSkipWidths[i] - elemWidth;
        up.downSkipWidths[i] = totalWidthSkip;
      } else {
        const up = this.nodes[i];
        up.downSkips[i]--;
        up.downSkipWidths[i] -= elemWidth;
      }
    }
    this._skipList._keyToNodeMap.delete(elem.key);
    this._skipList._totalWidth -= elemWidth;
  }

  getNode() {
    return this.nodes[0].downPtrs[0];
  }
}

/**
 * The skip-list contains "entries", JavaScript objects that each must have a unique "key"
 * property that is a string.
 */
class SkipList {
  constructor() {
    // if there are N elements in the skiplist, "start" is element -1 and "end" is element N
    this._start = new Node(null, 1);
    this._end = new Node(null, 1, null, null);
    this._totalWidth = 0;
    this._keyToNodeMap = new Map();
    this._start.downPtrs[0] = this._end;
    this._end.upPtrs[0] = this._start;
  }

  _getNodeAtOffset(targetOffset) {
    let i = 0;
    let n = this._start;
    let lvl = this._start.levels - 1;
    while (lvl >= 0 && n.downPtrs[lvl]) {
      while (n.downPtrs[lvl] && (i + n.downSkipWidths[lvl] <= targetOffset)) {
        i += n.downSkipWidths[lvl];
        n = n.downPtrs[lvl];
      }
      lvl--;
    }
    if (n === this._start) return (this._start.downPtrs[0] || null);
    if (n === this._end) {
      return targetOffset === this._totalWidth ? (this._end.upPtrs[0] || null) : null;
    }
    return n;
  }

  _getNodeIndex(node, byWidth) {
    let dist = (byWidth ? 0 : -1);
    let n = node;
    while (n !== this._start) {
      const lvl = n.levels - 1;
      n = n.upPtrs[lvl];
      if (byWidth) dist += n.downSkipWidths[lvl];
      else dist += n.downSkips[lvl];
    }
    return dist;
  }

  // Returns index of first entry such that entryFunc(entry) is truthy,
  // or length() if no such entry.  Assumes all falsy entries come before
  // all truthy entries.
  search(entryFunc) {
    let low = this._start;
    let lvl = this._start.levels - 1;
    let lowIndex = -1;

    const f = (node) => {
      if (node === this._start) return false;
      else if (node === this._end) return true;
      else return entryFunc(node.entry);
    };

    while (lvl >= 0) {
      let nextLow = low.downPtrs[lvl];
      while (!f(nextLow)) {
        lowIndex += low.downSkips[lvl];
        low = nextLow;
        nextLow = low.downPtrs[lvl];
      }
      lvl--;
    }
    return lowIndex + 1;
  }

  length() { return this._keyToNodeMap.size; }

  atIndex(i) {
    if (i < 0) console.warn(`atIndex(${i})`);
    if (i >= this._keyToNodeMap.size) console.warn(`atIndex(${i}>=${this._keyToNodeMap.size})`);
    return (new Point(this, i)).getNode().entry;
  }

  // differs from Array.splice() in that new elements are in an array, not varargs
  splice(start, deleteCount, newEntryArray) {
    if (start < 0) console.warn(`splice(${start}, ...)`);
    if (start + deleteCount > this._keyToNodeMap.size) {
      console.warn(`splice(${start}, ${deleteCount}, ...), N=${this._keyToNodeMap.size}`);
      console.warn('%s %s %s', typeof start, typeof deleteCount, typeof this._keyToNodeMap.size);
      console.trace();
    }

    if (!newEntryArray) newEntryArray = [];
    const pt = new Point(this, start);
    for (let i = 0; i < deleteCount; i++) pt.delete();
    for (let i = (newEntryArray.length - 1); i >= 0; i--) {
      const entry = newEntryArray[i];
      pt.insert(entry);
    }
  }

  next(entry) { return this._keyToNodeMap.get(entry.key).downPtrs[0].entry || null; }
  prev(entry) { return this._keyToNodeMap.get(entry.key).upPtrs[0].entry || null; }
  push(entry) { this.splice(this._keyToNodeMap.size, 0, [entry]); }

  slice(start, end) {
    // act like Array.slice()
    if (start === undefined) start = 0;
    else if (start < 0) start += this._keyToNodeMap.size;
    if (end === undefined) end = this._keyToNodeMap.size;
    else if (end < 0) end += this._keyToNodeMap.size;

    if (start < 0) start = 0;
    if (start > this._keyToNodeMap.size) start = this._keyToNodeMap.size;
    if (end < 0) end = 0;
    if (end > this._keyToNodeMap.size) end = this._keyToNodeMap.size;

    if (end <= start) return [];
    let n = this.atIndex(start);
    const array = [n];
    for (let i = 1; i < (end - start); i++) {
      n = this.next(n);
      array.push(n);
    }
    return array;
  }

  atKey(key) { return this._keyToNodeMap.get(key).entry; }
  indexOfKey(key) { return this._getNodeIndex(this._keyToNodeMap.get(key)); }
  indexOfEntry(entry) { return this.indexOfKey(entry.key); }
  containsKey(key) { return this._keyToNodeMap.has(key); }
  // gets the last entry starting at or before the offset
  atOffset(offset) { return this._getNodeAtOffset(offset).entry; }
  keyAtOffset(offset) { return this.atOffset(offset).key; }
  offsetOfKey(key) { return this._getNodeIndex(this._keyToNodeMap.get(key), true); }
  offsetOfEntry(entry) { return this.offsetOfKey(entry.key); }
  setEntryWidth(entry, width) {
    entry.width = width;
    this._totalWidth += this._keyToNodeMap.get(entry.key).propagateWidthChange();
  }
  totalWidth() { return this._totalWidth; }
  offsetOfIndex(i) {
    if (i < 0) return 0;
    if (i >= this._keyToNodeMap.size) return this._totalWidth;
    return this.offsetOfEntry(this.atIndex(i));
  }
  indexOfOffset(offset) {
    if (offset <= 0) return 0;
    if (offset >= this._totalWidth) return this._keyToNodeMap.size;
    return this.indexOfEntry(this.atOffset(offset));
  }
}

module.exports = SkipList;
}}["(module ep_etherpad-lite/static/js/skiplist.js)"],
"ep_etherpad-lite/static/js/colorutils.js": {"(module ep_etherpad-lite/static/js/colorutils.js)": function (require, exports, module) {'use strict';

/**
 * This code is mostly from the old Etherpad. Please help us to comment this code.
 * This helps other people to understand this code better and helps them to improve it.
 * TL;DR COMMENTS ON THIS FILE ARE HIGHLY APPRECIATED
 */

// DO NOT EDIT THIS FILE, edit infrastructure/ace/www/colorutils.js
// THIS FILE IS ALSO SERVED AS CLIENT-SIDE JS
/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const colorutils = {};

// Check that a given value is a css hex color value, e.g.
// "#ffffff" or "#fff"
colorutils.isCssHex = (cssColor) => /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(cssColor);

// "#ffffff" or "#fff" or "ffffff" or "fff" to [1.0, 1.0, 1.0]
colorutils.css2triple = (cssColor) => {
  const sixHex = colorutils.css2sixhex(cssColor);

  const hexToFloat = (hh) => Number(`0x${hh}`) / 255;
  return [
    hexToFloat(sixHex.substr(0, 2)),
    hexToFloat(sixHex.substr(2, 2)),
    hexToFloat(sixHex.substr(4, 2)),
  ];
};

// "#ffffff" or "#fff" or "ffffff" or "fff" to "ffffff"
colorutils.css2sixhex = (cssColor) => {
  let h = /[0-9a-fA-F]+/.exec(cssColor)[0];
  if (h.length !== 6) {
    const a = h.charAt(0);
    const b = h.charAt(1);
    const c = h.charAt(2);
    h = a + a + b + b + c + c;
  }
  return h;
};

// [1.0, 1.0, 1.0] -> "#ffffff"
colorutils.triple2css = (triple) => {
  const floatToHex = (n) => {
    const n2 = colorutils.clamp(Math.round(n * 255), 0, 255);
    return (`0${n2.toString(16)}`).slice(-2);
  };
  return `#${floatToHex(triple[0])}${floatToHex(triple[1])}${floatToHex(triple[2])}`;
};


colorutils.clamp = (v, bot, top) => v < bot ? bot : (v > top ? top : v);
colorutils.min3 = (a, b, c) => (a < b) ? (a < c ? a : c) : (b < c ? b : c);
colorutils.max3 = (a, b, c) => (a > b) ? (a > c ? a : c) : (b > c ? b : c);
colorutils.colorMin = (c) => colorutils.min3(c[0], c[1], c[2]);
colorutils.colorMax = (c) => colorutils.max3(c[0], c[1], c[2]);
colorutils.scale = (v, bot, top) => colorutils.clamp(bot + v * (top - bot), 0, 1);
colorutils.unscale = (v, bot, top) => colorutils.clamp((v - bot) / (top - bot), 0, 1);

colorutils.scaleColor = (c, bot, top) => [
  colorutils.scale(c[0], bot, top),
  colorutils.scale(c[1], bot, top),
  colorutils.scale(c[2], bot, top),
];

colorutils.unscaleColor = (c, bot, top) => [
  colorutils.unscale(c[0], bot, top),
  colorutils.unscale(c[1], bot, top),
  colorutils.unscale(c[2], bot, top),
];

// rule of thumb for RGB brightness; 1.0 is white
colorutils.luminosity = (c) => c[0] * 0.30 + c[1] * 0.59 + c[2] * 0.11;

colorutils.saturate = (c) => {
  const min = colorutils.colorMin(c);
  const max = colorutils.colorMax(c);
  if (max - min <= 0) return [1.0, 1.0, 1.0];
  return colorutils.unscaleColor(c, min, max);
};

colorutils.blend = (c1, c2, t) => [
  colorutils.scale(t, c1[0], c2[0]),
  colorutils.scale(t, c1[1], c2[1]),
  colorutils.scale(t, c1[2], c2[2]),
];

colorutils.invert = (c) => [1 - c[0], 1 - c[1], 1 - c[2]];

colorutils.complementary = (c) => {
  const inv = colorutils.invert(c);
  return [
    (inv[0] >= c[0]) ? Math.min(inv[0] * 1.30, 1) : (c[0] * 0.30),
    (inv[1] >= c[1]) ? Math.min(inv[1] * 1.59, 1) : (c[1] * 0.59),
    (inv[2] >= c[2]) ? Math.min(inv[2] * 1.11, 1) : (c[2] * 0.11),
  ];
};

colorutils.textColorFromBackgroundColor = (bgcolor, skinName) => {
  const white = skinName === 'colibris' ? 'var(--super-light-color)' : '#fff';
  const black = skinName === 'colibris' ? 'var(--super-dark-color)' : '#222';

  return colorutils.luminosity(colorutils.css2triple(bgcolor)) < 0.5 ? white : black;
};

exports.colorutils = colorutils;
}}["(module ep_etherpad-lite/static/js/colorutils.js)"],
"ep_etherpad-lite/static/js/undomodule.js": {"(module ep_etherpad-lite/static/js/undomodule.js)": function (require, exports, module) {'use strict';

/**
 * This code is mostly from the old Etherpad. Please help us to comment this code.
 * This helps other people to understand this code better and helps them to improve it.
 * TL;DR COMMENTS ON THIS FILE ARE HIGHLY APPRECIATED
 */

/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const Changeset = require('./Changeset');
const _ = require('./underscore');

const undoModule = (() => {
  const stack = (() => {
    const stackElements = [];
    // two types of stackElements:
    // 1) { elementType: UNDOABLE_EVENT, eventType: "anything", [backset: <changeset>,]
    //      [selStart: <char number>, selEnd: <char number>, selFocusAtStart: <boolean>] }
    // 2) { elementType: EXTERNAL_CHANGE, changeset: <changeset> }
    // invariant: no two consecutive EXTERNAL_CHANGEs
    let numUndoableEvents = 0;

    const UNDOABLE_EVENT = 'undoableEvent';
    const EXTERNAL_CHANGE = 'externalChange';

    const clearStack = () => {
      stackElements.length = 0;
      stackElements.push(
          {
            elementType: UNDOABLE_EVENT,
            eventType: 'bottom',
          });
      numUndoableEvents = 1;
    };
    clearStack();

    const pushEvent = (event) => {
      const e = _.extend(
          {}, event);
      e.elementType = UNDOABLE_EVENT;
      stackElements.push(e);
      numUndoableEvents++;
    };

    const pushExternalChange = (cs) => {
      const idx = stackElements.length - 1;
      if (stackElements[idx].elementType === EXTERNAL_CHANGE) {
        stackElements[idx].changeset =
            Changeset.compose(stackElements[idx].changeset, cs, getAPool());
      } else {
        stackElements.push(
            {
              elementType: EXTERNAL_CHANGE,
              changeset: cs,
            });
      }
    };

    const _exposeEvent = (nthFromTop) => {
      // precond: 0 <= nthFromTop < numUndoableEvents
      const targetIndex = stackElements.length - 1 - nthFromTop;
      let idx = stackElements.length - 1;
      while (idx > targetIndex || stackElements[idx].elementType === EXTERNAL_CHANGE) {
        if (stackElements[idx].elementType === EXTERNAL_CHANGE) {
          const ex = stackElements[idx];
          const un = stackElements[idx - 1];
          if (un.backset) {
            const excs = ex.changeset;
            const unbs = un.backset;
            un.backset = Changeset.follow(excs, un.backset, false, getAPool());
            ex.changeset = Changeset.follow(unbs, ex.changeset, true, getAPool());
            if ((typeof un.selStart) === 'number') {
              const newSel = Changeset.characterRangeFollow(excs, un.selStart, un.selEnd);
              un.selStart = newSel[0];
              un.selEnd = newSel[1];
              if (un.selStart === un.selEnd) {
                un.selFocusAtStart = false;
              }
            }
          }
          stackElements[idx - 1] = ex;
          stackElements[idx] = un;
          if (idx >= 2 && stackElements[idx - 2].elementType === EXTERNAL_CHANGE) {
            ex.changeset =
                Changeset.compose(stackElements[idx - 2].changeset, ex.changeset, getAPool());
            stackElements.splice(idx - 2, 1);
            idx--;
          }
        } else {
          idx--;
        }
      }
    };

    const getNthFromTop = (n) => {
      // precond: 0 <= n < numEvents()
      _exposeEvent(n);
      return stackElements[stackElements.length - 1 - n];
    };

    const numEvents = () => numUndoableEvents;

    const popEvent = () => {
      // precond: numEvents() > 0
      _exposeEvent(0);
      numUndoableEvents--;
      return stackElements.pop();
    };

    return {
      numEvents,
      popEvent,
      pushEvent,
      pushExternalChange,
      clearStack,
      getNthFromTop,
    };
  })();

  // invariant: stack always has at least one undoable event
  let undoPtr = 0; // zero-index from top of stack, 0 == top

  const clearHistory = () => {
    stack.clearStack();
    undoPtr = 0;
  };

  const _charOccurrences = (str, c) => {
    let i = 0;
    let count = 0;
    while (i >= 0 && i < str.length) {
      i = str.indexOf(c, i);
      if (i >= 0) {
        count++;
        i++;
      }
    }
    return count;
  };

  const _opcodeOccurrences = (cs, opcode) => _charOccurrences(Changeset.unpack(cs).ops, opcode);

  const _mergeChangesets = (cs1, cs2) => {
    if (!cs1) return cs2;
    if (!cs2) return cs1;

    // Rough heuristic for whether changesets should be considered one action:
    // each does exactly one insertion, no dels, and the composition does also; or
    // each does exactly one deletion, no ins, and the composition does also.
    // A little weird in that it won't merge "make bold" with "insert char"
    // but will merge "make bold and insert char" with "insert char",
    // though that isn't expected to come up.
    const plusCount1 = _opcodeOccurrences(cs1, '+');
    const plusCount2 = _opcodeOccurrences(cs2, '+');
    const minusCount1 = _opcodeOccurrences(cs1, '-');
    const minusCount2 = _opcodeOccurrences(cs2, '-');
    if (plusCount1 === 1 && plusCount2 === 1 && minusCount1 === 0 && minusCount2 === 0) {
      const merge = Changeset.compose(cs1, cs2, getAPool());
      const plusCount3 = _opcodeOccurrences(merge, '+');
      const minusCount3 = _opcodeOccurrences(merge, '-');
      if (plusCount3 === 1 && minusCount3 === 0) {
        return merge;
      }
    } else if (plusCount1 === 0 && plusCount2 === 0 && minusCount1 === 1 && minusCount2 === 1) {
      const merge = Changeset.compose(cs1, cs2, getAPool());
      const plusCount3 = _opcodeOccurrences(merge, '+');
      const minusCount3 = _opcodeOccurrences(merge, '-');
      if (plusCount3 === 0 && minusCount3 === 1) {
        return merge;
      }
    }
    return null;
  };

  const reportEvent = (event) => {
    const topEvent = stack.getNthFromTop(0);

    const applySelectionToTop = () => {
      if ((typeof event.selStart) === 'number') {
        topEvent.selStart = event.selStart;
        topEvent.selEnd = event.selEnd;
        topEvent.selFocusAtStart = event.selFocusAtStart;
      }
    };

    if ((!event.backset) || Changeset.isIdentity(event.backset)) {
      applySelectionToTop();
    } else {
      let merged = false;
      if (topEvent.eventType === event.eventType) {
        const merge = _mergeChangesets(event.backset, topEvent.backset);
        if (merge) {
          topEvent.backset = merge;
          applySelectionToTop();
          merged = true;
        }
      }
      if (!merged) {
        /*
         * Push the event on the undo stack only if it exists, and if it's
         * not a "clearauthorship". This disallows undoing the removal of the
         * authorship colors, but is a necessary stopgap measure against
         * https://github.com/ether/etherpad-lite/issues/2802
         */
        if (event && (event.eventType !== 'clearauthorship')) {
          stack.pushEvent(event);
        }
      }
      undoPtr = 0;
    }
  };

  const reportExternalChange = (changeset) => {
    if (changeset && !Changeset.isIdentity(changeset)) {
      stack.pushExternalChange(changeset);
    }
  };

  const _getSelectionInfo = (event) => {
    if ((typeof event.selStart) !== 'number') {
      return null;
    } else {
      return {
        selStart: event.selStart,
        selEnd: event.selEnd,
        selFocusAtStart: event.selFocusAtStart,
      };
    }
  };

  // For "undo" and "redo", the change event must be returned
  // by eventFunc and NOT reported through the normal mechanism.
  // "eventFunc" should take a changeset and an optional selection info object,
  // or can be called with no arguments to mean that no undo is possible.
  // "eventFunc" will be called exactly once.

  const performUndo = (eventFunc) => {
    if (undoPtr < stack.numEvents() - 1) {
      const backsetEvent = stack.getNthFromTop(undoPtr);
      const selectionEvent = stack.getNthFromTop(undoPtr + 1);
      const undoEvent = eventFunc(backsetEvent.backset, _getSelectionInfo(selectionEvent));
      stack.pushEvent(undoEvent);
      undoPtr += 2;
    } else { eventFunc(); }
  };

  const performRedo = (eventFunc) => {
    if (undoPtr >= 2) {
      const backsetEvent = stack.getNthFromTop(0);
      const selectionEvent = stack.getNthFromTop(1);
      eventFunc(backsetEvent.backset, _getSelectionInfo(selectionEvent));
      stack.popEvent();
      undoPtr -= 2;
    } else { eventFunc(); }
  };

  const getAPool = () => undoModule.apool;

  return {
    clearHistory,
    reportEvent,
    reportExternalChange,
    performUndo,
    performRedo,
    enabled: true,
    apool: null,
  }; // apool is filled in by caller
})();

exports.undoModule = undoModule;
}}["(module ep_etherpad-lite/static/js/undomodule.js)"],
"unorm/lib/unorm.js": {"(module unorm/lib/unorm.js)": function (require, exports, module) {(function (root) {
   "use strict";

/***** unorm.js *****/

/*
 * UnicodeNormalizer 1.0.0
 * Copyright (c) 2008 Matsuza
 * Dual licensed under the MIT (MIT-LICENSE.txt) and GPL (GPL-LICENSE.txt) licenses.
 * $Date: 2008-06-05 16:44:17 +0200 (Thu, 05 Jun 2008) $
 * $Rev: 13309 $
 */

   var DEFAULT_FEATURE = [null, 0, {}];
   var CACHE_THRESHOLD = 10;
   var SBase = 0xAC00, LBase = 0x1100, VBase = 0x1161, TBase = 0x11A7, LCount = 19, VCount = 21, TCount = 28;
   var NCount = VCount * TCount; // 588
   var SCount = LCount * NCount; // 11172

   var UChar = function(cp, feature){
      this.codepoint = cp;
      this.feature = feature;
   };

   // Strategies
   var cache = {};
   var cacheCounter = [];
   for (var i = 0; i <= 0xFF; ++i){
      cacheCounter[i] = 0;
   }

   function fromCache(next, cp, needFeature){
      var ret = cache[cp];
      if(!ret){
         ret = next(cp, needFeature);
         if(!!ret.feature && ++cacheCounter[(cp >> 8) & 0xFF] > CACHE_THRESHOLD){
            cache[cp] = ret;
         }
      }
      return ret;
   }

   function fromData(next, cp, needFeature){
      var hash = cp & 0xFF00;
      var dunit = UChar.udata[hash] || {};
      var f = dunit[cp];
      return f ? new UChar(cp, f) : new UChar(cp, DEFAULT_FEATURE);
   }
   function fromCpOnly(next, cp, needFeature){
      return !!needFeature ? next(cp, needFeature) : new UChar(cp, null);
   }
   function fromRuleBasedJamo(next, cp, needFeature){
      var j;
      if(cp < LBase || (LBase + LCount <= cp && cp < SBase) || (SBase + SCount < cp)){
         return next(cp, needFeature);
      }
      if(LBase <= cp && cp < LBase + LCount){
         var c = {};
         var base = (cp - LBase) * VCount;
         for (j = 0; j < VCount; ++j){
            c[VBase + j] = SBase + TCount * (j + base);
         }
         return new UChar(cp, [,,c]);
      }

      var SIndex = cp - SBase;
      var TIndex = SIndex % TCount;
      var feature = [];
      if(TIndex !== 0){
         feature[0] = [SBase + SIndex - TIndex, TBase + TIndex];
      } else {
         feature[0] = [LBase + Math.floor(SIndex / NCount), VBase + Math.floor((SIndex % NCount) / TCount)];
         feature[2] = {};
         for (j = 1; j < TCount; ++j){
            feature[2][TBase + j] = cp + j;
         }
      }
      return new UChar(cp, feature);
   }
   function fromCpFilter(next, cp, needFeature){
      return cp < 60 || 13311 < cp && cp < 42607 ? new UChar(cp, DEFAULT_FEATURE) : next(cp, needFeature);
   }

   var strategies = [fromCpFilter, fromCache, fromCpOnly, fromRuleBasedJamo, fromData];

   UChar.fromCharCode = strategies.reduceRight(function (next, strategy) {
      return function (cp, needFeature) {
         return strategy(next, cp, needFeature);
      };
   }, null);

   UChar.isHighSurrogate = function(cp){
      return cp >= 0xD800 && cp <= 0xDBFF;
   };
   UChar.isLowSurrogate = function(cp){
      return cp >= 0xDC00 && cp <= 0xDFFF;
   };

   UChar.prototype.prepFeature = function(){
      if(!this.feature){
         this.feature = UChar.fromCharCode(this.codepoint, true).feature;
      }
   };

   UChar.prototype.toString = function(){
      if(this.codepoint < 0x10000){
         return String.fromCharCode(this.codepoint);
      } else {
         var x = this.codepoint - 0x10000;
         return String.fromCharCode(Math.floor(x / 0x400) + 0xD800, x % 0x400 + 0xDC00);
      }
   };

   UChar.prototype.getDecomp = function(){
      this.prepFeature();
      return this.feature[0] || null;
   };

   UChar.prototype.isCompatibility = function(){
      this.prepFeature();
      return !!this.feature[1] && (this.feature[1] & (1 << 8));
   };
   UChar.prototype.isExclude = function(){
      this.prepFeature();
      return !!this.feature[1] && (this.feature[1] & (1 << 9));
   };
   UChar.prototype.getCanonicalClass = function(){
      this.prepFeature();
      return !!this.feature[1] ? (this.feature[1] & 0xff) : 0;
   };
   UChar.prototype.getComposite = function(following){
      this.prepFeature();
      if(!this.feature[2]){
         return null;
      }
      var cp = this.feature[2][following.codepoint];
      return cp ? UChar.fromCharCode(cp) : null;
   };

   var UCharIterator = function(str){
      this.str = str;
      this.cursor = 0;
   };
   UCharIterator.prototype.next = function(){
      if(!!this.str && this.cursor < this.str.length){
         var cp = this.str.charCodeAt(this.cursor++);
         var d;
         if(UChar.isHighSurrogate(cp) && this.cursor < this.str.length && UChar.isLowSurrogate((d = this.str.charCodeAt(this.cursor)))){
            cp = (cp - 0xD800) * 0x400 + (d -0xDC00) + 0x10000;
            ++this.cursor;
         }
         return UChar.fromCharCode(cp);
      } else {
         this.str = null;
         return null;
      }
   };

   var RecursDecompIterator = function(it, cano){
      this.it = it;
      this.canonical = cano;
      this.resBuf = [];
   };

   RecursDecompIterator.prototype.next = function(){
      function recursiveDecomp(cano, uchar){
         var decomp = uchar.getDecomp();
         if(!!decomp && !(cano && uchar.isCompatibility())){
            var ret = [];
            for(var i = 0; i < decomp.length; ++i){
               var a = recursiveDecomp(cano, UChar.fromCharCode(decomp[i]));
                ret = ret.concat(a);
            }
            return ret;
         } else {
            return [uchar];
         }
      }
      if(this.resBuf.length === 0){
         var uchar = this.it.next();
         if(!uchar){
            return null;
         }
         this.resBuf = recursiveDecomp(this.canonical, uchar);
      }
      return this.resBuf.shift();
   };

   var DecompIterator = function(it){
      this.it = it;
      this.resBuf = [];
   };

   DecompIterator.prototype.next = function(){
      var cc;
      if(this.resBuf.length === 0){
         do{
            var uchar = this.it.next();
            if(!uchar){
               break;
            }
            cc = uchar.getCanonicalClass();
            var inspt = this.resBuf.length;
            if(cc !== 0){
               for(; inspt > 0; --inspt){
                  var uchar2 = this.resBuf[inspt - 1];
                  var cc2 = uchar2.getCanonicalClass();
                  if(cc2 <= cc){
                     break;
                  }
               }
            }
            this.resBuf.splice(inspt, 0, uchar);
         } while(cc !== 0);
      }
      return this.resBuf.shift();
   };

   var CompIterator = function(it){
      this.it = it;
      this.procBuf = [];
      this.resBuf = [];
      this.lastClass = null;
   };

   CompIterator.prototype.next = function(){
      while(this.resBuf.length === 0){
         var uchar = this.it.next();
         if(!uchar){
            this.resBuf = this.procBuf;
            this.procBuf = [];
            break;
         }
         if(this.procBuf.length === 0){
            this.lastClass = uchar.getCanonicalClass();
            this.procBuf.push(uchar);
         } else {
            var starter = this.procBuf[0];
            var composite = starter.getComposite(uchar);
            var cc = uchar.getCanonicalClass();
            if(!!composite && (this.lastClass < cc || this.lastClass === 0)){
               this.procBuf[0] = composite;
            } else {
               if(cc === 0){
                  this.resBuf = this.procBuf;
                  this.procBuf = [];
               }
               this.lastClass = cc;
               this.procBuf.push(uchar);
            }
         }
      }
      return this.resBuf.shift();
   };

   var createIterator = function(mode, str){
      switch(mode){
         case "NFD":
            return new DecompIterator(new RecursDecompIterator(new UCharIterator(str), true));
         case "NFKD":
            return new DecompIterator(new RecursDecompIterator(new UCharIterator(str), false));
         case "NFC":
            return new CompIterator(new DecompIterator(new RecursDecompIterator(new UCharIterator(str), true)));
         case "NFKC":
            return new CompIterator(new DecompIterator(new RecursDecompIterator(new UCharIterator(str), false)));
      }
      throw mode + " is invalid";
   };
   var normalize = function(mode, str){
      var it = createIterator(mode, str);
      var ret = "";
      var uchar;
      while(!!(uchar = it.next())){
         ret += uchar.toString();
      }
      return ret;
   };

   /* API functions */
   function nfd(str){
      return normalize("NFD", str);
   }

   function nfkd(str){
      return normalize("NFKD", str);
   }

   function nfc(str){
      return normalize("NFC", str);
   }

   function nfkc(str){
      return normalize("NFKC", str);
   }

/* Unicode data */
UChar.udata={
0:{60:[,,{824:8814}],61:[,,{824:8800}],62:[,,{824:8815}],65:[,,{768:192,769:193,770:194,771:195,772:256,774:258,775:550,776:196,777:7842,778:197,780:461,783:512,785:514,803:7840,805:7680,808:260}],66:[,,{775:7682,803:7684,817:7686}],67:[,,{769:262,770:264,775:266,780:268,807:199}],68:[,,{775:7690,780:270,803:7692,807:7696,813:7698,817:7694}],69:[,,{768:200,769:201,770:202,771:7868,772:274,774:276,775:278,776:203,777:7866,780:282,783:516,785:518,803:7864,807:552,808:280,813:7704,816:7706}],70:[,,{775:7710}],71:[,,{769:500,770:284,772:7712,774:286,775:288,780:486,807:290}],72:[,,{770:292,775:7714,776:7718,780:542,803:7716,807:7720,814:7722}],73:[,,{768:204,769:205,770:206,771:296,772:298,774:300,775:304,776:207,777:7880,780:463,783:520,785:522,803:7882,808:302,816:7724}],74:[,,{770:308}],75:[,,{769:7728,780:488,803:7730,807:310,817:7732}],76:[,,{769:313,780:317,803:7734,807:315,813:7740,817:7738}],77:[,,{769:7742,775:7744,803:7746}],78:[,,{768:504,769:323,771:209,775:7748,780:327,803:7750,807:325,813:7754,817:7752}],79:[,,{768:210,769:211,770:212,771:213,772:332,774:334,775:558,776:214,777:7886,779:336,780:465,783:524,785:526,795:416,803:7884,808:490}],80:[,,{769:7764,775:7766}],82:[,,{769:340,775:7768,780:344,783:528,785:530,803:7770,807:342,817:7774}],83:[,,{769:346,770:348,775:7776,780:352,803:7778,806:536,807:350}],84:[,,{775:7786,780:356,803:7788,806:538,807:354,813:7792,817:7790}],85:[,,{768:217,769:218,770:219,771:360,772:362,774:364,776:220,777:7910,778:366,779:368,780:467,783:532,785:534,795:431,803:7908,804:7794,808:370,813:7798,816:7796}],86:[,,{771:7804,803:7806}],87:[,,{768:7808,769:7810,770:372,775:7814,776:7812,803:7816}],88:[,,{775:7818,776:7820}],89:[,,{768:7922,769:221,770:374,771:7928,772:562,775:7822,776:376,777:7926,803:7924}],90:[,,{769:377,770:7824,775:379,780:381,803:7826,817:7828}],97:[,,{768:224,769:225,770:226,771:227,772:257,774:259,775:551,776:228,777:7843,778:229,780:462,783:513,785:515,803:7841,805:7681,808:261}],98:[,,{775:7683,803:7685,817:7687}],99:[,,{769:263,770:265,775:267,780:269,807:231}],100:[,,{775:7691,780:271,803:7693,807:7697,813:7699,817:7695}],101:[,,{768:232,769:233,770:234,771:7869,772:275,774:277,775:279,776:235,777:7867,780:283,783:517,785:519,803:7865,807:553,808:281,813:7705,816:7707}],102:[,,{775:7711}],103:[,,{769:501,770:285,772:7713,774:287,775:289,780:487,807:291}],104:[,,{770:293,775:7715,776:7719,780:543,803:7717,807:7721,814:7723,817:7830}],105:[,,{768:236,769:237,770:238,771:297,772:299,774:301,776:239,777:7881,780:464,783:521,785:523,803:7883,808:303,816:7725}],106:[,,{770:309,780:496}],107:[,,{769:7729,780:489,803:7731,807:311,817:7733}],108:[,,{769:314,780:318,803:7735,807:316,813:7741,817:7739}],109:[,,{769:7743,775:7745,803:7747}],110:[,,{768:505,769:324,771:241,775:7749,780:328,803:7751,807:326,813:7755,817:7753}],111:[,,{768:242,769:243,770:244,771:245,772:333,774:335,775:559,776:246,777:7887,779:337,780:466,783:525,785:527,795:417,803:7885,808:491}],112:[,,{769:7765,775:7767}],114:[,,{769:341,775:7769,780:345,783:529,785:531,803:7771,807:343,817:7775}],115:[,,{769:347,770:349,775:7777,780:353,803:7779,806:537,807:351}],116:[,,{775:7787,776:7831,780:357,803:7789,806:539,807:355,813:7793,817:7791}],117:[,,{768:249,769:250,770:251,771:361,772:363,774:365,776:252,777:7911,778:367,779:369,780:468,783:533,785:535,795:432,803:7909,804:7795,808:371,813:7799,816:7797}],118:[,,{771:7805,803:7807}],119:[,,{768:7809,769:7811,770:373,775:7815,776:7813,778:7832,803:7817}],120:[,,{775:7819,776:7821}],121:[,,{768:7923,769:253,770:375,771:7929,772:563,775:7823,776:255,777:7927,778:7833,803:7925}],122:[,,{769:378,770:7825,775:380,780:382,803:7827,817:7829}],160:[[32],256],168:[[32,776],256,{768:8173,769:901,834:8129}],170:[[97],256],175:[[32,772],256],178:[[50],256],179:[[51],256],180:[[32,769],256],181:[[956],256],184:[[32,807],256],185:[[49],256],186:[[111],256],188:[[49,8260,52],256],189:[[49,8260,50],256],190:[[51,8260,52],256],192:[[65,768]],193:[[65,769]],194:[[65,770],,{768:7846,769:7844,771:7850,777:7848}],195:[[65,771]],196:[[65,776],,{772:478}],197:[[65,778],,{769:506}],198:[,,{769:508,772:482}],199:[[67,807],,{769:7688}],200:[[69,768]],201:[[69,769]],202:[[69,770],,{768:7872,769:7870,771:7876,777:7874}],203:[[69,776]],204:[[73,768]],205:[[73,769]],206:[[73,770]],207:[[73,776],,{769:7726}],209:[[78,771]],210:[[79,768]],211:[[79,769]],212:[[79,770],,{768:7890,769:7888,771:7894,777:7892}],213:[[79,771],,{769:7756,772:556,776:7758}],214:[[79,776],,{772:554}],216:[,,{769:510}],217:[[85,768]],218:[[85,769]],219:[[85,770]],220:[[85,776],,{768:475,769:471,772:469,780:473}],221:[[89,769]],224:[[97,768]],225:[[97,769]],226:[[97,770],,{768:7847,769:7845,771:7851,777:7849}],227:[[97,771]],228:[[97,776],,{772:479}],229:[[97,778],,{769:507}],230:[,,{769:509,772:483}],231:[[99,807],,{769:7689}],232:[[101,768]],233:[[101,769]],234:[[101,770],,{768:7873,769:7871,771:7877,777:7875}],235:[[101,776]],236:[[105,768]],237:[[105,769]],238:[[105,770]],239:[[105,776],,{769:7727}],241:[[110,771]],242:[[111,768]],243:[[111,769]],244:[[111,770],,{768:7891,769:7889,771:7895,777:7893}],245:[[111,771],,{769:7757,772:557,776:7759}],246:[[111,776],,{772:555}],248:[,,{769:511}],249:[[117,768]],250:[[117,769]],251:[[117,770]],252:[[117,776],,{768:476,769:472,772:470,780:474}],253:[[121,769]],255:[[121,776]]},
256:{256:[[65,772]],257:[[97,772]],258:[[65,774],,{768:7856,769:7854,771:7860,777:7858}],259:[[97,774],,{768:7857,769:7855,771:7861,777:7859}],260:[[65,808]],261:[[97,808]],262:[[67,769]],263:[[99,769]],264:[[67,770]],265:[[99,770]],266:[[67,775]],267:[[99,775]],268:[[67,780]],269:[[99,780]],270:[[68,780]],271:[[100,780]],274:[[69,772],,{768:7700,769:7702}],275:[[101,772],,{768:7701,769:7703}],276:[[69,774]],277:[[101,774]],278:[[69,775]],279:[[101,775]],280:[[69,808]],281:[[101,808]],282:[[69,780]],283:[[101,780]],284:[[71,770]],285:[[103,770]],286:[[71,774]],287:[[103,774]],288:[[71,775]],289:[[103,775]],290:[[71,807]],291:[[103,807]],292:[[72,770]],293:[[104,770]],296:[[73,771]],297:[[105,771]],298:[[73,772]],299:[[105,772]],300:[[73,774]],301:[[105,774]],302:[[73,808]],303:[[105,808]],304:[[73,775]],306:[[73,74],256],307:[[105,106],256],308:[[74,770]],309:[[106,770]],310:[[75,807]],311:[[107,807]],313:[[76,769]],314:[[108,769]],315:[[76,807]],316:[[108,807]],317:[[76,780]],318:[[108,780]],319:[[76,183],256],320:[[108,183],256],323:[[78,769]],324:[[110,769]],325:[[78,807]],326:[[110,807]],327:[[78,780]],328:[[110,780]],329:[[700,110],256],332:[[79,772],,{768:7760,769:7762}],333:[[111,772],,{768:7761,769:7763}],334:[[79,774]],335:[[111,774]],336:[[79,779]],337:[[111,779]],340:[[82,769]],341:[[114,769]],342:[[82,807]],343:[[114,807]],344:[[82,780]],345:[[114,780]],346:[[83,769],,{775:7780}],347:[[115,769],,{775:7781}],348:[[83,770]],349:[[115,770]],350:[[83,807]],351:[[115,807]],352:[[83,780],,{775:7782}],353:[[115,780],,{775:7783}],354:[[84,807]],355:[[116,807]],356:[[84,780]],357:[[116,780]],360:[[85,771],,{769:7800}],361:[[117,771],,{769:7801}],362:[[85,772],,{776:7802}],363:[[117,772],,{776:7803}],364:[[85,774]],365:[[117,774]],366:[[85,778]],367:[[117,778]],368:[[85,779]],369:[[117,779]],370:[[85,808]],371:[[117,808]],372:[[87,770]],373:[[119,770]],374:[[89,770]],375:[[121,770]],376:[[89,776]],377:[[90,769]],378:[[122,769]],379:[[90,775]],380:[[122,775]],381:[[90,780]],382:[[122,780]],383:[[115],256,{775:7835}],416:[[79,795],,{768:7900,769:7898,771:7904,777:7902,803:7906}],417:[[111,795],,{768:7901,769:7899,771:7905,777:7903,803:7907}],431:[[85,795],,{768:7914,769:7912,771:7918,777:7916,803:7920}],432:[[117,795],,{768:7915,769:7913,771:7919,777:7917,803:7921}],439:[,,{780:494}],452:[[68,381],256],453:[[68,382],256],454:[[100,382],256],455:[[76,74],256],456:[[76,106],256],457:[[108,106],256],458:[[78,74],256],459:[[78,106],256],460:[[110,106],256],461:[[65,780]],462:[[97,780]],463:[[73,780]],464:[[105,780]],465:[[79,780]],466:[[111,780]],467:[[85,780]],468:[[117,780]],469:[[220,772]],470:[[252,772]],471:[[220,769]],472:[[252,769]],473:[[220,780]],474:[[252,780]],475:[[220,768]],476:[[252,768]],478:[[196,772]],479:[[228,772]],480:[[550,772]],481:[[551,772]],482:[[198,772]],483:[[230,772]],486:[[71,780]],487:[[103,780]],488:[[75,780]],489:[[107,780]],490:[[79,808],,{772:492}],491:[[111,808],,{772:493}],492:[[490,772]],493:[[491,772]],494:[[439,780]],495:[[658,780]],496:[[106,780]],497:[[68,90],256],498:[[68,122],256],499:[[100,122],256],500:[[71,769]],501:[[103,769]],504:[[78,768]],505:[[110,768]],506:[[197,769]],507:[[229,769]],508:[[198,769]],509:[[230,769]],510:[[216,769]],511:[[248,769]],66045:[,220]},
512:{512:[[65,783]],513:[[97,783]],514:[[65,785]],515:[[97,785]],516:[[69,783]],517:[[101,783]],518:[[69,785]],519:[[101,785]],520:[[73,783]],521:[[105,783]],522:[[73,785]],523:[[105,785]],524:[[79,783]],525:[[111,783]],526:[[79,785]],527:[[111,785]],528:[[82,783]],529:[[114,783]],530:[[82,785]],531:[[114,785]],532:[[85,783]],533:[[117,783]],534:[[85,785]],535:[[117,785]],536:[[83,806]],537:[[115,806]],538:[[84,806]],539:[[116,806]],542:[[72,780]],543:[[104,780]],550:[[65,775],,{772:480}],551:[[97,775],,{772:481}],552:[[69,807],,{774:7708}],553:[[101,807],,{774:7709}],554:[[214,772]],555:[[246,772]],556:[[213,772]],557:[[245,772]],558:[[79,775],,{772:560}],559:[[111,775],,{772:561}],560:[[558,772]],561:[[559,772]],562:[[89,772]],563:[[121,772]],658:[,,{780:495}],688:[[104],256],689:[[614],256],690:[[106],256],691:[[114],256],692:[[633],256],693:[[635],256],694:[[641],256],695:[[119],256],696:[[121],256],728:[[32,774],256],729:[[32,775],256],730:[[32,778],256],731:[[32,808],256],732:[[32,771],256],733:[[32,779],256],736:[[611],256],737:[[108],256],738:[[115],256],739:[[120],256],740:[[661],256],66272:[,220]},
768:{768:[,230],769:[,230],770:[,230],771:[,230],772:[,230],773:[,230],774:[,230],775:[,230],776:[,230,{769:836}],777:[,230],778:[,230],779:[,230],780:[,230],781:[,230],782:[,230],783:[,230],784:[,230],785:[,230],786:[,230],787:[,230],788:[,230],789:[,232],790:[,220],791:[,220],792:[,220],793:[,220],794:[,232],795:[,216],796:[,220],797:[,220],798:[,220],799:[,220],800:[,220],801:[,202],802:[,202],803:[,220],804:[,220],805:[,220],806:[,220],807:[,202],808:[,202],809:[,220],810:[,220],811:[,220],812:[,220],813:[,220],814:[,220],815:[,220],816:[,220],817:[,220],818:[,220],819:[,220],820:[,1],821:[,1],822:[,1],823:[,1],824:[,1],825:[,220],826:[,220],827:[,220],828:[,220],829:[,230],830:[,230],831:[,230],832:[[768],230],833:[[769],230],834:[,230],835:[[787],230],836:[[776,769],230],837:[,240],838:[,230],839:[,220],840:[,220],841:[,220],842:[,230],843:[,230],844:[,230],845:[,220],846:[,220],848:[,230],849:[,230],850:[,230],851:[,220],852:[,220],853:[,220],854:[,220],855:[,230],856:[,232],857:[,220],858:[,220],859:[,230],860:[,233],861:[,234],862:[,234],863:[,233],864:[,234],865:[,234],866:[,233],867:[,230],868:[,230],869:[,230],870:[,230],871:[,230],872:[,230],873:[,230],874:[,230],875:[,230],876:[,230],877:[,230],878:[,230],879:[,230],884:[[697]],890:[[32,837],256],894:[[59]],900:[[32,769],256],901:[[168,769]],902:[[913,769]],903:[[183]],904:[[917,769]],905:[[919,769]],906:[[921,769]],908:[[927,769]],910:[[933,769]],911:[[937,769]],912:[[970,769]],913:[,,{768:8122,769:902,772:8121,774:8120,787:7944,788:7945,837:8124}],917:[,,{768:8136,769:904,787:7960,788:7961}],919:[,,{768:8138,769:905,787:7976,788:7977,837:8140}],921:[,,{768:8154,769:906,772:8153,774:8152,776:938,787:7992,788:7993}],927:[,,{768:8184,769:908,787:8008,788:8009}],929:[,,{788:8172}],933:[,,{768:8170,769:910,772:8169,774:8168,776:939,788:8025}],937:[,,{768:8186,769:911,787:8040,788:8041,837:8188}],938:[[921,776]],939:[[933,776]],940:[[945,769],,{837:8116}],941:[[949,769]],942:[[951,769],,{837:8132}],943:[[953,769]],944:[[971,769]],945:[,,{768:8048,769:940,772:8113,774:8112,787:7936,788:7937,834:8118,837:8115}],949:[,,{768:8050,769:941,787:7952,788:7953}],951:[,,{768:8052,769:942,787:7968,788:7969,834:8134,837:8131}],953:[,,{768:8054,769:943,772:8145,774:8144,776:970,787:7984,788:7985,834:8150}],959:[,,{768:8056,769:972,787:8000,788:8001}],961:[,,{787:8164,788:8165}],965:[,,{768:8058,769:973,772:8161,774:8160,776:971,787:8016,788:8017,834:8166}],969:[,,{768:8060,769:974,787:8032,788:8033,834:8182,837:8179}],970:[[953,776],,{768:8146,769:912,834:8151}],971:[[965,776],,{768:8162,769:944,834:8167}],972:[[959,769]],973:[[965,769]],974:[[969,769],,{837:8180}],976:[[946],256],977:[[952],256],978:[[933],256,{769:979,776:980}],979:[[978,769]],980:[[978,776]],981:[[966],256],982:[[960],256],1008:[[954],256],1009:[[961],256],1010:[[962],256],1012:[[920],256],1013:[[949],256],1017:[[931],256],66422:[,230],66423:[,230],66424:[,230],66425:[,230],66426:[,230]},
1024:{1024:[[1045,768]],1025:[[1045,776]],1027:[[1043,769]],1030:[,,{776:1031}],1031:[[1030,776]],1036:[[1050,769]],1037:[[1048,768]],1038:[[1059,774]],1040:[,,{774:1232,776:1234}],1043:[,,{769:1027}],1045:[,,{768:1024,774:1238,776:1025}],1046:[,,{774:1217,776:1244}],1047:[,,{776:1246}],1048:[,,{768:1037,772:1250,774:1049,776:1252}],1049:[[1048,774]],1050:[,,{769:1036}],1054:[,,{776:1254}],1059:[,,{772:1262,774:1038,776:1264,779:1266}],1063:[,,{776:1268}],1067:[,,{776:1272}],1069:[,,{776:1260}],1072:[,,{774:1233,776:1235}],1075:[,,{769:1107}],1077:[,,{768:1104,774:1239,776:1105}],1078:[,,{774:1218,776:1245}],1079:[,,{776:1247}],1080:[,,{768:1117,772:1251,774:1081,776:1253}],1081:[[1080,774]],1082:[,,{769:1116}],1086:[,,{776:1255}],1091:[,,{772:1263,774:1118,776:1265,779:1267}],1095:[,,{776:1269}],1099:[,,{776:1273}],1101:[,,{776:1261}],1104:[[1077,768]],1105:[[1077,776]],1107:[[1075,769]],1110:[,,{776:1111}],1111:[[1110,776]],1116:[[1082,769]],1117:[[1080,768]],1118:[[1091,774]],1140:[,,{783:1142}],1141:[,,{783:1143}],1142:[[1140,783]],1143:[[1141,783]],1155:[,230],1156:[,230],1157:[,230],1158:[,230],1159:[,230],1217:[[1046,774]],1218:[[1078,774]],1232:[[1040,774]],1233:[[1072,774]],1234:[[1040,776]],1235:[[1072,776]],1238:[[1045,774]],1239:[[1077,774]],1240:[,,{776:1242}],1241:[,,{776:1243}],1242:[[1240,776]],1243:[[1241,776]],1244:[[1046,776]],1245:[[1078,776]],1246:[[1047,776]],1247:[[1079,776]],1250:[[1048,772]],1251:[[1080,772]],1252:[[1048,776]],1253:[[1080,776]],1254:[[1054,776]],1255:[[1086,776]],1256:[,,{776:1258}],1257:[,,{776:1259}],1258:[[1256,776]],1259:[[1257,776]],1260:[[1069,776]],1261:[[1101,776]],1262:[[1059,772]],1263:[[1091,772]],1264:[[1059,776]],1265:[[1091,776]],1266:[[1059,779]],1267:[[1091,779]],1268:[[1063,776]],1269:[[1095,776]],1272:[[1067,776]],1273:[[1099,776]]},
1280:{1415:[[1381,1410],256],1425:[,220],1426:[,230],1427:[,230],1428:[,230],1429:[,230],1430:[,220],1431:[,230],1432:[,230],1433:[,230],1434:[,222],1435:[,220],1436:[,230],1437:[,230],1438:[,230],1439:[,230],1440:[,230],1441:[,230],1442:[,220],1443:[,220],1444:[,220],1445:[,220],1446:[,220],1447:[,220],1448:[,230],1449:[,230],1450:[,220],1451:[,230],1452:[,230],1453:[,222],1454:[,228],1455:[,230],1456:[,10],1457:[,11],1458:[,12],1459:[,13],1460:[,14],1461:[,15],1462:[,16],1463:[,17],1464:[,18],1465:[,19],1466:[,19],1467:[,20],1468:[,21],1469:[,22],1471:[,23],1473:[,24],1474:[,25],1476:[,230],1477:[,220],1479:[,18]},
1536:{1552:[,230],1553:[,230],1554:[,230],1555:[,230],1556:[,230],1557:[,230],1558:[,230],1559:[,230],1560:[,30],1561:[,31],1562:[,32],1570:[[1575,1619]],1571:[[1575,1620]],1572:[[1608,1620]],1573:[[1575,1621]],1574:[[1610,1620]],1575:[,,{1619:1570,1620:1571,1621:1573}],1608:[,,{1620:1572}],1610:[,,{1620:1574}],1611:[,27],1612:[,28],1613:[,29],1614:[,30],1615:[,31],1616:[,32],1617:[,33],1618:[,34],1619:[,230],1620:[,230],1621:[,220],1622:[,220],1623:[,230],1624:[,230],1625:[,230],1626:[,230],1627:[,230],1628:[,220],1629:[,230],1630:[,230],1631:[,220],1648:[,35],1653:[[1575,1652],256],1654:[[1608,1652],256],1655:[[1735,1652],256],1656:[[1610,1652],256],1728:[[1749,1620]],1729:[,,{1620:1730}],1730:[[1729,1620]],1746:[,,{1620:1747}],1747:[[1746,1620]],1749:[,,{1620:1728}],1750:[,230],1751:[,230],1752:[,230],1753:[,230],1754:[,230],1755:[,230],1756:[,230],1759:[,230],1760:[,230],1761:[,230],1762:[,230],1763:[,220],1764:[,230],1767:[,230],1768:[,230],1770:[,220],1771:[,230],1772:[,230],1773:[,220]},
1792:{1809:[,36],1840:[,230],1841:[,220],1842:[,230],1843:[,230],1844:[,220],1845:[,230],1846:[,230],1847:[,220],1848:[,220],1849:[,220],1850:[,230],1851:[,220],1852:[,220],1853:[,230],1854:[,220],1855:[,230],1856:[,230],1857:[,230],1858:[,220],1859:[,230],1860:[,220],1861:[,230],1862:[,220],1863:[,230],1864:[,220],1865:[,230],1866:[,230],2027:[,230],2028:[,230],2029:[,230],2030:[,230],2031:[,230],2032:[,230],2033:[,230],2034:[,220],2035:[,230]},
2048:{2070:[,230],2071:[,230],2072:[,230],2073:[,230],2075:[,230],2076:[,230],2077:[,230],2078:[,230],2079:[,230],2080:[,230],2081:[,230],2082:[,230],2083:[,230],2085:[,230],2086:[,230],2087:[,230],2089:[,230],2090:[,230],2091:[,230],2092:[,230],2093:[,230],2137:[,220],2138:[,220],2139:[,220],2276:[,230],2277:[,230],2278:[,220],2279:[,230],2280:[,230],2281:[,220],2282:[,230],2283:[,230],2284:[,230],2285:[,220],2286:[,220],2287:[,220],2288:[,27],2289:[,28],2290:[,29],2291:[,230],2292:[,230],2293:[,230],2294:[,220],2295:[,230],2296:[,230],2297:[,220],2298:[,220],2299:[,230],2300:[,230],2301:[,230],2302:[,230],2303:[,230]},
2304:{2344:[,,{2364:2345}],2345:[[2344,2364]],2352:[,,{2364:2353}],2353:[[2352,2364]],2355:[,,{2364:2356}],2356:[[2355,2364]],2364:[,7],2381:[,9],2385:[,230],2386:[,220],2387:[,230],2388:[,230],2392:[[2325,2364],512],2393:[[2326,2364],512],2394:[[2327,2364],512],2395:[[2332,2364],512],2396:[[2337,2364],512],2397:[[2338,2364],512],2398:[[2347,2364],512],2399:[[2351,2364],512],2492:[,7],2503:[,,{2494:2507,2519:2508}],2507:[[2503,2494]],2508:[[2503,2519]],2509:[,9],2524:[[2465,2492],512],2525:[[2466,2492],512],2527:[[2479,2492],512]},
2560:{2611:[[2610,2620],512],2614:[[2616,2620],512],2620:[,7],2637:[,9],2649:[[2582,2620],512],2650:[[2583,2620],512],2651:[[2588,2620],512],2654:[[2603,2620],512],2748:[,7],2765:[,9],68109:[,220],68111:[,230],68152:[,230],68153:[,1],68154:[,220],68159:[,9],68325:[,230],68326:[,220]},
2816:{2876:[,7],2887:[,,{2878:2891,2902:2888,2903:2892}],2888:[[2887,2902]],2891:[[2887,2878]],2892:[[2887,2903]],2893:[,9],2908:[[2849,2876],512],2909:[[2850,2876],512],2962:[,,{3031:2964}],2964:[[2962,3031]],3014:[,,{3006:3018,3031:3020}],3015:[,,{3006:3019}],3018:[[3014,3006]],3019:[[3015,3006]],3020:[[3014,3031]],3021:[,9]},
3072:{3142:[,,{3158:3144}],3144:[[3142,3158]],3149:[,9],3157:[,84],3158:[,91],3260:[,7],3263:[,,{3285:3264}],3264:[[3263,3285]],3270:[,,{3266:3274,3285:3271,3286:3272}],3271:[[3270,3285]],3272:[[3270,3286]],3274:[[3270,3266],,{3285:3275}],3275:[[3274,3285]],3277:[,9]},
3328:{3398:[,,{3390:3402,3415:3404}],3399:[,,{3390:3403}],3402:[[3398,3390]],3403:[[3399,3390]],3404:[[3398,3415]],3405:[,9],3530:[,9],3545:[,,{3530:3546,3535:3548,3551:3550}],3546:[[3545,3530]],3548:[[3545,3535],,{3530:3549}],3549:[[3548,3530]],3550:[[3545,3551]]},
3584:{3635:[[3661,3634],256],3640:[,103],3641:[,103],3642:[,9],3656:[,107],3657:[,107],3658:[,107],3659:[,107],3763:[[3789,3762],256],3768:[,118],3769:[,118],3784:[,122],3785:[,122],3786:[,122],3787:[,122],3804:[[3755,3737],256],3805:[[3755,3745],256]},
3840:{3852:[[3851],256],3864:[,220],3865:[,220],3893:[,220],3895:[,220],3897:[,216],3907:[[3906,4023],512],3917:[[3916,4023],512],3922:[[3921,4023],512],3927:[[3926,4023],512],3932:[[3931,4023],512],3945:[[3904,4021],512],3953:[,129],3954:[,130],3955:[[3953,3954],512],3956:[,132],3957:[[3953,3956],512],3958:[[4018,3968],512],3959:[[4018,3969],256],3960:[[4019,3968],512],3961:[[4019,3969],256],3962:[,130],3963:[,130],3964:[,130],3965:[,130],3968:[,130],3969:[[3953,3968],512],3970:[,230],3971:[,230],3972:[,9],3974:[,230],3975:[,230],3987:[[3986,4023],512],3997:[[3996,4023],512],4002:[[4001,4023],512],4007:[[4006,4023],512],4012:[[4011,4023],512],4025:[[3984,4021],512],4038:[,220]},
4096:{4133:[,,{4142:4134}],4134:[[4133,4142]],4151:[,7],4153:[,9],4154:[,9],4237:[,220],4348:[[4316],256],69702:[,9],69759:[,9],69785:[,,{69818:69786}],69786:[[69785,69818]],69787:[,,{69818:69788}],69788:[[69787,69818]],69797:[,,{69818:69803}],69803:[[69797,69818]],69817:[,9],69818:[,7]},
4352:{69888:[,230],69889:[,230],69890:[,230],69934:[[69937,69927]],69935:[[69938,69927]],69937:[,,{69927:69934}],69938:[,,{69927:69935}],69939:[,9],69940:[,9],70003:[,7],70080:[,9]},
4608:{70197:[,9],70198:[,7],70377:[,7],70378:[,9]},
4864:{4957:[,230],4958:[,230],4959:[,230],70460:[,7],70471:[,,{70462:70475,70487:70476}],70475:[[70471,70462]],70476:[[70471,70487]],70477:[,9],70502:[,230],70503:[,230],70504:[,230],70505:[,230],70506:[,230],70507:[,230],70508:[,230],70512:[,230],70513:[,230],70514:[,230],70515:[,230],70516:[,230]},
5120:{70841:[,,{70832:70844,70842:70843,70845:70846}],70843:[[70841,70842]],70844:[[70841,70832]],70846:[[70841,70845]],70850:[,9],70851:[,7]},
5376:{71096:[,,{71087:71098}],71097:[,,{71087:71099}],71098:[[71096,71087]],71099:[[71097,71087]],71103:[,9],71104:[,7]},
5632:{71231:[,9],71350:[,9],71351:[,7]},
5888:{5908:[,9],5940:[,9],6098:[,9],6109:[,230]},
6144:{6313:[,228]},
6400:{6457:[,222],6458:[,230],6459:[,220]},
6656:{6679:[,230],6680:[,220],6752:[,9],6773:[,230],6774:[,230],6775:[,230],6776:[,230],6777:[,230],6778:[,230],6779:[,230],6780:[,230],6783:[,220],6832:[,230],6833:[,230],6834:[,230],6835:[,230],6836:[,230],6837:[,220],6838:[,220],6839:[,220],6840:[,220],6841:[,220],6842:[,220],6843:[,230],6844:[,230],6845:[,220]},
6912:{6917:[,,{6965:6918}],6918:[[6917,6965]],6919:[,,{6965:6920}],6920:[[6919,6965]],6921:[,,{6965:6922}],6922:[[6921,6965]],6923:[,,{6965:6924}],6924:[[6923,6965]],6925:[,,{6965:6926}],6926:[[6925,6965]],6929:[,,{6965:6930}],6930:[[6929,6965]],6964:[,7],6970:[,,{6965:6971}],6971:[[6970,6965]],6972:[,,{6965:6973}],6973:[[6972,6965]],6974:[,,{6965:6976}],6975:[,,{6965:6977}],6976:[[6974,6965]],6977:[[6975,6965]],6978:[,,{6965:6979}],6979:[[6978,6965]],6980:[,9],7019:[,230],7020:[,220],7021:[,230],7022:[,230],7023:[,230],7024:[,230],7025:[,230],7026:[,230],7027:[,230],7082:[,9],7083:[,9],7142:[,7],7154:[,9],7155:[,9]},
7168:{7223:[,7],7376:[,230],7377:[,230],7378:[,230],7380:[,1],7381:[,220],7382:[,220],7383:[,220],7384:[,220],7385:[,220],7386:[,230],7387:[,230],7388:[,220],7389:[,220],7390:[,220],7391:[,220],7392:[,230],7394:[,1],7395:[,1],7396:[,1],7397:[,1],7398:[,1],7399:[,1],7400:[,1],7405:[,220],7412:[,230],7416:[,230],7417:[,230]},
7424:{7468:[[65],256],7469:[[198],256],7470:[[66],256],7472:[[68],256],7473:[[69],256],7474:[[398],256],7475:[[71],256],7476:[[72],256],7477:[[73],256],7478:[[74],256],7479:[[75],256],7480:[[76],256],7481:[[77],256],7482:[[78],256],7484:[[79],256],7485:[[546],256],7486:[[80],256],7487:[[82],256],7488:[[84],256],7489:[[85],256],7490:[[87],256],7491:[[97],256],7492:[[592],256],7493:[[593],256],7494:[[7426],256],7495:[[98],256],7496:[[100],256],7497:[[101],256],7498:[[601],256],7499:[[603],256],7500:[[604],256],7501:[[103],256],7503:[[107],256],7504:[[109],256],7505:[[331],256],7506:[[111],256],7507:[[596],256],7508:[[7446],256],7509:[[7447],256],7510:[[112],256],7511:[[116],256],7512:[[117],256],7513:[[7453],256],7514:[[623],256],7515:[[118],256],7516:[[7461],256],7517:[[946],256],7518:[[947],256],7519:[[948],256],7520:[[966],256],7521:[[967],256],7522:[[105],256],7523:[[114],256],7524:[[117],256],7525:[[118],256],7526:[[946],256],7527:[[947],256],7528:[[961],256],7529:[[966],256],7530:[[967],256],7544:[[1085],256],7579:[[594],256],7580:[[99],256],7581:[[597],256],7582:[[240],256],7583:[[604],256],7584:[[102],256],7585:[[607],256],7586:[[609],256],7587:[[613],256],7588:[[616],256],7589:[[617],256],7590:[[618],256],7591:[[7547],256],7592:[[669],256],7593:[[621],256],7594:[[7557],256],7595:[[671],256],7596:[[625],256],7597:[[624],256],7598:[[626],256],7599:[[627],256],7600:[[628],256],7601:[[629],256],7602:[[632],256],7603:[[642],256],7604:[[643],256],7605:[[427],256],7606:[[649],256],7607:[[650],256],7608:[[7452],256],7609:[[651],256],7610:[[652],256],7611:[[122],256],7612:[[656],256],7613:[[657],256],7614:[[658],256],7615:[[952],256],7616:[,230],7617:[,230],7618:[,220],7619:[,230],7620:[,230],7621:[,230],7622:[,230],7623:[,230],7624:[,230],7625:[,230],7626:[,220],7627:[,230],7628:[,230],7629:[,234],7630:[,214],7631:[,220],7632:[,202],7633:[,230],7634:[,230],7635:[,230],7636:[,230],7637:[,230],7638:[,230],7639:[,230],7640:[,230],7641:[,230],7642:[,230],7643:[,230],7644:[,230],7645:[,230],7646:[,230],7647:[,230],7648:[,230],7649:[,230],7650:[,230],7651:[,230],7652:[,230],7653:[,230],7654:[,230],7655:[,230],7656:[,230],7657:[,230],7658:[,230],7659:[,230],7660:[,230],7661:[,230],7662:[,230],7663:[,230],7664:[,230],7665:[,230],7666:[,230],7667:[,230],7668:[,230],7669:[,230],7676:[,233],7677:[,220],7678:[,230],7679:[,220]},
7680:{7680:[[65,805]],7681:[[97,805]],7682:[[66,775]],7683:[[98,775]],7684:[[66,803]],7685:[[98,803]],7686:[[66,817]],7687:[[98,817]],7688:[[199,769]],7689:[[231,769]],7690:[[68,775]],7691:[[100,775]],7692:[[68,803]],7693:[[100,803]],7694:[[68,817]],7695:[[100,817]],7696:[[68,807]],7697:[[100,807]],7698:[[68,813]],7699:[[100,813]],7700:[[274,768]],7701:[[275,768]],7702:[[274,769]],7703:[[275,769]],7704:[[69,813]],7705:[[101,813]],7706:[[69,816]],7707:[[101,816]],7708:[[552,774]],7709:[[553,774]],7710:[[70,775]],7711:[[102,775]],7712:[[71,772]],7713:[[103,772]],7714:[[72,775]],7715:[[104,775]],7716:[[72,803]],7717:[[104,803]],7718:[[72,776]],7719:[[104,776]],7720:[[72,807]],7721:[[104,807]],7722:[[72,814]],7723:[[104,814]],7724:[[73,816]],7725:[[105,816]],7726:[[207,769]],7727:[[239,769]],7728:[[75,769]],7729:[[107,769]],7730:[[75,803]],7731:[[107,803]],7732:[[75,817]],7733:[[107,817]],7734:[[76,803],,{772:7736}],7735:[[108,803],,{772:7737}],7736:[[7734,772]],7737:[[7735,772]],7738:[[76,817]],7739:[[108,817]],7740:[[76,813]],7741:[[108,813]],7742:[[77,769]],7743:[[109,769]],7744:[[77,775]],7745:[[109,775]],7746:[[77,803]],7747:[[109,803]],7748:[[78,775]],7749:[[110,775]],7750:[[78,803]],7751:[[110,803]],7752:[[78,817]],7753:[[110,817]],7754:[[78,813]],7755:[[110,813]],7756:[[213,769]],7757:[[245,769]],7758:[[213,776]],7759:[[245,776]],7760:[[332,768]],7761:[[333,768]],7762:[[332,769]],7763:[[333,769]],7764:[[80,769]],7765:[[112,769]],7766:[[80,775]],7767:[[112,775]],7768:[[82,775]],7769:[[114,775]],7770:[[82,803],,{772:7772}],7771:[[114,803],,{772:7773}],7772:[[7770,772]],7773:[[7771,772]],7774:[[82,817]],7775:[[114,817]],7776:[[83,775]],7777:[[115,775]],7778:[[83,803],,{775:7784}],7779:[[115,803],,{775:7785}],7780:[[346,775]],7781:[[347,775]],7782:[[352,775]],7783:[[353,775]],7784:[[7778,775]],7785:[[7779,775]],7786:[[84,775]],7787:[[116,775]],7788:[[84,803]],7789:[[116,803]],7790:[[84,817]],7791:[[116,817]],7792:[[84,813]],7793:[[116,813]],7794:[[85,804]],7795:[[117,804]],7796:[[85,816]],7797:[[117,816]],7798:[[85,813]],7799:[[117,813]],7800:[[360,769]],7801:[[361,769]],7802:[[362,776]],7803:[[363,776]],7804:[[86,771]],7805:[[118,771]],7806:[[86,803]],7807:[[118,803]],7808:[[87,768]],7809:[[119,768]],7810:[[87,769]],7811:[[119,769]],7812:[[87,776]],7813:[[119,776]],7814:[[87,775]],7815:[[119,775]],7816:[[87,803]],7817:[[119,803]],7818:[[88,775]],7819:[[120,775]],7820:[[88,776]],7821:[[120,776]],7822:[[89,775]],7823:[[121,775]],7824:[[90,770]],7825:[[122,770]],7826:[[90,803]],7827:[[122,803]],7828:[[90,817]],7829:[[122,817]],7830:[[104,817]],7831:[[116,776]],7832:[[119,778]],7833:[[121,778]],7834:[[97,702],256],7835:[[383,775]],7840:[[65,803],,{770:7852,774:7862}],7841:[[97,803],,{770:7853,774:7863}],7842:[[65,777]],7843:[[97,777]],7844:[[194,769]],7845:[[226,769]],7846:[[194,768]],7847:[[226,768]],7848:[[194,777]],7849:[[226,777]],7850:[[194,771]],7851:[[226,771]],7852:[[7840,770]],7853:[[7841,770]],7854:[[258,769]],7855:[[259,769]],7856:[[258,768]],7857:[[259,768]],7858:[[258,777]],7859:[[259,777]],7860:[[258,771]],7861:[[259,771]],7862:[[7840,774]],7863:[[7841,774]],7864:[[69,803],,{770:7878}],7865:[[101,803],,{770:7879}],7866:[[69,777]],7867:[[101,777]],7868:[[69,771]],7869:[[101,771]],7870:[[202,769]],7871:[[234,769]],7872:[[202,768]],7873:[[234,768]],7874:[[202,777]],7875:[[234,777]],7876:[[202,771]],7877:[[234,771]],7878:[[7864,770]],7879:[[7865,770]],7880:[[73,777]],7881:[[105,777]],7882:[[73,803]],7883:[[105,803]],7884:[[79,803],,{770:7896}],7885:[[111,803],,{770:7897}],7886:[[79,777]],7887:[[111,777]],7888:[[212,769]],7889:[[244,769]],7890:[[212,768]],7891:[[244,768]],7892:[[212,777]],7893:[[244,777]],7894:[[212,771]],7895:[[244,771]],7896:[[7884,770]],7897:[[7885,770]],7898:[[416,769]],7899:[[417,769]],7900:[[416,768]],7901:[[417,768]],7902:[[416,777]],7903:[[417,777]],7904:[[416,771]],7905:[[417,771]],7906:[[416,803]],7907:[[417,803]],7908:[[85,803]],7909:[[117,803]],7910:[[85,777]],7911:[[117,777]],7912:[[431,769]],7913:[[432,769]],7914:[[431,768]],7915:[[432,768]],7916:[[431,777]],7917:[[432,777]],7918:[[431,771]],7919:[[432,771]],7920:[[431,803]],7921:[[432,803]],7922:[[89,768]],7923:[[121,768]],7924:[[89,803]],7925:[[121,803]],7926:[[89,777]],7927:[[121,777]],7928:[[89,771]],7929:[[121,771]]},
7936:{7936:[[945,787],,{768:7938,769:7940,834:7942,837:8064}],7937:[[945,788],,{768:7939,769:7941,834:7943,837:8065}],7938:[[7936,768],,{837:8066}],7939:[[7937,768],,{837:8067}],7940:[[7936,769],,{837:8068}],7941:[[7937,769],,{837:8069}],7942:[[7936,834],,{837:8070}],7943:[[7937,834],,{837:8071}],7944:[[913,787],,{768:7946,769:7948,834:7950,837:8072}],7945:[[913,788],,{768:7947,769:7949,834:7951,837:8073}],7946:[[7944,768],,{837:8074}],7947:[[7945,768],,{837:8075}],7948:[[7944,769],,{837:8076}],7949:[[7945,769],,{837:8077}],7950:[[7944,834],,{837:8078}],7951:[[7945,834],,{837:8079}],7952:[[949,787],,{768:7954,769:7956}],7953:[[949,788],,{768:7955,769:7957}],7954:[[7952,768]],7955:[[7953,768]],7956:[[7952,769]],7957:[[7953,769]],7960:[[917,787],,{768:7962,769:7964}],7961:[[917,788],,{768:7963,769:7965}],7962:[[7960,768]],7963:[[7961,768]],7964:[[7960,769]],7965:[[7961,769]],7968:[[951,787],,{768:7970,769:7972,834:7974,837:8080}],7969:[[951,788],,{768:7971,769:7973,834:7975,837:8081}],7970:[[7968,768],,{837:8082}],7971:[[7969,768],,{837:8083}],7972:[[7968,769],,{837:8084}],7973:[[7969,769],,{837:8085}],7974:[[7968,834],,{837:8086}],7975:[[7969,834],,{837:8087}],7976:[[919,787],,{768:7978,769:7980,834:7982,837:8088}],7977:[[919,788],,{768:7979,769:7981,834:7983,837:8089}],7978:[[7976,768],,{837:8090}],7979:[[7977,768],,{837:8091}],7980:[[7976,769],,{837:8092}],7981:[[7977,769],,{837:8093}],7982:[[7976,834],,{837:8094}],7983:[[7977,834],,{837:8095}],7984:[[953,787],,{768:7986,769:7988,834:7990}],7985:[[953,788],,{768:7987,769:7989,834:7991}],7986:[[7984,768]],7987:[[7985,768]],7988:[[7984,769]],7989:[[7985,769]],7990:[[7984,834]],7991:[[7985,834]],7992:[[921,787],,{768:7994,769:7996,834:7998}],7993:[[921,788],,{768:7995,769:7997,834:7999}],7994:[[7992,768]],7995:[[7993,768]],7996:[[7992,769]],7997:[[7993,769]],7998:[[7992,834]],7999:[[7993,834]],8000:[[959,787],,{768:8002,769:8004}],8001:[[959,788],,{768:8003,769:8005}],8002:[[8000,768]],8003:[[8001,768]],8004:[[8000,769]],8005:[[8001,769]],8008:[[927,787],,{768:8010,769:8012}],8009:[[927,788],,{768:8011,769:8013}],8010:[[8008,768]],8011:[[8009,768]],8012:[[8008,769]],8013:[[8009,769]],8016:[[965,787],,{768:8018,769:8020,834:8022}],8017:[[965,788],,{768:8019,769:8021,834:8023}],8018:[[8016,768]],8019:[[8017,768]],8020:[[8016,769]],8021:[[8017,769]],8022:[[8016,834]],8023:[[8017,834]],8025:[[933,788],,{768:8027,769:8029,834:8031}],8027:[[8025,768]],8029:[[8025,769]],8031:[[8025,834]],8032:[[969,787],,{768:8034,769:8036,834:8038,837:8096}],8033:[[969,788],,{768:8035,769:8037,834:8039,837:8097}],8034:[[8032,768],,{837:8098}],8035:[[8033,768],,{837:8099}],8036:[[8032,769],,{837:8100}],8037:[[8033,769],,{837:8101}],8038:[[8032,834],,{837:8102}],8039:[[8033,834],,{837:8103}],8040:[[937,787],,{768:8042,769:8044,834:8046,837:8104}],8041:[[937,788],,{768:8043,769:8045,834:8047,837:8105}],8042:[[8040,768],,{837:8106}],8043:[[8041,768],,{837:8107}],8044:[[8040,769],,{837:8108}],8045:[[8041,769],,{837:8109}],8046:[[8040,834],,{837:8110}],8047:[[8041,834],,{837:8111}],8048:[[945,768],,{837:8114}],8049:[[940]],8050:[[949,768]],8051:[[941]],8052:[[951,768],,{837:8130}],8053:[[942]],8054:[[953,768]],8055:[[943]],8056:[[959,768]],8057:[[972]],8058:[[965,768]],8059:[[973]],8060:[[969,768],,{837:8178}],8061:[[974]],8064:[[7936,837]],8065:[[7937,837]],8066:[[7938,837]],8067:[[7939,837]],8068:[[7940,837]],8069:[[7941,837]],8070:[[7942,837]],8071:[[7943,837]],8072:[[7944,837]],8073:[[7945,837]],8074:[[7946,837]],8075:[[7947,837]],8076:[[7948,837]],8077:[[7949,837]],8078:[[7950,837]],8079:[[7951,837]],8080:[[7968,837]],8081:[[7969,837]],8082:[[7970,837]],8083:[[7971,837]],8084:[[7972,837]],8085:[[7973,837]],8086:[[7974,837]],8087:[[7975,837]],8088:[[7976,837]],8089:[[7977,837]],8090:[[7978,837]],8091:[[7979,837]],8092:[[7980,837]],8093:[[7981,837]],8094:[[7982,837]],8095:[[7983,837]],8096:[[8032,837]],8097:[[8033,837]],8098:[[8034,837]],8099:[[8035,837]],8100:[[8036,837]],8101:[[8037,837]],8102:[[8038,837]],8103:[[8039,837]],8104:[[8040,837]],8105:[[8041,837]],8106:[[8042,837]],8107:[[8043,837]],8108:[[8044,837]],8109:[[8045,837]],8110:[[8046,837]],8111:[[8047,837]],8112:[[945,774]],8113:[[945,772]],8114:[[8048,837]],8115:[[945,837]],8116:[[940,837]],8118:[[945,834],,{837:8119}],8119:[[8118,837]],8120:[[913,774]],8121:[[913,772]],8122:[[913,768]],8123:[[902]],8124:[[913,837]],8125:[[32,787],256],8126:[[953]],8127:[[32,787],256,{768:8141,769:8142,834:8143}],8128:[[32,834],256],8129:[[168,834]],8130:[[8052,837]],8131:[[951,837]],8132:[[942,837]],8134:[[951,834],,{837:8135}],8135:[[8134,837]],8136:[[917,768]],8137:[[904]],8138:[[919,768]],8139:[[905]],8140:[[919,837]],8141:[[8127,768]],8142:[[8127,769]],8143:[[8127,834]],8144:[[953,774]],8145:[[953,772]],8146:[[970,768]],8147:[[912]],8150:[[953,834]],8151:[[970,834]],8152:[[921,774]],8153:[[921,772]],8154:[[921,768]],8155:[[906]],8157:[[8190,768]],8158:[[8190,769]],8159:[[8190,834]],8160:[[965,774]],8161:[[965,772]],8162:[[971,768]],8163:[[944]],8164:[[961,787]],8165:[[961,788]],8166:[[965,834]],8167:[[971,834]],8168:[[933,774]],8169:[[933,772]],8170:[[933,768]],8171:[[910]],8172:[[929,788]],8173:[[168,768]],8174:[[901]],8175:[[96]],8178:[[8060,837]],8179:[[969,837]],8180:[[974,837]],8182:[[969,834],,{837:8183}],8183:[[8182,837]],8184:[[927,768]],8185:[[908]],8186:[[937,768]],8187:[[911]],8188:[[937,837]],8189:[[180]],8190:[[32,788],256,{768:8157,769:8158,834:8159}]},
8192:{8192:[[8194]],8193:[[8195]],8194:[[32],256],8195:[[32],256],8196:[[32],256],8197:[[32],256],8198:[[32],256],8199:[[32],256],8200:[[32],256],8201:[[32],256],8202:[[32],256],8209:[[8208],256],8215:[[32,819],256],8228:[[46],256],8229:[[46,46],256],8230:[[46,46,46],256],8239:[[32],256],8243:[[8242,8242],256],8244:[[8242,8242,8242],256],8246:[[8245,8245],256],8247:[[8245,8245,8245],256],8252:[[33,33],256],8254:[[32,773],256],8263:[[63,63],256],8264:[[63,33],256],8265:[[33,63],256],8279:[[8242,8242,8242,8242],256],8287:[[32],256],8304:[[48],256],8305:[[105],256],8308:[[52],256],8309:[[53],256],8310:[[54],256],8311:[[55],256],8312:[[56],256],8313:[[57],256],8314:[[43],256],8315:[[8722],256],8316:[[61],256],8317:[[40],256],8318:[[41],256],8319:[[110],256],8320:[[48],256],8321:[[49],256],8322:[[50],256],8323:[[51],256],8324:[[52],256],8325:[[53],256],8326:[[54],256],8327:[[55],256],8328:[[56],256],8329:[[57],256],8330:[[43],256],8331:[[8722],256],8332:[[61],256],8333:[[40],256],8334:[[41],256],8336:[[97],256],8337:[[101],256],8338:[[111],256],8339:[[120],256],8340:[[601],256],8341:[[104],256],8342:[[107],256],8343:[[108],256],8344:[[109],256],8345:[[110],256],8346:[[112],256],8347:[[115],256],8348:[[116],256],8360:[[82,115],256],8400:[,230],8401:[,230],8402:[,1],8403:[,1],8404:[,230],8405:[,230],8406:[,230],8407:[,230],8408:[,1],8409:[,1],8410:[,1],8411:[,230],8412:[,230],8417:[,230],8421:[,1],8422:[,1],8423:[,230],8424:[,220],8425:[,230],8426:[,1],8427:[,1],8428:[,220],8429:[,220],8430:[,220],8431:[,220],8432:[,230]},
8448:{8448:[[97,47,99],256],8449:[[97,47,115],256],8450:[[67],256],8451:[[176,67],256],8453:[[99,47,111],256],8454:[[99,47,117],256],8455:[[400],256],8457:[[176,70],256],8458:[[103],256],8459:[[72],256],8460:[[72],256],8461:[[72],256],8462:[[104],256],8463:[[295],256],8464:[[73],256],8465:[[73],256],8466:[[76],256],8467:[[108],256],8469:[[78],256],8470:[[78,111],256],8473:[[80],256],8474:[[81],256],8475:[[82],256],8476:[[82],256],8477:[[82],256],8480:[[83,77],256],8481:[[84,69,76],256],8482:[[84,77],256],8484:[[90],256],8486:[[937]],8488:[[90],256],8490:[[75]],8491:[[197]],8492:[[66],256],8493:[[67],256],8495:[[101],256],8496:[[69],256],8497:[[70],256],8499:[[77],256],8500:[[111],256],8501:[[1488],256],8502:[[1489],256],8503:[[1490],256],8504:[[1491],256],8505:[[105],256],8507:[[70,65,88],256],8508:[[960],256],8509:[[947],256],8510:[[915],256],8511:[[928],256],8512:[[8721],256],8517:[[68],256],8518:[[100],256],8519:[[101],256],8520:[[105],256],8521:[[106],256],8528:[[49,8260,55],256],8529:[[49,8260,57],256],8530:[[49,8260,49,48],256],8531:[[49,8260,51],256],8532:[[50,8260,51],256],8533:[[49,8260,53],256],8534:[[50,8260,53],256],8535:[[51,8260,53],256],8536:[[52,8260,53],256],8537:[[49,8260,54],256],8538:[[53,8260,54],256],8539:[[49,8260,56],256],8540:[[51,8260,56],256],8541:[[53,8260,56],256],8542:[[55,8260,56],256],8543:[[49,8260],256],8544:[[73],256],8545:[[73,73],256],8546:[[73,73,73],256],8547:[[73,86],256],8548:[[86],256],8549:[[86,73],256],8550:[[86,73,73],256],8551:[[86,73,73,73],256],8552:[[73,88],256],8553:[[88],256],8554:[[88,73],256],8555:[[88,73,73],256],8556:[[76],256],8557:[[67],256],8558:[[68],256],8559:[[77],256],8560:[[105],256],8561:[[105,105],256],8562:[[105,105,105],256],8563:[[105,118],256],8564:[[118],256],8565:[[118,105],256],8566:[[118,105,105],256],8567:[[118,105,105,105],256],8568:[[105,120],256],8569:[[120],256],8570:[[120,105],256],8571:[[120,105,105],256],8572:[[108],256],8573:[[99],256],8574:[[100],256],8575:[[109],256],8585:[[48,8260,51],256],8592:[,,{824:8602}],8594:[,,{824:8603}],8596:[,,{824:8622}],8602:[[8592,824]],8603:[[8594,824]],8622:[[8596,824]],8653:[[8656,824]],8654:[[8660,824]],8655:[[8658,824]],8656:[,,{824:8653}],8658:[,,{824:8655}],8660:[,,{824:8654}]},
8704:{8707:[,,{824:8708}],8708:[[8707,824]],8712:[,,{824:8713}],8713:[[8712,824]],8715:[,,{824:8716}],8716:[[8715,824]],8739:[,,{824:8740}],8740:[[8739,824]],8741:[,,{824:8742}],8742:[[8741,824]],8748:[[8747,8747],256],8749:[[8747,8747,8747],256],8751:[[8750,8750],256],8752:[[8750,8750,8750],256],8764:[,,{824:8769}],8769:[[8764,824]],8771:[,,{824:8772}],8772:[[8771,824]],8773:[,,{824:8775}],8775:[[8773,824]],8776:[,,{824:8777}],8777:[[8776,824]],8781:[,,{824:8813}],8800:[[61,824]],8801:[,,{824:8802}],8802:[[8801,824]],8804:[,,{824:8816}],8805:[,,{824:8817}],8813:[[8781,824]],8814:[[60,824]],8815:[[62,824]],8816:[[8804,824]],8817:[[8805,824]],8818:[,,{824:8820}],8819:[,,{824:8821}],8820:[[8818,824]],8821:[[8819,824]],8822:[,,{824:8824}],8823:[,,{824:8825}],8824:[[8822,824]],8825:[[8823,824]],8826:[,,{824:8832}],8827:[,,{824:8833}],8828:[,,{824:8928}],8829:[,,{824:8929}],8832:[[8826,824]],8833:[[8827,824]],8834:[,,{824:8836}],8835:[,,{824:8837}],8836:[[8834,824]],8837:[[8835,824]],8838:[,,{824:8840}],8839:[,,{824:8841}],8840:[[8838,824]],8841:[[8839,824]],8849:[,,{824:8930}],8850:[,,{824:8931}],8866:[,,{824:8876}],8872:[,,{824:8877}],8873:[,,{824:8878}],8875:[,,{824:8879}],8876:[[8866,824]],8877:[[8872,824]],8878:[[8873,824]],8879:[[8875,824]],8882:[,,{824:8938}],8883:[,,{824:8939}],8884:[,,{824:8940}],8885:[,,{824:8941}],8928:[[8828,824]],8929:[[8829,824]],8930:[[8849,824]],8931:[[8850,824]],8938:[[8882,824]],8939:[[8883,824]],8940:[[8884,824]],8941:[[8885,824]]},
8960:{9001:[[12296]],9002:[[12297]]},
9216:{9312:[[49],256],9313:[[50],256],9314:[[51],256],9315:[[52],256],9316:[[53],256],9317:[[54],256],9318:[[55],256],9319:[[56],256],9320:[[57],256],9321:[[49,48],256],9322:[[49,49],256],9323:[[49,50],256],9324:[[49,51],256],9325:[[49,52],256],9326:[[49,53],256],9327:[[49,54],256],9328:[[49,55],256],9329:[[49,56],256],9330:[[49,57],256],9331:[[50,48],256],9332:[[40,49,41],256],9333:[[40,50,41],256],9334:[[40,51,41],256],9335:[[40,52,41],256],9336:[[40,53,41],256],9337:[[40,54,41],256],9338:[[40,55,41],256],9339:[[40,56,41],256],9340:[[40,57,41],256],9341:[[40,49,48,41],256],9342:[[40,49,49,41],256],9343:[[40,49,50,41],256],9344:[[40,49,51,41],256],9345:[[40,49,52,41],256],9346:[[40,49,53,41],256],9347:[[40,49,54,41],256],9348:[[40,49,55,41],256],9349:[[40,49,56,41],256],9350:[[40,49,57,41],256],9351:[[40,50,48,41],256],9352:[[49,46],256],9353:[[50,46],256],9354:[[51,46],256],9355:[[52,46],256],9356:[[53,46],256],9357:[[54,46],256],9358:[[55,46],256],9359:[[56,46],256],9360:[[57,46],256],9361:[[49,48,46],256],9362:[[49,49,46],256],9363:[[49,50,46],256],9364:[[49,51,46],256],9365:[[49,52,46],256],9366:[[49,53,46],256],9367:[[49,54,46],256],9368:[[49,55,46],256],9369:[[49,56,46],256],9370:[[49,57,46],256],9371:[[50,48,46],256],9372:[[40,97,41],256],9373:[[40,98,41],256],9374:[[40,99,41],256],9375:[[40,100,41],256],9376:[[40,101,41],256],9377:[[40,102,41],256],9378:[[40,103,41],256],9379:[[40,104,41],256],9380:[[40,105,41],256],9381:[[40,106,41],256],9382:[[40,107,41],256],9383:[[40,108,41],256],9384:[[40,109,41],256],9385:[[40,110,41],256],9386:[[40,111,41],256],9387:[[40,112,41],256],9388:[[40,113,41],256],9389:[[40,114,41],256],9390:[[40,115,41],256],9391:[[40,116,41],256],9392:[[40,117,41],256],9393:[[40,118,41],256],9394:[[40,119,41],256],9395:[[40,120,41],256],9396:[[40,121,41],256],9397:[[40,122,41],256],9398:[[65],256],9399:[[66],256],9400:[[67],256],9401:[[68],256],9402:[[69],256],9403:[[70],256],9404:[[71],256],9405:[[72],256],9406:[[73],256],9407:[[74],256],9408:[[75],256],9409:[[76],256],9410:[[77],256],9411:[[78],256],9412:[[79],256],9413:[[80],256],9414:[[81],256],9415:[[82],256],9416:[[83],256],9417:[[84],256],9418:[[85],256],9419:[[86],256],9420:[[87],256],9421:[[88],256],9422:[[89],256],9423:[[90],256],9424:[[97],256],9425:[[98],256],9426:[[99],256],9427:[[100],256],9428:[[101],256],9429:[[102],256],9430:[[103],256],9431:[[104],256],9432:[[105],256],9433:[[106],256],9434:[[107],256],9435:[[108],256],9436:[[109],256],9437:[[110],256],9438:[[111],256],9439:[[112],256],9440:[[113],256],9441:[[114],256],9442:[[115],256],9443:[[116],256],9444:[[117],256],9445:[[118],256],9446:[[119],256],9447:[[120],256],9448:[[121],256],9449:[[122],256],9450:[[48],256]},
10752:{10764:[[8747,8747,8747,8747],256],10868:[[58,58,61],256],10869:[[61,61],256],10870:[[61,61,61],256],10972:[[10973,824],512]},
11264:{11388:[[106],256],11389:[[86],256],11503:[,230],11504:[,230],11505:[,230]},
11520:{11631:[[11617],256],11647:[,9],11744:[,230],11745:[,230],11746:[,230],11747:[,230],11748:[,230],11749:[,230],11750:[,230],11751:[,230],11752:[,230],11753:[,230],11754:[,230],11755:[,230],11756:[,230],11757:[,230],11758:[,230],11759:[,230],11760:[,230],11761:[,230],11762:[,230],11763:[,230],11764:[,230],11765:[,230],11766:[,230],11767:[,230],11768:[,230],11769:[,230],11770:[,230],11771:[,230],11772:[,230],11773:[,230],11774:[,230],11775:[,230]},
11776:{11935:[[27597],256],12019:[[40863],256]},
12032:{12032:[[19968],256],12033:[[20008],256],12034:[[20022],256],12035:[[20031],256],12036:[[20057],256],12037:[[20101],256],12038:[[20108],256],12039:[[20128],256],12040:[[20154],256],12041:[[20799],256],12042:[[20837],256],12043:[[20843],256],12044:[[20866],256],12045:[[20886],256],12046:[[20907],256],12047:[[20960],256],12048:[[20981],256],12049:[[20992],256],12050:[[21147],256],12051:[[21241],256],12052:[[21269],256],12053:[[21274],256],12054:[[21304],256],12055:[[21313],256],12056:[[21340],256],12057:[[21353],256],12058:[[21378],256],12059:[[21430],256],12060:[[21448],256],12061:[[21475],256],12062:[[22231],256],12063:[[22303],256],12064:[[22763],256],12065:[[22786],256],12066:[[22794],256],12067:[[22805],256],12068:[[22823],256],12069:[[22899],256],12070:[[23376],256],12071:[[23424],256],12072:[[23544],256],12073:[[23567],256],12074:[[23586],256],12075:[[23608],256],12076:[[23662],256],12077:[[23665],256],12078:[[24027],256],12079:[[24037],256],12080:[[24049],256],12081:[[24062],256],12082:[[24178],256],12083:[[24186],256],12084:[[24191],256],12085:[[24308],256],12086:[[24318],256],12087:[[24331],256],12088:[[24339],256],12089:[[24400],256],12090:[[24417],256],12091:[[24435],256],12092:[[24515],256],12093:[[25096],256],12094:[[25142],256],12095:[[25163],256],12096:[[25903],256],12097:[[25908],256],12098:[[25991],256],12099:[[26007],256],12100:[[26020],256],12101:[[26041],256],12102:[[26080],256],12103:[[26085],256],12104:[[26352],256],12105:[[26376],256],12106:[[26408],256],12107:[[27424],256],12108:[[27490],256],12109:[[27513],256],12110:[[27571],256],12111:[[27595],256],12112:[[27604],256],12113:[[27611],256],12114:[[27663],256],12115:[[27668],256],12116:[[27700],256],12117:[[28779],256],12118:[[29226],256],12119:[[29238],256],12120:[[29243],256],12121:[[29247],256],12122:[[29255],256],12123:[[29273],256],12124:[[29275],256],12125:[[29356],256],12126:[[29572],256],12127:[[29577],256],12128:[[29916],256],12129:[[29926],256],12130:[[29976],256],12131:[[29983],256],12132:[[29992],256],12133:[[30000],256],12134:[[30091],256],12135:[[30098],256],12136:[[30326],256],12137:[[30333],256],12138:[[30382],256],12139:[[30399],256],12140:[[30446],256],12141:[[30683],256],12142:[[30690],256],12143:[[30707],256],12144:[[31034],256],12145:[[31160],256],12146:[[31166],256],12147:[[31348],256],12148:[[31435],256],12149:[[31481],256],12150:[[31859],256],12151:[[31992],256],12152:[[32566],256],12153:[[32593],256],12154:[[32650],256],12155:[[32701],256],12156:[[32769],256],12157:[[32780],256],12158:[[32786],256],12159:[[32819],256],12160:[[32895],256],12161:[[32905],256],12162:[[33251],256],12163:[[33258],256],12164:[[33267],256],12165:[[33276],256],12166:[[33292],256],12167:[[33307],256],12168:[[33311],256],12169:[[33390],256],12170:[[33394],256],12171:[[33400],256],12172:[[34381],256],12173:[[34411],256],12174:[[34880],256],12175:[[34892],256],12176:[[34915],256],12177:[[35198],256],12178:[[35211],256],12179:[[35282],256],12180:[[35328],256],12181:[[35895],256],12182:[[35910],256],12183:[[35925],256],12184:[[35960],256],12185:[[35997],256],12186:[[36196],256],12187:[[36208],256],12188:[[36275],256],12189:[[36523],256],12190:[[36554],256],12191:[[36763],256],12192:[[36784],256],12193:[[36789],256],12194:[[37009],256],12195:[[37193],256],12196:[[37318],256],12197:[[37324],256],12198:[[37329],256],12199:[[38263],256],12200:[[38272],256],12201:[[38428],256],12202:[[38582],256],12203:[[38585],256],12204:[[38632],256],12205:[[38737],256],12206:[[38750],256],12207:[[38754],256],12208:[[38761],256],12209:[[38859],256],12210:[[38893],256],12211:[[38899],256],12212:[[38913],256],12213:[[39080],256],12214:[[39131],256],12215:[[39135],256],12216:[[39318],256],12217:[[39321],256],12218:[[39340],256],12219:[[39592],256],12220:[[39640],256],12221:[[39647],256],12222:[[39717],256],12223:[[39727],256],12224:[[39730],256],12225:[[39740],256],12226:[[39770],256],12227:[[40165],256],12228:[[40565],256],12229:[[40575],256],12230:[[40613],256],12231:[[40635],256],12232:[[40643],256],12233:[[40653],256],12234:[[40657],256],12235:[[40697],256],12236:[[40701],256],12237:[[40718],256],12238:[[40723],256],12239:[[40736],256],12240:[[40763],256],12241:[[40778],256],12242:[[40786],256],12243:[[40845],256],12244:[[40860],256],12245:[[40864],256]},
12288:{12288:[[32],256],12330:[,218],12331:[,228],12332:[,232],12333:[,222],12334:[,224],12335:[,224],12342:[[12306],256],12344:[[21313],256],12345:[[21316],256],12346:[[21317],256],12358:[,,{12441:12436}],12363:[,,{12441:12364}],12364:[[12363,12441]],12365:[,,{12441:12366}],12366:[[12365,12441]],12367:[,,{12441:12368}],12368:[[12367,12441]],12369:[,,{12441:12370}],12370:[[12369,12441]],12371:[,,{12441:12372}],12372:[[12371,12441]],12373:[,,{12441:12374}],12374:[[12373,12441]],12375:[,,{12441:12376}],12376:[[12375,12441]],12377:[,,{12441:12378}],12378:[[12377,12441]],12379:[,,{12441:12380}],12380:[[12379,12441]],12381:[,,{12441:12382}],12382:[[12381,12441]],12383:[,,{12441:12384}],12384:[[12383,12441]],12385:[,,{12441:12386}],12386:[[12385,12441]],12388:[,,{12441:12389}],12389:[[12388,12441]],12390:[,,{12441:12391}],12391:[[12390,12441]],12392:[,,{12441:12393}],12393:[[12392,12441]],12399:[,,{12441:12400,12442:12401}],12400:[[12399,12441]],12401:[[12399,12442]],12402:[,,{12441:12403,12442:12404}],12403:[[12402,12441]],12404:[[12402,12442]],12405:[,,{12441:12406,12442:12407}],12406:[[12405,12441]],12407:[[12405,12442]],12408:[,,{12441:12409,12442:12410}],12409:[[12408,12441]],12410:[[12408,12442]],12411:[,,{12441:12412,12442:12413}],12412:[[12411,12441]],12413:[[12411,12442]],12436:[[12358,12441]],12441:[,8],12442:[,8],12443:[[32,12441],256],12444:[[32,12442],256],12445:[,,{12441:12446}],12446:[[12445,12441]],12447:[[12424,12426],256],12454:[,,{12441:12532}],12459:[,,{12441:12460}],12460:[[12459,12441]],12461:[,,{12441:12462}],12462:[[12461,12441]],12463:[,,{12441:12464}],12464:[[12463,12441]],12465:[,,{12441:12466}],12466:[[12465,12441]],12467:[,,{12441:12468}],12468:[[12467,12441]],12469:[,,{12441:12470}],12470:[[12469,12441]],12471:[,,{12441:12472}],12472:[[12471,12441]],12473:[,,{12441:12474}],12474:[[12473,12441]],12475:[,,{12441:12476}],12476:[[12475,12441]],12477:[,,{12441:12478}],12478:[[12477,12441]],12479:[,,{12441:12480}],12480:[[12479,12441]],12481:[,,{12441:12482}],12482:[[12481,12441]],12484:[,,{12441:12485}],12485:[[12484,12441]],12486:[,,{12441:12487}],12487:[[12486,12441]],12488:[,,{12441:12489}],12489:[[12488,12441]],12495:[,,{12441:12496,12442:12497}],12496:[[12495,12441]],12497:[[12495,12442]],12498:[,,{12441:12499,12442:12500}],12499:[[12498,12441]],12500:[[12498,12442]],12501:[,,{12441:12502,12442:12503}],12502:[[12501,12441]],12503:[[12501,12442]],12504:[,,{12441:12505,12442:12506}],12505:[[12504,12441]],12506:[[12504,12442]],12507:[,,{12441:12508,12442:12509}],12508:[[12507,12441]],12509:[[12507,12442]],12527:[,,{12441:12535}],12528:[,,{12441:12536}],12529:[,,{12441:12537}],12530:[,,{12441:12538}],12532:[[12454,12441]],12535:[[12527,12441]],12536:[[12528,12441]],12537:[[12529,12441]],12538:[[12530,12441]],12541:[,,{12441:12542}],12542:[[12541,12441]],12543:[[12467,12488],256]},
12544:{12593:[[4352],256],12594:[[4353],256],12595:[[4522],256],12596:[[4354],256],12597:[[4524],256],12598:[[4525],256],12599:[[4355],256],12600:[[4356],256],12601:[[4357],256],12602:[[4528],256],12603:[[4529],256],12604:[[4530],256],12605:[[4531],256],12606:[[4532],256],12607:[[4533],256],12608:[[4378],256],12609:[[4358],256],12610:[[4359],256],12611:[[4360],256],12612:[[4385],256],12613:[[4361],256],12614:[[4362],256],12615:[[4363],256],12616:[[4364],256],12617:[[4365],256],12618:[[4366],256],12619:[[4367],256],12620:[[4368],256],12621:[[4369],256],12622:[[4370],256],12623:[[4449],256],12624:[[4450],256],12625:[[4451],256],12626:[[4452],256],12627:[[4453],256],12628:[[4454],256],12629:[[4455],256],12630:[[4456],256],12631:[[4457],256],12632:[[4458],256],12633:[[4459],256],12634:[[4460],256],12635:[[4461],256],12636:[[4462],256],12637:[[4463],256],12638:[[4464],256],12639:[[4465],256],12640:[[4466],256],12641:[[4467],256],12642:[[4468],256],12643:[[4469],256],12644:[[4448],256],12645:[[4372],256],12646:[[4373],256],12647:[[4551],256],12648:[[4552],256],12649:[[4556],256],12650:[[4558],256],12651:[[4563],256],12652:[[4567],256],12653:[[4569],256],12654:[[4380],256],12655:[[4573],256],12656:[[4575],256],12657:[[4381],256],12658:[[4382],256],12659:[[4384],256],12660:[[4386],256],12661:[[4387],256],12662:[[4391],256],12663:[[4393],256],12664:[[4395],256],12665:[[4396],256],12666:[[4397],256],12667:[[4398],256],12668:[[4399],256],12669:[[4402],256],12670:[[4406],256],12671:[[4416],256],12672:[[4423],256],12673:[[4428],256],12674:[[4593],256],12675:[[4594],256],12676:[[4439],256],12677:[[4440],256],12678:[[4441],256],12679:[[4484],256],12680:[[4485],256],12681:[[4488],256],12682:[[4497],256],12683:[[4498],256],12684:[[4500],256],12685:[[4510],256],12686:[[4513],256],12690:[[19968],256],12691:[[20108],256],12692:[[19977],256],12693:[[22235],256],12694:[[19978],256],12695:[[20013],256],12696:[[19979],256],12697:[[30002],256],12698:[[20057],256],12699:[[19993],256],12700:[[19969],256],12701:[[22825],256],12702:[[22320],256],12703:[[20154],256]},
12800:{12800:[[40,4352,41],256],12801:[[40,4354,41],256],12802:[[40,4355,41],256],12803:[[40,4357,41],256],12804:[[40,4358,41],256],12805:[[40,4359,41],256],12806:[[40,4361,41],256],12807:[[40,4363,41],256],12808:[[40,4364,41],256],12809:[[40,4366,41],256],12810:[[40,4367,41],256],12811:[[40,4368,41],256],12812:[[40,4369,41],256],12813:[[40,4370,41],256],12814:[[40,4352,4449,41],256],12815:[[40,4354,4449,41],256],12816:[[40,4355,4449,41],256],12817:[[40,4357,4449,41],256],12818:[[40,4358,4449,41],256],12819:[[40,4359,4449,41],256],12820:[[40,4361,4449,41],256],12821:[[40,4363,4449,41],256],12822:[[40,4364,4449,41],256],12823:[[40,4366,4449,41],256],12824:[[40,4367,4449,41],256],12825:[[40,4368,4449,41],256],12826:[[40,4369,4449,41],256],12827:[[40,4370,4449,41],256],12828:[[40,4364,4462,41],256],12829:[[40,4363,4457,4364,4453,4523,41],256],12830:[[40,4363,4457,4370,4462,41],256],12832:[[40,19968,41],256],12833:[[40,20108,41],256],12834:[[40,19977,41],256],12835:[[40,22235,41],256],12836:[[40,20116,41],256],12837:[[40,20845,41],256],12838:[[40,19971,41],256],12839:[[40,20843,41],256],12840:[[40,20061,41],256],12841:[[40,21313,41],256],12842:[[40,26376,41],256],12843:[[40,28779,41],256],12844:[[40,27700,41],256],12845:[[40,26408,41],256],12846:[[40,37329,41],256],12847:[[40,22303,41],256],12848:[[40,26085,41],256],12849:[[40,26666,41],256],12850:[[40,26377,41],256],12851:[[40,31038,41],256],12852:[[40,21517,41],256],12853:[[40,29305,41],256],12854:[[40,36001,41],256],12855:[[40,31069,41],256],12856:[[40,21172,41],256],12857:[[40,20195,41],256],12858:[[40,21628,41],256],12859:[[40,23398,41],256],12860:[[40,30435,41],256],12861:[[40,20225,41],256],12862:[[40,36039,41],256],12863:[[40,21332,41],256],12864:[[40,31085,41],256],12865:[[40,20241,41],256],12866:[[40,33258,41],256],12867:[[40,33267,41],256],12868:[[21839],256],12869:[[24188],256],12870:[[25991],256],12871:[[31631],256],12880:[[80,84,69],256],12881:[[50,49],256],12882:[[50,50],256],12883:[[50,51],256],12884:[[50,52],256],12885:[[50,53],256],12886:[[50,54],256],12887:[[50,55],256],12888:[[50,56],256],12889:[[50,57],256],12890:[[51,48],256],12891:[[51,49],256],12892:[[51,50],256],12893:[[51,51],256],12894:[[51,52],256],12895:[[51,53],256],12896:[[4352],256],12897:[[4354],256],12898:[[4355],256],12899:[[4357],256],12900:[[4358],256],12901:[[4359],256],12902:[[4361],256],12903:[[4363],256],12904:[[4364],256],12905:[[4366],256],12906:[[4367],256],12907:[[4368],256],12908:[[4369],256],12909:[[4370],256],12910:[[4352,4449],256],12911:[[4354,4449],256],12912:[[4355,4449],256],12913:[[4357,4449],256],12914:[[4358,4449],256],12915:[[4359,4449],256],12916:[[4361,4449],256],12917:[[4363,4449],256],12918:[[4364,4449],256],12919:[[4366,4449],256],12920:[[4367,4449],256],12921:[[4368,4449],256],12922:[[4369,4449],256],12923:[[4370,4449],256],12924:[[4366,4449,4535,4352,4457],256],12925:[[4364,4462,4363,4468],256],12926:[[4363,4462],256],12928:[[19968],256],12929:[[20108],256],12930:[[19977],256],12931:[[22235],256],12932:[[20116],256],12933:[[20845],256],12934:[[19971],256],12935:[[20843],256],12936:[[20061],256],12937:[[21313],256],12938:[[26376],256],12939:[[28779],256],12940:[[27700],256],12941:[[26408],256],12942:[[37329],256],12943:[[22303],256],12944:[[26085],256],12945:[[26666],256],12946:[[26377],256],12947:[[31038],256],12948:[[21517],256],12949:[[29305],256],12950:[[36001],256],12951:[[31069],256],12952:[[21172],256],12953:[[31192],256],12954:[[30007],256],12955:[[22899],256],12956:[[36969],256],12957:[[20778],256],12958:[[21360],256],12959:[[27880],256],12960:[[38917],256],12961:[[20241],256],12962:[[20889],256],12963:[[27491],256],12964:[[19978],256],12965:[[20013],256],12966:[[19979],256],12967:[[24038],256],12968:[[21491],256],12969:[[21307],256],12970:[[23447],256],12971:[[23398],256],12972:[[30435],256],12973:[[20225],256],12974:[[36039],256],12975:[[21332],256],12976:[[22812],256],12977:[[51,54],256],12978:[[51,55],256],12979:[[51,56],256],12980:[[51,57],256],12981:[[52,48],256],12982:[[52,49],256],12983:[[52,50],256],12984:[[52,51],256],12985:[[52,52],256],12986:[[52,53],256],12987:[[52,54],256],12988:[[52,55],256],12989:[[52,56],256],12990:[[52,57],256],12991:[[53,48],256],12992:[[49,26376],256],12993:[[50,26376],256],12994:[[51,26376],256],12995:[[52,26376],256],12996:[[53,26376],256],12997:[[54,26376],256],12998:[[55,26376],256],12999:[[56,26376],256],13000:[[57,26376],256],13001:[[49,48,26376],256],13002:[[49,49,26376],256],13003:[[49,50,26376],256],13004:[[72,103],256],13005:[[101,114,103],256],13006:[[101,86],256],13007:[[76,84,68],256],13008:[[12450],256],13009:[[12452],256],13010:[[12454],256],13011:[[12456],256],13012:[[12458],256],13013:[[12459],256],13014:[[12461],256],13015:[[12463],256],13016:[[12465],256],13017:[[12467],256],13018:[[12469],256],13019:[[12471],256],13020:[[12473],256],13021:[[12475],256],13022:[[12477],256],13023:[[12479],256],13024:[[12481],256],13025:[[12484],256],13026:[[12486],256],13027:[[12488],256],13028:[[12490],256],13029:[[12491],256],13030:[[12492],256],13031:[[12493],256],13032:[[12494],256],13033:[[12495],256],13034:[[12498],256],13035:[[12501],256],13036:[[12504],256],13037:[[12507],256],13038:[[12510],256],13039:[[12511],256],13040:[[12512],256],13041:[[12513],256],13042:[[12514],256],13043:[[12516],256],13044:[[12518],256],13045:[[12520],256],13046:[[12521],256],13047:[[12522],256],13048:[[12523],256],13049:[[12524],256],13050:[[12525],256],13051:[[12527],256],13052:[[12528],256],13053:[[12529],256],13054:[[12530],256]},
13056:{13056:[[12450,12497,12540,12488],256],13057:[[12450,12523,12501,12449],256],13058:[[12450,12531,12506,12450],256],13059:[[12450,12540,12523],256],13060:[[12452,12491,12531,12464],256],13061:[[12452,12531,12481],256],13062:[[12454,12457,12531],256],13063:[[12456,12473,12463,12540,12489],256],13064:[[12456,12540,12459,12540],256],13065:[[12458,12531,12473],256],13066:[[12458,12540,12512],256],13067:[[12459,12452,12522],256],13068:[[12459,12521,12483,12488],256],13069:[[12459,12525,12522,12540],256],13070:[[12460,12525,12531],256],13071:[[12460,12531,12510],256],13072:[[12462,12460],256],13073:[[12462,12491,12540],256],13074:[[12461,12517,12522,12540],256],13075:[[12462,12523,12480,12540],256],13076:[[12461,12525],256],13077:[[12461,12525,12464,12521,12512],256],13078:[[12461,12525,12513,12540,12488,12523],256],13079:[[12461,12525,12527,12483,12488],256],13080:[[12464,12521,12512],256],13081:[[12464,12521,12512,12488,12531],256],13082:[[12463,12523,12476,12452,12525],256],13083:[[12463,12525,12540,12493],256],13084:[[12465,12540,12473],256],13085:[[12467,12523,12490],256],13086:[[12467,12540,12509],256],13087:[[12469,12452,12463,12523],256],13088:[[12469,12531,12481,12540,12512],256],13089:[[12471,12522,12531,12464],256],13090:[[12475,12531,12481],256],13091:[[12475,12531,12488],256],13092:[[12480,12540,12473],256],13093:[[12487,12471],256],13094:[[12489,12523],256],13095:[[12488,12531],256],13096:[[12490,12494],256],13097:[[12494,12483,12488],256],13098:[[12495,12452,12484],256],13099:[[12497,12540,12475,12531,12488],256],13100:[[12497,12540,12484],256],13101:[[12496,12540,12524,12523],256],13102:[[12500,12450,12473,12488,12523],256],13103:[[12500,12463,12523],256],13104:[[12500,12467],256],13105:[[12499,12523],256],13106:[[12501,12449,12521,12483,12489],256],13107:[[12501,12451,12540,12488],256],13108:[[12502,12483,12471,12455,12523],256],13109:[[12501,12521,12531],256],13110:[[12504,12463,12479,12540,12523],256],13111:[[12506,12477],256],13112:[[12506,12491,12498],256],13113:[[12504,12523,12484],256],13114:[[12506,12531,12473],256],13115:[[12506,12540,12472],256],13116:[[12505,12540,12479],256],13117:[[12509,12452,12531,12488],256],13118:[[12508,12523,12488],256],13119:[[12507,12531],256],13120:[[12509,12531,12489],256],13121:[[12507,12540,12523],256],13122:[[12507,12540,12531],256],13123:[[12510,12452,12463,12525],256],13124:[[12510,12452,12523],256],13125:[[12510,12483,12495],256],13126:[[12510,12523,12463],256],13127:[[12510,12531,12471,12519,12531],256],13128:[[12511,12463,12525,12531],256],13129:[[12511,12522],256],13130:[[12511,12522,12496,12540,12523],256],13131:[[12513,12460],256],13132:[[12513,12460,12488,12531],256],13133:[[12513,12540,12488,12523],256],13134:[[12516,12540,12489],256],13135:[[12516,12540,12523],256],13136:[[12518,12450,12531],256],13137:[[12522,12483,12488,12523],256],13138:[[12522,12521],256],13139:[[12523,12500,12540],256],13140:[[12523,12540,12502,12523],256],13141:[[12524,12512],256],13142:[[12524,12531,12488,12466,12531],256],13143:[[12527,12483,12488],256],13144:[[48,28857],256],13145:[[49,28857],256],13146:[[50,28857],256],13147:[[51,28857],256],13148:[[52,28857],256],13149:[[53,28857],256],13150:[[54,28857],256],13151:[[55,28857],256],13152:[[56,28857],256],13153:[[57,28857],256],13154:[[49,48,28857],256],13155:[[49,49,28857],256],13156:[[49,50,28857],256],13157:[[49,51,28857],256],13158:[[49,52,28857],256],13159:[[49,53,28857],256],13160:[[49,54,28857],256],13161:[[49,55,28857],256],13162:[[49,56,28857],256],13163:[[49,57,28857],256],13164:[[50,48,28857],256],13165:[[50,49,28857],256],13166:[[50,50,28857],256],13167:[[50,51,28857],256],13168:[[50,52,28857],256],13169:[[104,80,97],256],13170:[[100,97],256],13171:[[65,85],256],13172:[[98,97,114],256],13173:[[111,86],256],13174:[[112,99],256],13175:[[100,109],256],13176:[[100,109,178],256],13177:[[100,109,179],256],13178:[[73,85],256],13179:[[24179,25104],256],13180:[[26157,21644],256],13181:[[22823,27491],256],13182:[[26126,27835],256],13183:[[26666,24335,20250,31038],256],13184:[[112,65],256],13185:[[110,65],256],13186:[[956,65],256],13187:[[109,65],256],13188:[[107,65],256],13189:[[75,66],256],13190:[[77,66],256],13191:[[71,66],256],13192:[[99,97,108],256],13193:[[107,99,97,108],256],13194:[[112,70],256],13195:[[110,70],256],13196:[[956,70],256],13197:[[956,103],256],13198:[[109,103],256],13199:[[107,103],256],13200:[[72,122],256],13201:[[107,72,122],256],13202:[[77,72,122],256],13203:[[71,72,122],256],13204:[[84,72,122],256],13205:[[956,8467],256],13206:[[109,8467],256],13207:[[100,8467],256],13208:[[107,8467],256],13209:[[102,109],256],13210:[[110,109],256],13211:[[956,109],256],13212:[[109,109],256],13213:[[99,109],256],13214:[[107,109],256],13215:[[109,109,178],256],13216:[[99,109,178],256],13217:[[109,178],256],13218:[[107,109,178],256],13219:[[109,109,179],256],13220:[[99,109,179],256],13221:[[109,179],256],13222:[[107,109,179],256],13223:[[109,8725,115],256],13224:[[109,8725,115,178],256],13225:[[80,97],256],13226:[[107,80,97],256],13227:[[77,80,97],256],13228:[[71,80,97],256],13229:[[114,97,100],256],13230:[[114,97,100,8725,115],256],13231:[[114,97,100,8725,115,178],256],13232:[[112,115],256],13233:[[110,115],256],13234:[[956,115],256],13235:[[109,115],256],13236:[[112,86],256],13237:[[110,86],256],13238:[[956,86],256],13239:[[109,86],256],13240:[[107,86],256],13241:[[77,86],256],13242:[[112,87],256],13243:[[110,87],256],13244:[[956,87],256],13245:[[109,87],256],13246:[[107,87],256],13247:[[77,87],256],13248:[[107,937],256],13249:[[77,937],256],13250:[[97,46,109,46],256],13251:[[66,113],256],13252:[[99,99],256],13253:[[99,100],256],13254:[[67,8725,107,103],256],13255:[[67,111,46],256],13256:[[100,66],256],13257:[[71,121],256],13258:[[104,97],256],13259:[[72,80],256],13260:[[105,110],256],13261:[[75,75],256],13262:[[75,77],256],13263:[[107,116],256],13264:[[108,109],256],13265:[[108,110],256],13266:[[108,111,103],256],13267:[[108,120],256],13268:[[109,98],256],13269:[[109,105,108],256],13270:[[109,111,108],256],13271:[[80,72],256],13272:[[112,46,109,46],256],13273:[[80,80,77],256],13274:[[80,82],256],13275:[[115,114],256],13276:[[83,118],256],13277:[[87,98],256],13278:[[86,8725,109],256],13279:[[65,8725,109],256],13280:[[49,26085],256],13281:[[50,26085],256],13282:[[51,26085],256],13283:[[52,26085],256],13284:[[53,26085],256],13285:[[54,26085],256],13286:[[55,26085],256],13287:[[56,26085],256],13288:[[57,26085],256],13289:[[49,48,26085],256],13290:[[49,49,26085],256],13291:[[49,50,26085],256],13292:[[49,51,26085],256],13293:[[49,52,26085],256],13294:[[49,53,26085],256],13295:[[49,54,26085],256],13296:[[49,55,26085],256],13297:[[49,56,26085],256],13298:[[49,57,26085],256],13299:[[50,48,26085],256],13300:[[50,49,26085],256],13301:[[50,50,26085],256],13302:[[50,51,26085],256],13303:[[50,52,26085],256],13304:[[50,53,26085],256],13305:[[50,54,26085],256],13306:[[50,55,26085],256],13307:[[50,56,26085],256],13308:[[50,57,26085],256],13309:[[51,48,26085],256],13310:[[51,49,26085],256],13311:[[103,97,108],256]},
27136:{92912:[,1],92913:[,1],92914:[,1],92915:[,1],92916:[,1]},
27392:{92976:[,230],92977:[,230],92978:[,230],92979:[,230],92980:[,230],92981:[,230],92982:[,230]},
42496:{42607:[,230],42612:[,230],42613:[,230],42614:[,230],42615:[,230],42616:[,230],42617:[,230],42618:[,230],42619:[,230],42620:[,230],42621:[,230],42652:[[1098],256],42653:[[1100],256],42655:[,230],42736:[,230],42737:[,230]},
42752:{42864:[[42863],256],43000:[[294],256],43001:[[339],256]},
43008:{43014:[,9],43204:[,9],43232:[,230],43233:[,230],43234:[,230],43235:[,230],43236:[,230],43237:[,230],43238:[,230],43239:[,230],43240:[,230],43241:[,230],43242:[,230],43243:[,230],43244:[,230],43245:[,230],43246:[,230],43247:[,230],43248:[,230],43249:[,230]},
43264:{43307:[,220],43308:[,220],43309:[,220],43347:[,9],43443:[,7],43456:[,9]},
43520:{43696:[,230],43698:[,230],43699:[,230],43700:[,220],43703:[,230],43704:[,230],43710:[,230],43711:[,230],43713:[,230],43766:[,9]},
43776:{43868:[[42791],256],43869:[[43831],256],43870:[[619],256],43871:[[43858],256],44013:[,9]},
48128:{113822:[,1]},
53504:{119134:[[119127,119141],512],119135:[[119128,119141],512],119136:[[119135,119150],512],119137:[[119135,119151],512],119138:[[119135,119152],512],119139:[[119135,119153],512],119140:[[119135,119154],512],119141:[,216],119142:[,216],119143:[,1],119144:[,1],119145:[,1],119149:[,226],119150:[,216],119151:[,216],119152:[,216],119153:[,216],119154:[,216],119163:[,220],119164:[,220],119165:[,220],119166:[,220],119167:[,220],119168:[,220],119169:[,220],119170:[,220],119173:[,230],119174:[,230],119175:[,230],119176:[,230],119177:[,230],119178:[,220],119179:[,220],119210:[,230],119211:[,230],119212:[,230],119213:[,230],119227:[[119225,119141],512],119228:[[119226,119141],512],119229:[[119227,119150],512],119230:[[119228,119150],512],119231:[[119227,119151],512],119232:[[119228,119151],512]},
53760:{119362:[,230],119363:[,230],119364:[,230]},
54272:{119808:[[65],256],119809:[[66],256],119810:[[67],256],119811:[[68],256],119812:[[69],256],119813:[[70],256],119814:[[71],256],119815:[[72],256],119816:[[73],256],119817:[[74],256],119818:[[75],256],119819:[[76],256],119820:[[77],256],119821:[[78],256],119822:[[79],256],119823:[[80],256],119824:[[81],256],119825:[[82],256],119826:[[83],256],119827:[[84],256],119828:[[85],256],119829:[[86],256],119830:[[87],256],119831:[[88],256],119832:[[89],256],119833:[[90],256],119834:[[97],256],119835:[[98],256],119836:[[99],256],119837:[[100],256],119838:[[101],256],119839:[[102],256],119840:[[103],256],119841:[[104],256],119842:[[105],256],119843:[[106],256],119844:[[107],256],119845:[[108],256],119846:[[109],256],119847:[[110],256],119848:[[111],256],119849:[[112],256],119850:[[113],256],119851:[[114],256],119852:[[115],256],119853:[[116],256],119854:[[117],256],119855:[[118],256],119856:[[119],256],119857:[[120],256],119858:[[121],256],119859:[[122],256],119860:[[65],256],119861:[[66],256],119862:[[67],256],119863:[[68],256],119864:[[69],256],119865:[[70],256],119866:[[71],256],119867:[[72],256],119868:[[73],256],119869:[[74],256],119870:[[75],256],119871:[[76],256],119872:[[77],256],119873:[[78],256],119874:[[79],256],119875:[[80],256],119876:[[81],256],119877:[[82],256],119878:[[83],256],119879:[[84],256],119880:[[85],256],119881:[[86],256],119882:[[87],256],119883:[[88],256],119884:[[89],256],119885:[[90],256],119886:[[97],256],119887:[[98],256],119888:[[99],256],119889:[[100],256],119890:[[101],256],119891:[[102],256],119892:[[103],256],119894:[[105],256],119895:[[106],256],119896:[[107],256],119897:[[108],256],119898:[[109],256],119899:[[110],256],119900:[[111],256],119901:[[112],256],119902:[[113],256],119903:[[114],256],119904:[[115],256],119905:[[116],256],119906:[[117],256],119907:[[118],256],119908:[[119],256],119909:[[120],256],119910:[[121],256],119911:[[122],256],119912:[[65],256],119913:[[66],256],119914:[[67],256],119915:[[68],256],119916:[[69],256],119917:[[70],256],119918:[[71],256],119919:[[72],256],119920:[[73],256],119921:[[74],256],119922:[[75],256],119923:[[76],256],119924:[[77],256],119925:[[78],256],119926:[[79],256],119927:[[80],256],119928:[[81],256],119929:[[82],256],119930:[[83],256],119931:[[84],256],119932:[[85],256],119933:[[86],256],119934:[[87],256],119935:[[88],256],119936:[[89],256],119937:[[90],256],119938:[[97],256],119939:[[98],256],119940:[[99],256],119941:[[100],256],119942:[[101],256],119943:[[102],256],119944:[[103],256],119945:[[104],256],119946:[[105],256],119947:[[106],256],119948:[[107],256],119949:[[108],256],119950:[[109],256],119951:[[110],256],119952:[[111],256],119953:[[112],256],119954:[[113],256],119955:[[114],256],119956:[[115],256],119957:[[116],256],119958:[[117],256],119959:[[118],256],119960:[[119],256],119961:[[120],256],119962:[[121],256],119963:[[122],256],119964:[[65],256],119966:[[67],256],119967:[[68],256],119970:[[71],256],119973:[[74],256],119974:[[75],256],119977:[[78],256],119978:[[79],256],119979:[[80],256],119980:[[81],256],119982:[[83],256],119983:[[84],256],119984:[[85],256],119985:[[86],256],119986:[[87],256],119987:[[88],256],119988:[[89],256],119989:[[90],256],119990:[[97],256],119991:[[98],256],119992:[[99],256],119993:[[100],256],119995:[[102],256],119997:[[104],256],119998:[[105],256],119999:[[106],256],120000:[[107],256],120001:[[108],256],120002:[[109],256],120003:[[110],256],120005:[[112],256],120006:[[113],256],120007:[[114],256],120008:[[115],256],120009:[[116],256],120010:[[117],256],120011:[[118],256],120012:[[119],256],120013:[[120],256],120014:[[121],256],120015:[[122],256],120016:[[65],256],120017:[[66],256],120018:[[67],256],120019:[[68],256],120020:[[69],256],120021:[[70],256],120022:[[71],256],120023:[[72],256],120024:[[73],256],120025:[[74],256],120026:[[75],256],120027:[[76],256],120028:[[77],256],120029:[[78],256],120030:[[79],256],120031:[[80],256],120032:[[81],256],120033:[[82],256],120034:[[83],256],120035:[[84],256],120036:[[85],256],120037:[[86],256],120038:[[87],256],120039:[[88],256],120040:[[89],256],120041:[[90],256],120042:[[97],256],120043:[[98],256],120044:[[99],256],120045:[[100],256],120046:[[101],256],120047:[[102],256],120048:[[103],256],120049:[[104],256],120050:[[105],256],120051:[[106],256],120052:[[107],256],120053:[[108],256],120054:[[109],256],120055:[[110],256],120056:[[111],256],120057:[[112],256],120058:[[113],256],120059:[[114],256],120060:[[115],256],120061:[[116],256],120062:[[117],256],120063:[[118],256]},
54528:{120064:[[119],256],120065:[[120],256],120066:[[121],256],120067:[[122],256],120068:[[65],256],120069:[[66],256],120071:[[68],256],120072:[[69],256],120073:[[70],256],120074:[[71],256],120077:[[74],256],120078:[[75],256],120079:[[76],256],120080:[[77],256],120081:[[78],256],120082:[[79],256],120083:[[80],256],120084:[[81],256],120086:[[83],256],120087:[[84],256],120088:[[85],256],120089:[[86],256],120090:[[87],256],120091:[[88],256],120092:[[89],256],120094:[[97],256],120095:[[98],256],120096:[[99],256],120097:[[100],256],120098:[[101],256],120099:[[102],256],120100:[[103],256],120101:[[104],256],120102:[[105],256],120103:[[106],256],120104:[[107],256],120105:[[108],256],120106:[[109],256],120107:[[110],256],120108:[[111],256],120109:[[112],256],120110:[[113],256],120111:[[114],256],120112:[[115],256],120113:[[116],256],120114:[[117],256],120115:[[118],256],120116:[[119],256],120117:[[120],256],120118:[[121],256],120119:[[122],256],120120:[[65],256],120121:[[66],256],120123:[[68],256],120124:[[69],256],120125:[[70],256],120126:[[71],256],120128:[[73],256],120129:[[74],256],120130:[[75],256],120131:[[76],256],120132:[[77],256],120134:[[79],256],120138:[[83],256],120139:[[84],256],120140:[[85],256],120141:[[86],256],120142:[[87],256],120143:[[88],256],120144:[[89],256],120146:[[97],256],120147:[[98],256],120148:[[99],256],120149:[[100],256],120150:[[101],256],120151:[[102],256],120152:[[103],256],120153:[[104],256],120154:[[105],256],120155:[[106],256],120156:[[107],256],120157:[[108],256],120158:[[109],256],120159:[[110],256],120160:[[111],256],120161:[[112],256],120162:[[113],256],120163:[[114],256],120164:[[115],256],120165:[[116],256],120166:[[117],256],120167:[[118],256],120168:[[119],256],120169:[[120],256],120170:[[121],256],120171:[[122],256],120172:[[65],256],120173:[[66],256],120174:[[67],256],120175:[[68],256],120176:[[69],256],120177:[[70],256],120178:[[71],256],120179:[[72],256],120180:[[73],256],120181:[[74],256],120182:[[75],256],120183:[[76],256],120184:[[77],256],120185:[[78],256],120186:[[79],256],120187:[[80],256],120188:[[81],256],120189:[[82],256],120190:[[83],256],120191:[[84],256],120192:[[85],256],120193:[[86],256],120194:[[87],256],120195:[[88],256],120196:[[89],256],120197:[[90],256],120198:[[97],256],120199:[[98],256],120200:[[99],256],120201:[[100],256],120202:[[101],256],120203:[[102],256],120204:[[103],256],120205:[[104],256],120206:[[105],256],120207:[[106],256],120208:[[107],256],120209:[[108],256],120210:[[109],256],120211:[[110],256],120212:[[111],256],120213:[[112],256],120214:[[113],256],120215:[[114],256],120216:[[115],256],120217:[[116],256],120218:[[117],256],120219:[[118],256],120220:[[119],256],120221:[[120],256],120222:[[121],256],120223:[[122],256],120224:[[65],256],120225:[[66],256],120226:[[67],256],120227:[[68],256],120228:[[69],256],120229:[[70],256],120230:[[71],256],120231:[[72],256],120232:[[73],256],120233:[[74],256],120234:[[75],256],120235:[[76],256],120236:[[77],256],120237:[[78],256],120238:[[79],256],120239:[[80],256],120240:[[81],256],120241:[[82],256],120242:[[83],256],120243:[[84],256],120244:[[85],256],120245:[[86],256],120246:[[87],256],120247:[[88],256],120248:[[89],256],120249:[[90],256],120250:[[97],256],120251:[[98],256],120252:[[99],256],120253:[[100],256],120254:[[101],256],120255:[[102],256],120256:[[103],256],120257:[[104],256],120258:[[105],256],120259:[[106],256],120260:[[107],256],120261:[[108],256],120262:[[109],256],120263:[[110],256],120264:[[111],256],120265:[[112],256],120266:[[113],256],120267:[[114],256],120268:[[115],256],120269:[[116],256],120270:[[117],256],120271:[[118],256],120272:[[119],256],120273:[[120],256],120274:[[121],256],120275:[[122],256],120276:[[65],256],120277:[[66],256],120278:[[67],256],120279:[[68],256],120280:[[69],256],120281:[[70],256],120282:[[71],256],120283:[[72],256],120284:[[73],256],120285:[[74],256],120286:[[75],256],120287:[[76],256],120288:[[77],256],120289:[[78],256],120290:[[79],256],120291:[[80],256],120292:[[81],256],120293:[[82],256],120294:[[83],256],120295:[[84],256],120296:[[85],256],120297:[[86],256],120298:[[87],256],120299:[[88],256],120300:[[89],256],120301:[[90],256],120302:[[97],256],120303:[[98],256],120304:[[99],256],120305:[[100],256],120306:[[101],256],120307:[[102],256],120308:[[103],256],120309:[[104],256],120310:[[105],256],120311:[[106],256],120312:[[107],256],120313:[[108],256],120314:[[109],256],120315:[[110],256],120316:[[111],256],120317:[[112],256],120318:[[113],256],120319:[[114],256]},
54784:{120320:[[115],256],120321:[[116],256],120322:[[117],256],120323:[[118],256],120324:[[119],256],120325:[[120],256],120326:[[121],256],120327:[[122],256],120328:[[65],256],120329:[[66],256],120330:[[67],256],120331:[[68],256],120332:[[69],256],120333:[[70],256],120334:[[71],256],120335:[[72],256],120336:[[73],256],120337:[[74],256],120338:[[75],256],120339:[[76],256],120340:[[77],256],120341:[[78],256],120342:[[79],256],120343:[[80],256],120344:[[81],256],120345:[[82],256],120346:[[83],256],120347:[[84],256],120348:[[85],256],120349:[[86],256],120350:[[87],256],120351:[[88],256],120352:[[89],256],120353:[[90],256],120354:[[97],256],120355:[[98],256],120356:[[99],256],120357:[[100],256],120358:[[101],256],120359:[[102],256],120360:[[103],256],120361:[[104],256],120362:[[105],256],120363:[[106],256],120364:[[107],256],120365:[[108],256],120366:[[109],256],120367:[[110],256],120368:[[111],256],120369:[[112],256],120370:[[113],256],120371:[[114],256],120372:[[115],256],120373:[[116],256],120374:[[117],256],120375:[[118],256],120376:[[119],256],120377:[[120],256],120378:[[121],256],120379:[[122],256],120380:[[65],256],120381:[[66],256],120382:[[67],256],120383:[[68],256],120384:[[69],256],120385:[[70],256],120386:[[71],256],120387:[[72],256],120388:[[73],256],120389:[[74],256],120390:[[75],256],120391:[[76],256],120392:[[77],256],120393:[[78],256],120394:[[79],256],120395:[[80],256],120396:[[81],256],120397:[[82],256],120398:[[83],256],120399:[[84],256],120400:[[85],256],120401:[[86],256],120402:[[87],256],120403:[[88],256],120404:[[89],256],120405:[[90],256],120406:[[97],256],120407:[[98],256],120408:[[99],256],120409:[[100],256],120410:[[101],256],120411:[[102],256],120412:[[103],256],120413:[[104],256],120414:[[105],256],120415:[[106],256],120416:[[107],256],120417:[[108],256],120418:[[109],256],120419:[[110],256],120420:[[111],256],120421:[[112],256],120422:[[113],256],120423:[[114],256],120424:[[115],256],120425:[[116],256],120426:[[117],256],120427:[[118],256],120428:[[119],256],120429:[[120],256],120430:[[121],256],120431:[[122],256],120432:[[65],256],120433:[[66],256],120434:[[67],256],120435:[[68],256],120436:[[69],256],120437:[[70],256],120438:[[71],256],120439:[[72],256],120440:[[73],256],120441:[[74],256],120442:[[75],256],120443:[[76],256],120444:[[77],256],120445:[[78],256],120446:[[79],256],120447:[[80],256],120448:[[81],256],120449:[[82],256],120450:[[83],256],120451:[[84],256],120452:[[85],256],120453:[[86],256],120454:[[87],256],120455:[[88],256],120456:[[89],256],120457:[[90],256],120458:[[97],256],120459:[[98],256],120460:[[99],256],120461:[[100],256],120462:[[101],256],120463:[[102],256],120464:[[103],256],120465:[[104],256],120466:[[105],256],120467:[[106],256],120468:[[107],256],120469:[[108],256],120470:[[109],256],120471:[[110],256],120472:[[111],256],120473:[[112],256],120474:[[113],256],120475:[[114],256],120476:[[115],256],120477:[[116],256],120478:[[117],256],120479:[[118],256],120480:[[119],256],120481:[[120],256],120482:[[121],256],120483:[[122],256],120484:[[305],256],120485:[[567],256],120488:[[913],256],120489:[[914],256],120490:[[915],256],120491:[[916],256],120492:[[917],256],120493:[[918],256],120494:[[919],256],120495:[[920],256],120496:[[921],256],120497:[[922],256],120498:[[923],256],120499:[[924],256],120500:[[925],256],120501:[[926],256],120502:[[927],256],120503:[[928],256],120504:[[929],256],120505:[[1012],256],120506:[[931],256],120507:[[932],256],120508:[[933],256],120509:[[934],256],120510:[[935],256],120511:[[936],256],120512:[[937],256],120513:[[8711],256],120514:[[945],256],120515:[[946],256],120516:[[947],256],120517:[[948],256],120518:[[949],256],120519:[[950],256],120520:[[951],256],120521:[[952],256],120522:[[953],256],120523:[[954],256],120524:[[955],256],120525:[[956],256],120526:[[957],256],120527:[[958],256],120528:[[959],256],120529:[[960],256],120530:[[961],256],120531:[[962],256],120532:[[963],256],120533:[[964],256],120534:[[965],256],120535:[[966],256],120536:[[967],256],120537:[[968],256],120538:[[969],256],120539:[[8706],256],120540:[[1013],256],120541:[[977],256],120542:[[1008],256],120543:[[981],256],120544:[[1009],256],120545:[[982],256],120546:[[913],256],120547:[[914],256],120548:[[915],256],120549:[[916],256],120550:[[917],256],120551:[[918],256],120552:[[919],256],120553:[[920],256],120554:[[921],256],120555:[[922],256],120556:[[923],256],120557:[[924],256],120558:[[925],256],120559:[[926],256],120560:[[927],256],120561:[[928],256],120562:[[929],256],120563:[[1012],256],120564:[[931],256],120565:[[932],256],120566:[[933],256],120567:[[934],256],120568:[[935],256],120569:[[936],256],120570:[[937],256],120571:[[8711],256],120572:[[945],256],120573:[[946],256],120574:[[947],256],120575:[[948],256]},
55040:{120576:[[949],256],120577:[[950],256],120578:[[951],256],120579:[[952],256],120580:[[953],256],120581:[[954],256],120582:[[955],256],120583:[[956],256],120584:[[957],256],120585:[[958],256],120586:[[959],256],120587:[[960],256],120588:[[961],256],120589:[[962],256],120590:[[963],256],120591:[[964],256],120592:[[965],256],120593:[[966],256],120594:[[967],256],120595:[[968],256],120596:[[969],256],120597:[[8706],256],120598:[[1013],256],120599:[[977],256],120600:[[1008],256],120601:[[981],256],120602:[[1009],256],120603:[[982],256],120604:[[913],256],120605:[[914],256],120606:[[915],256],120607:[[916],256],120608:[[917],256],120609:[[918],256],120610:[[919],256],120611:[[920],256],120612:[[921],256],120613:[[922],256],120614:[[923],256],120615:[[924],256],120616:[[925],256],120617:[[926],256],120618:[[927],256],120619:[[928],256],120620:[[929],256],120621:[[1012],256],120622:[[931],256],120623:[[932],256],120624:[[933],256],120625:[[934],256],120626:[[935],256],120627:[[936],256],120628:[[937],256],120629:[[8711],256],120630:[[945],256],120631:[[946],256],120632:[[947],256],120633:[[948],256],120634:[[949],256],120635:[[950],256],120636:[[951],256],120637:[[952],256],120638:[[953],256],120639:[[954],256],120640:[[955],256],120641:[[956],256],120642:[[957],256],120643:[[958],256],120644:[[959],256],120645:[[960],256],120646:[[961],256],120647:[[962],256],120648:[[963],256],120649:[[964],256],120650:[[965],256],120651:[[966],256],120652:[[967],256],120653:[[968],256],120654:[[969],256],120655:[[8706],256],120656:[[1013],256],120657:[[977],256],120658:[[1008],256],120659:[[981],256],120660:[[1009],256],120661:[[982],256],120662:[[913],256],120663:[[914],256],120664:[[915],256],120665:[[916],256],120666:[[917],256],120667:[[918],256],120668:[[919],256],120669:[[920],256],120670:[[921],256],120671:[[922],256],120672:[[923],256],120673:[[924],256],120674:[[925],256],120675:[[926],256],120676:[[927],256],120677:[[928],256],120678:[[929],256],120679:[[1012],256],120680:[[931],256],120681:[[932],256],120682:[[933],256],120683:[[934],256],120684:[[935],256],120685:[[936],256],120686:[[937],256],120687:[[8711],256],120688:[[945],256],120689:[[946],256],120690:[[947],256],120691:[[948],256],120692:[[949],256],120693:[[950],256],120694:[[951],256],120695:[[952],256],120696:[[953],256],120697:[[954],256],120698:[[955],256],120699:[[956],256],120700:[[957],256],120701:[[958],256],120702:[[959],256],120703:[[960],256],120704:[[961],256],120705:[[962],256],120706:[[963],256],120707:[[964],256],120708:[[965],256],120709:[[966],256],120710:[[967],256],120711:[[968],256],120712:[[969],256],120713:[[8706],256],120714:[[1013],256],120715:[[977],256],120716:[[1008],256],120717:[[981],256],120718:[[1009],256],120719:[[982],256],120720:[[913],256],120721:[[914],256],120722:[[915],256],120723:[[916],256],120724:[[917],256],120725:[[918],256],120726:[[919],256],120727:[[920],256],120728:[[921],256],120729:[[922],256],120730:[[923],256],120731:[[924],256],120732:[[925],256],120733:[[926],256],120734:[[927],256],120735:[[928],256],120736:[[929],256],120737:[[1012],256],120738:[[931],256],120739:[[932],256],120740:[[933],256],120741:[[934],256],120742:[[935],256],120743:[[936],256],120744:[[937],256],120745:[[8711],256],120746:[[945],256],120747:[[946],256],120748:[[947],256],120749:[[948],256],120750:[[949],256],120751:[[950],256],120752:[[951],256],120753:[[952],256],120754:[[953],256],120755:[[954],256],120756:[[955],256],120757:[[956],256],120758:[[957],256],120759:[[958],256],120760:[[959],256],120761:[[960],256],120762:[[961],256],120763:[[962],256],120764:[[963],256],120765:[[964],256],120766:[[965],256],120767:[[966],256],120768:[[967],256],120769:[[968],256],120770:[[969],256],120771:[[8706],256],120772:[[1013],256],120773:[[977],256],120774:[[1008],256],120775:[[981],256],120776:[[1009],256],120777:[[982],256],120778:[[988],256],120779:[[989],256],120782:[[48],256],120783:[[49],256],120784:[[50],256],120785:[[51],256],120786:[[52],256],120787:[[53],256],120788:[[54],256],120789:[[55],256],120790:[[56],256],120791:[[57],256],120792:[[48],256],120793:[[49],256],120794:[[50],256],120795:[[51],256],120796:[[52],256],120797:[[53],256],120798:[[54],256],120799:[[55],256],120800:[[56],256],120801:[[57],256],120802:[[48],256],120803:[[49],256],120804:[[50],256],120805:[[51],256],120806:[[52],256],120807:[[53],256],120808:[[54],256],120809:[[55],256],120810:[[56],256],120811:[[57],256],120812:[[48],256],120813:[[49],256],120814:[[50],256],120815:[[51],256],120816:[[52],256],120817:[[53],256],120818:[[54],256],120819:[[55],256],120820:[[56],256],120821:[[57],256],120822:[[48],256],120823:[[49],256],120824:[[50],256],120825:[[51],256],120826:[[52],256],120827:[[53],256],120828:[[54],256],120829:[[55],256],120830:[[56],256],120831:[[57],256]},
59392:{125136:[,220],125137:[,220],125138:[,220],125139:[,220],125140:[,220],125141:[,220],125142:[,220]},
60928:{126464:[[1575],256],126465:[[1576],256],126466:[[1580],256],126467:[[1583],256],126469:[[1608],256],126470:[[1586],256],126471:[[1581],256],126472:[[1591],256],126473:[[1610],256],126474:[[1603],256],126475:[[1604],256],126476:[[1605],256],126477:[[1606],256],126478:[[1587],256],126479:[[1593],256],126480:[[1601],256],126481:[[1589],256],126482:[[1602],256],126483:[[1585],256],126484:[[1588],256],126485:[[1578],256],126486:[[1579],256],126487:[[1582],256],126488:[[1584],256],126489:[[1590],256],126490:[[1592],256],126491:[[1594],256],126492:[[1646],256],126493:[[1722],256],126494:[[1697],256],126495:[[1647],256],126497:[[1576],256],126498:[[1580],256],126500:[[1607],256],126503:[[1581],256],126505:[[1610],256],126506:[[1603],256],126507:[[1604],256],126508:[[1605],256],126509:[[1606],256],126510:[[1587],256],126511:[[1593],256],126512:[[1601],256],126513:[[1589],256],126514:[[1602],256],126516:[[1588],256],126517:[[1578],256],126518:[[1579],256],126519:[[1582],256],126521:[[1590],256],126523:[[1594],256],126530:[[1580],256],126535:[[1581],256],126537:[[1610],256],126539:[[1604],256],126541:[[1606],256],126542:[[1587],256],126543:[[1593],256],126545:[[1589],256],126546:[[1602],256],126548:[[1588],256],126551:[[1582],256],126553:[[1590],256],126555:[[1594],256],126557:[[1722],256],126559:[[1647],256],126561:[[1576],256],126562:[[1580],256],126564:[[1607],256],126567:[[1581],256],126568:[[1591],256],126569:[[1610],256],126570:[[1603],256],126572:[[1605],256],126573:[[1606],256],126574:[[1587],256],126575:[[1593],256],126576:[[1601],256],126577:[[1589],256],126578:[[1602],256],126580:[[1588],256],126581:[[1578],256],126582:[[1579],256],126583:[[1582],256],126585:[[1590],256],126586:[[1592],256],126587:[[1594],256],126588:[[1646],256],126590:[[1697],256],126592:[[1575],256],126593:[[1576],256],126594:[[1580],256],126595:[[1583],256],126596:[[1607],256],126597:[[1608],256],126598:[[1586],256],126599:[[1581],256],126600:[[1591],256],126601:[[1610],256],126603:[[1604],256],126604:[[1605],256],126605:[[1606],256],126606:[[1587],256],126607:[[1593],256],126608:[[1601],256],126609:[[1589],256],126610:[[1602],256],126611:[[1585],256],126612:[[1588],256],126613:[[1578],256],126614:[[1579],256],126615:[[1582],256],126616:[[1584],256],126617:[[1590],256],126618:[[1592],256],126619:[[1594],256],126625:[[1576],256],126626:[[1580],256],126627:[[1583],256],126629:[[1608],256],126630:[[1586],256],126631:[[1581],256],126632:[[1591],256],126633:[[1610],256],126635:[[1604],256],126636:[[1605],256],126637:[[1606],256],126638:[[1587],256],126639:[[1593],256],126640:[[1601],256],126641:[[1589],256],126642:[[1602],256],126643:[[1585],256],126644:[[1588],256],126645:[[1578],256],126646:[[1579],256],126647:[[1582],256],126648:[[1584],256],126649:[[1590],256],126650:[[1592],256],126651:[[1594],256]},
61696:{127232:[[48,46],256],127233:[[48,44],256],127234:[[49,44],256],127235:[[50,44],256],127236:[[51,44],256],127237:[[52,44],256],127238:[[53,44],256],127239:[[54,44],256],127240:[[55,44],256],127241:[[56,44],256],127242:[[57,44],256],127248:[[40,65,41],256],127249:[[40,66,41],256],127250:[[40,67,41],256],127251:[[40,68,41],256],127252:[[40,69,41],256],127253:[[40,70,41],256],127254:[[40,71,41],256],127255:[[40,72,41],256],127256:[[40,73,41],256],127257:[[40,74,41],256],127258:[[40,75,41],256],127259:[[40,76,41],256],127260:[[40,77,41],256],127261:[[40,78,41],256],127262:[[40,79,41],256],127263:[[40,80,41],256],127264:[[40,81,41],256],127265:[[40,82,41],256],127266:[[40,83,41],256],127267:[[40,84,41],256],127268:[[40,85,41],256],127269:[[40,86,41],256],127270:[[40,87,41],256],127271:[[40,88,41],256],127272:[[40,89,41],256],127273:[[40,90,41],256],127274:[[12308,83,12309],256],127275:[[67],256],127276:[[82],256],127277:[[67,68],256],127278:[[87,90],256],127280:[[65],256],127281:[[66],256],127282:[[67],256],127283:[[68],256],127284:[[69],256],127285:[[70],256],127286:[[71],256],127287:[[72],256],127288:[[73],256],127289:[[74],256],127290:[[75],256],127291:[[76],256],127292:[[77],256],127293:[[78],256],127294:[[79],256],127295:[[80],256],127296:[[81],256],127297:[[82],256],127298:[[83],256],127299:[[84],256],127300:[[85],256],127301:[[86],256],127302:[[87],256],127303:[[88],256],127304:[[89],256],127305:[[90],256],127306:[[72,86],256],127307:[[77,86],256],127308:[[83,68],256],127309:[[83,83],256],127310:[[80,80,86],256],127311:[[87,67],256],127338:[[77,67],256],127339:[[77,68],256],127376:[[68,74],256]},
61952:{127488:[[12411,12363],256],127489:[[12467,12467],256],127490:[[12469],256],127504:[[25163],256],127505:[[23383],256],127506:[[21452],256],127507:[[12487],256],127508:[[20108],256],127509:[[22810],256],127510:[[35299],256],127511:[[22825],256],127512:[[20132],256],127513:[[26144],256],127514:[[28961],256],127515:[[26009],256],127516:[[21069],256],127517:[[24460],256],127518:[[20877],256],127519:[[26032],256],127520:[[21021],256],127521:[[32066],256],127522:[[29983],256],127523:[[36009],256],127524:[[22768],256],127525:[[21561],256],127526:[[28436],256],127527:[[25237],256],127528:[[25429],256],127529:[[19968],256],127530:[[19977],256],127531:[[36938],256],127532:[[24038],256],127533:[[20013],256],127534:[[21491],256],127535:[[25351],256],127536:[[36208],256],127537:[[25171],256],127538:[[31105],256],127539:[[31354],256],127540:[[21512],256],127541:[[28288],256],127542:[[26377],256],127543:[[26376],256],127544:[[30003],256],127545:[[21106],256],127546:[[21942],256],127552:[[12308,26412,12309],256],127553:[[12308,19977,12309],256],127554:[[12308,20108,12309],256],127555:[[12308,23433,12309],256],127556:[[12308,28857,12309],256],127557:[[12308,25171,12309],256],127558:[[12308,30423,12309],256],127559:[[12308,21213,12309],256],127560:[[12308,25943,12309],256],127568:[[24471],256],127569:[[21487],256]},
63488:{194560:[[20029]],194561:[[20024]],194562:[[20033]],194563:[[131362]],194564:[[20320]],194565:[[20398]],194566:[[20411]],194567:[[20482]],194568:[[20602]],194569:[[20633]],194570:[[20711]],194571:[[20687]],194572:[[13470]],194573:[[132666]],194574:[[20813]],194575:[[20820]],194576:[[20836]],194577:[[20855]],194578:[[132380]],194579:[[13497]],194580:[[20839]],194581:[[20877]],194582:[[132427]],194583:[[20887]],194584:[[20900]],194585:[[20172]],194586:[[20908]],194587:[[20917]],194588:[[168415]],194589:[[20981]],194590:[[20995]],194591:[[13535]],194592:[[21051]],194593:[[21062]],194594:[[21106]],194595:[[21111]],194596:[[13589]],194597:[[21191]],194598:[[21193]],194599:[[21220]],194600:[[21242]],194601:[[21253]],194602:[[21254]],194603:[[21271]],194604:[[21321]],194605:[[21329]],194606:[[21338]],194607:[[21363]],194608:[[21373]],194609:[[21375]],194610:[[21375]],194611:[[21375]],194612:[[133676]],194613:[[28784]],194614:[[21450]],194615:[[21471]],194616:[[133987]],194617:[[21483]],194618:[[21489]],194619:[[21510]],194620:[[21662]],194621:[[21560]],194622:[[21576]],194623:[[21608]],194624:[[21666]],194625:[[21750]],194626:[[21776]],194627:[[21843]],194628:[[21859]],194629:[[21892]],194630:[[21892]],194631:[[21913]],194632:[[21931]],194633:[[21939]],194634:[[21954]],194635:[[22294]],194636:[[22022]],194637:[[22295]],194638:[[22097]],194639:[[22132]],194640:[[20999]],194641:[[22766]],194642:[[22478]],194643:[[22516]],194644:[[22541]],194645:[[22411]],194646:[[22578]],194647:[[22577]],194648:[[22700]],194649:[[136420]],194650:[[22770]],194651:[[22775]],194652:[[22790]],194653:[[22810]],194654:[[22818]],194655:[[22882]],194656:[[136872]],194657:[[136938]],194658:[[23020]],194659:[[23067]],194660:[[23079]],194661:[[23000]],194662:[[23142]],194663:[[14062]],194664:[[14076]],194665:[[23304]],194666:[[23358]],194667:[[23358]],194668:[[137672]],194669:[[23491]],194670:[[23512]],194671:[[23527]],194672:[[23539]],194673:[[138008]],194674:[[23551]],194675:[[23558]],194676:[[24403]],194677:[[23586]],194678:[[14209]],194679:[[23648]],194680:[[23662]],194681:[[23744]],194682:[[23693]],194683:[[138724]],194684:[[23875]],194685:[[138726]],194686:[[23918]],194687:[[23915]],194688:[[23932]],194689:[[24033]],194690:[[24034]],194691:[[14383]],194692:[[24061]],194693:[[24104]],194694:[[24125]],194695:[[24169]],194696:[[14434]],194697:[[139651]],194698:[[14460]],194699:[[24240]],194700:[[24243]],194701:[[24246]],194702:[[24266]],194703:[[172946]],194704:[[24318]],194705:[[140081]],194706:[[140081]],194707:[[33281]],194708:[[24354]],194709:[[24354]],194710:[[14535]],194711:[[144056]],194712:[[156122]],194713:[[24418]],194714:[[24427]],194715:[[14563]],194716:[[24474]],194717:[[24525]],194718:[[24535]],194719:[[24569]],194720:[[24705]],194721:[[14650]],194722:[[14620]],194723:[[24724]],194724:[[141012]],194725:[[24775]],194726:[[24904]],194727:[[24908]],194728:[[24910]],194729:[[24908]],194730:[[24954]],194731:[[24974]],194732:[[25010]],194733:[[24996]],194734:[[25007]],194735:[[25054]],194736:[[25074]],194737:[[25078]],194738:[[25104]],194739:[[25115]],194740:[[25181]],194741:[[25265]],194742:[[25300]],194743:[[25424]],194744:[[142092]],194745:[[25405]],194746:[[25340]],194747:[[25448]],194748:[[25475]],194749:[[25572]],194750:[[142321]],194751:[[25634]],194752:[[25541]],194753:[[25513]],194754:[[14894]],194755:[[25705]],194756:[[25726]],194757:[[25757]],194758:[[25719]],194759:[[14956]],194760:[[25935]],194761:[[25964]],194762:[[143370]],194763:[[26083]],194764:[[26360]],194765:[[26185]],194766:[[15129]],194767:[[26257]],194768:[[15112]],194769:[[15076]],194770:[[20882]],194771:[[20885]],194772:[[26368]],194773:[[26268]],194774:[[32941]],194775:[[17369]],194776:[[26391]],194777:[[26395]],194778:[[26401]],194779:[[26462]],194780:[[26451]],194781:[[144323]],194782:[[15177]],194783:[[26618]],194784:[[26501]],194785:[[26706]],194786:[[26757]],194787:[[144493]],194788:[[26766]],194789:[[26655]],194790:[[26900]],194791:[[15261]],194792:[[26946]],194793:[[27043]],194794:[[27114]],194795:[[27304]],194796:[[145059]],194797:[[27355]],194798:[[15384]],194799:[[27425]],194800:[[145575]],194801:[[27476]],194802:[[15438]],194803:[[27506]],194804:[[27551]],194805:[[27578]],194806:[[27579]],194807:[[146061]],194808:[[138507]],194809:[[146170]],194810:[[27726]],194811:[[146620]],194812:[[27839]],194813:[[27853]],194814:[[27751]],194815:[[27926]]},
63744:{63744:[[35912]],63745:[[26356]],63746:[[36554]],63747:[[36040]],63748:[[28369]],63749:[[20018]],63750:[[21477]],63751:[[40860]],63752:[[40860]],63753:[[22865]],63754:[[37329]],63755:[[21895]],63756:[[22856]],63757:[[25078]],63758:[[30313]],63759:[[32645]],63760:[[34367]],63761:[[34746]],63762:[[35064]],63763:[[37007]],63764:[[27138]],63765:[[27931]],63766:[[28889]],63767:[[29662]],63768:[[33853]],63769:[[37226]],63770:[[39409]],63771:[[20098]],63772:[[21365]],63773:[[27396]],63774:[[29211]],63775:[[34349]],63776:[[40478]],63777:[[23888]],63778:[[28651]],63779:[[34253]],63780:[[35172]],63781:[[25289]],63782:[[33240]],63783:[[34847]],63784:[[24266]],63785:[[26391]],63786:[[28010]],63787:[[29436]],63788:[[37070]],63789:[[20358]],63790:[[20919]],63791:[[21214]],63792:[[25796]],63793:[[27347]],63794:[[29200]],63795:[[30439]],63796:[[32769]],63797:[[34310]],63798:[[34396]],63799:[[36335]],63800:[[38706]],63801:[[39791]],63802:[[40442]],63803:[[30860]],63804:[[31103]],63805:[[32160]],63806:[[33737]],63807:[[37636]],63808:[[40575]],63809:[[35542]],63810:[[22751]],63811:[[24324]],63812:[[31840]],63813:[[32894]],63814:[[29282]],63815:[[30922]],63816:[[36034]],63817:[[38647]],63818:[[22744]],63819:[[23650]],63820:[[27155]],63821:[[28122]],63822:[[28431]],63823:[[32047]],63824:[[32311]],63825:[[38475]],63826:[[21202]],63827:[[32907]],63828:[[20956]],63829:[[20940]],63830:[[31260]],63831:[[32190]],63832:[[33777]],63833:[[38517]],63834:[[35712]],63835:[[25295]],63836:[[27138]],63837:[[35582]],63838:[[20025]],63839:[[23527]],63840:[[24594]],63841:[[29575]],63842:[[30064]],63843:[[21271]],63844:[[30971]],63845:[[20415]],63846:[[24489]],63847:[[19981]],63848:[[27852]],63849:[[25976]],63850:[[32034]],63851:[[21443]],63852:[[22622]],63853:[[30465]],63854:[[33865]],63855:[[35498]],63856:[[27578]],63857:[[36784]],63858:[[27784]],63859:[[25342]],63860:[[33509]],63861:[[25504]],63862:[[30053]],63863:[[20142]],63864:[[20841]],63865:[[20937]],63866:[[26753]],63867:[[31975]],63868:[[33391]],63869:[[35538]],63870:[[37327]],63871:[[21237]],63872:[[21570]],63873:[[22899]],63874:[[24300]],63875:[[26053]],63876:[[28670]],63877:[[31018]],63878:[[38317]],63879:[[39530]],63880:[[40599]],63881:[[40654]],63882:[[21147]],63883:[[26310]],63884:[[27511]],63885:[[36706]],63886:[[24180]],63887:[[24976]],63888:[[25088]],63889:[[25754]],63890:[[28451]],63891:[[29001]],63892:[[29833]],63893:[[31178]],63894:[[32244]],63895:[[32879]],63896:[[36646]],63897:[[34030]],63898:[[36899]],63899:[[37706]],63900:[[21015]],63901:[[21155]],63902:[[21693]],63903:[[28872]],63904:[[35010]],63905:[[35498]],63906:[[24265]],63907:[[24565]],63908:[[25467]],63909:[[27566]],63910:[[31806]],63911:[[29557]],63912:[[20196]],63913:[[22265]],63914:[[23527]],63915:[[23994]],63916:[[24604]],63917:[[29618]],63918:[[29801]],63919:[[32666]],63920:[[32838]],63921:[[37428]],63922:[[38646]],63923:[[38728]],63924:[[38936]],63925:[[20363]],63926:[[31150]],63927:[[37300]],63928:[[38584]],63929:[[24801]],63930:[[20102]],63931:[[20698]],63932:[[23534]],63933:[[23615]],63934:[[26009]],63935:[[27138]],63936:[[29134]],63937:[[30274]],63938:[[34044]],63939:[[36988]],63940:[[40845]],63941:[[26248]],63942:[[38446]],63943:[[21129]],63944:[[26491]],63945:[[26611]],63946:[[27969]],63947:[[28316]],63948:[[29705]],63949:[[30041]],63950:[[30827]],63951:[[32016]],63952:[[39006]],63953:[[20845]],63954:[[25134]],63955:[[38520]],63956:[[20523]],63957:[[23833]],63958:[[28138]],63959:[[36650]],63960:[[24459]],63961:[[24900]],63962:[[26647]],63963:[[29575]],63964:[[38534]],63965:[[21033]],63966:[[21519]],63967:[[23653]],63968:[[26131]],63969:[[26446]],63970:[[26792]],63971:[[27877]],63972:[[29702]],63973:[[30178]],63974:[[32633]],63975:[[35023]],63976:[[35041]],63977:[[37324]],63978:[[38626]],63979:[[21311]],63980:[[28346]],63981:[[21533]],63982:[[29136]],63983:[[29848]],63984:[[34298]],63985:[[38563]],63986:[[40023]],63987:[[40607]],63988:[[26519]],63989:[[28107]],63990:[[33256]],63991:[[31435]],63992:[[31520]],63993:[[31890]],63994:[[29376]],63995:[[28825]],63996:[[35672]],63997:[[20160]],63998:[[33590]],63999:[[21050]],194816:[[27966]],194817:[[28023]],194818:[[27969]],194819:[[28009]],194820:[[28024]],194821:[[28037]],194822:[[146718]],194823:[[27956]],194824:[[28207]],194825:[[28270]],194826:[[15667]],194827:[[28363]],194828:[[28359]],194829:[[147153]],194830:[[28153]],194831:[[28526]],194832:[[147294]],194833:[[147342]],194834:[[28614]],194835:[[28729]],194836:[[28702]],194837:[[28699]],194838:[[15766]],194839:[[28746]],194840:[[28797]],194841:[[28791]],194842:[[28845]],194843:[[132389]],194844:[[28997]],194845:[[148067]],194846:[[29084]],194847:[[148395]],194848:[[29224]],194849:[[29237]],194850:[[29264]],194851:[[149000]],194852:[[29312]],194853:[[29333]],194854:[[149301]],194855:[[149524]],194856:[[29562]],194857:[[29579]],194858:[[16044]],194859:[[29605]],194860:[[16056]],194861:[[16056]],194862:[[29767]],194863:[[29788]],194864:[[29809]],194865:[[29829]],194866:[[29898]],194867:[[16155]],194868:[[29988]],194869:[[150582]],194870:[[30014]],194871:[[150674]],194872:[[30064]],194873:[[139679]],194874:[[30224]],194875:[[151457]],194876:[[151480]],194877:[[151620]],194878:[[16380]],194879:[[16392]],194880:[[30452]],194881:[[151795]],194882:[[151794]],194883:[[151833]],194884:[[151859]],194885:[[30494]],194886:[[30495]],194887:[[30495]],194888:[[30538]],194889:[[16441]],194890:[[30603]],194891:[[16454]],194892:[[16534]],194893:[[152605]],194894:[[30798]],194895:[[30860]],194896:[[30924]],194897:[[16611]],194898:[[153126]],194899:[[31062]],194900:[[153242]],194901:[[153285]],194902:[[31119]],194903:[[31211]],194904:[[16687]],194905:[[31296]],194906:[[31306]],194907:[[31311]],194908:[[153980]],194909:[[154279]],194910:[[154279]],194911:[[31470]],194912:[[16898]],194913:[[154539]],194914:[[31686]],194915:[[31689]],194916:[[16935]],194917:[[154752]],194918:[[31954]],194919:[[17056]],194920:[[31976]],194921:[[31971]],194922:[[32000]],194923:[[155526]],194924:[[32099]],194925:[[17153]],194926:[[32199]],194927:[[32258]],194928:[[32325]],194929:[[17204]],194930:[[156200]],194931:[[156231]],194932:[[17241]],194933:[[156377]],194934:[[32634]],194935:[[156478]],194936:[[32661]],194937:[[32762]],194938:[[32773]],194939:[[156890]],194940:[[156963]],194941:[[32864]],194942:[[157096]],194943:[[32880]],194944:[[144223]],194945:[[17365]],194946:[[32946]],194947:[[33027]],194948:[[17419]],194949:[[33086]],194950:[[23221]],194951:[[157607]],194952:[[157621]],194953:[[144275]],194954:[[144284]],194955:[[33281]],194956:[[33284]],194957:[[36766]],194958:[[17515]],194959:[[33425]],194960:[[33419]],194961:[[33437]],194962:[[21171]],194963:[[33457]],194964:[[33459]],194965:[[33469]],194966:[[33510]],194967:[[158524]],194968:[[33509]],194969:[[33565]],194970:[[33635]],194971:[[33709]],194972:[[33571]],194973:[[33725]],194974:[[33767]],194975:[[33879]],194976:[[33619]],194977:[[33738]],194978:[[33740]],194979:[[33756]],194980:[[158774]],194981:[[159083]],194982:[[158933]],194983:[[17707]],194984:[[34033]],194985:[[34035]],194986:[[34070]],194987:[[160714]],194988:[[34148]],194989:[[159532]],194990:[[17757]],194991:[[17761]],194992:[[159665]],194993:[[159954]],194994:[[17771]],194995:[[34384]],194996:[[34396]],194997:[[34407]],194998:[[34409]],194999:[[34473]],195000:[[34440]],195001:[[34574]],195002:[[34530]],195003:[[34681]],195004:[[34600]],195005:[[34667]],195006:[[34694]],195007:[[17879]],195008:[[34785]],195009:[[34817]],195010:[[17913]],195011:[[34912]],195012:[[34915]],195013:[[161383]],195014:[[35031]],195015:[[35038]],195016:[[17973]],195017:[[35066]],195018:[[13499]],195019:[[161966]],195020:[[162150]],195021:[[18110]],195022:[[18119]],195023:[[35488]],195024:[[35565]],195025:[[35722]],195026:[[35925]],195027:[[162984]],195028:[[36011]],195029:[[36033]],195030:[[36123]],195031:[[36215]],195032:[[163631]],195033:[[133124]],195034:[[36299]],195035:[[36284]],195036:[[36336]],195037:[[133342]],195038:[[36564]],195039:[[36664]],195040:[[165330]],195041:[[165357]],195042:[[37012]],195043:[[37105]],195044:[[37137]],195045:[[165678]],195046:[[37147]],195047:[[37432]],195048:[[37591]],195049:[[37592]],195050:[[37500]],195051:[[37881]],195052:[[37909]],195053:[[166906]],195054:[[38283]],195055:[[18837]],195056:[[38327]],195057:[[167287]],195058:[[18918]],195059:[[38595]],195060:[[23986]],195061:[[38691]],195062:[[168261]],195063:[[168474]],195064:[[19054]],195065:[[19062]],195066:[[38880]],195067:[[168970]],195068:[[19122]],195069:[[169110]],195070:[[38923]],195071:[[38923]]},
64000:{64000:[[20999]],64001:[[24230]],64002:[[25299]],64003:[[31958]],64004:[[23429]],64005:[[27934]],64006:[[26292]],64007:[[36667]],64008:[[34892]],64009:[[38477]],64010:[[35211]],64011:[[24275]],64012:[[20800]],64013:[[21952]],64016:[[22618]],64018:[[26228]],64021:[[20958]],64022:[[29482]],64023:[[30410]],64024:[[31036]],64025:[[31070]],64026:[[31077]],64027:[[31119]],64028:[[38742]],64029:[[31934]],64030:[[32701]],64032:[[34322]],64034:[[35576]],64037:[[36920]],64038:[[37117]],64042:[[39151]],64043:[[39164]],64044:[[39208]],64045:[[40372]],64046:[[37086]],64047:[[38583]],64048:[[20398]],64049:[[20711]],64050:[[20813]],64051:[[21193]],64052:[[21220]],64053:[[21329]],64054:[[21917]],64055:[[22022]],64056:[[22120]],64057:[[22592]],64058:[[22696]],64059:[[23652]],64060:[[23662]],64061:[[24724]],64062:[[24936]],64063:[[24974]],64064:[[25074]],64065:[[25935]],64066:[[26082]],64067:[[26257]],64068:[[26757]],64069:[[28023]],64070:[[28186]],64071:[[28450]],64072:[[29038]],64073:[[29227]],64074:[[29730]],64075:[[30865]],64076:[[31038]],64077:[[31049]],64078:[[31048]],64079:[[31056]],64080:[[31062]],64081:[[31069]],64082:[[31117]],64083:[[31118]],64084:[[31296]],64085:[[31361]],64086:[[31680]],64087:[[32244]],64088:[[32265]],64089:[[32321]],64090:[[32626]],64091:[[32773]],64092:[[33261]],64093:[[33401]],64094:[[33401]],64095:[[33879]],64096:[[35088]],64097:[[35222]],64098:[[35585]],64099:[[35641]],64100:[[36051]],64101:[[36104]],64102:[[36790]],64103:[[36920]],64104:[[38627]],64105:[[38911]],64106:[[38971]],64107:[[24693]],64108:[[148206]],64109:[[33304]],64112:[[20006]],64113:[[20917]],64114:[[20840]],64115:[[20352]],64116:[[20805]],64117:[[20864]],64118:[[21191]],64119:[[21242]],64120:[[21917]],64121:[[21845]],64122:[[21913]],64123:[[21986]],64124:[[22618]],64125:[[22707]],64126:[[22852]],64127:[[22868]],64128:[[23138]],64129:[[23336]],64130:[[24274]],64131:[[24281]],64132:[[24425]],64133:[[24493]],64134:[[24792]],64135:[[24910]],64136:[[24840]],64137:[[24974]],64138:[[24928]],64139:[[25074]],64140:[[25140]],64141:[[25540]],64142:[[25628]],64143:[[25682]],64144:[[25942]],64145:[[26228]],64146:[[26391]],64147:[[26395]],64148:[[26454]],64149:[[27513]],64150:[[27578]],64151:[[27969]],64152:[[28379]],64153:[[28363]],64154:[[28450]],64155:[[28702]],64156:[[29038]],64157:[[30631]],64158:[[29237]],64159:[[29359]],64160:[[29482]],64161:[[29809]],64162:[[29958]],64163:[[30011]],64164:[[30237]],64165:[[30239]],64166:[[30410]],64167:[[30427]],64168:[[30452]],64169:[[30538]],64170:[[30528]],64171:[[30924]],64172:[[31409]],64173:[[31680]],64174:[[31867]],64175:[[32091]],64176:[[32244]],64177:[[32574]],64178:[[32773]],64179:[[33618]],64180:[[33775]],64181:[[34681]],64182:[[35137]],64183:[[35206]],64184:[[35222]],64185:[[35519]],64186:[[35576]],64187:[[35531]],64188:[[35585]],64189:[[35582]],64190:[[35565]],64191:[[35641]],64192:[[35722]],64193:[[36104]],64194:[[36664]],64195:[[36978]],64196:[[37273]],64197:[[37494]],64198:[[38524]],64199:[[38627]],64200:[[38742]],64201:[[38875]],64202:[[38911]],64203:[[38923]],64204:[[38971]],64205:[[39698]],64206:[[40860]],64207:[[141386]],64208:[[141380]],64209:[[144341]],64210:[[15261]],64211:[[16408]],64212:[[16441]],64213:[[152137]],64214:[[154832]],64215:[[163539]],64216:[[40771]],64217:[[40846]],195072:[[38953]],195073:[[169398]],195074:[[39138]],195075:[[19251]],195076:[[39209]],195077:[[39335]],195078:[[39362]],195079:[[39422]],195080:[[19406]],195081:[[170800]],195082:[[39698]],195083:[[40000]],195084:[[40189]],195085:[[19662]],195086:[[19693]],195087:[[40295]],195088:[[172238]],195089:[[19704]],195090:[[172293]],195091:[[172558]],195092:[[172689]],195093:[[40635]],195094:[[19798]],195095:[[40697]],195096:[[40702]],195097:[[40709]],195098:[[40719]],195099:[[40726]],195100:[[40763]],195101:[[173568]]},
64256:{64256:[[102,102],256],64257:[[102,105],256],64258:[[102,108],256],64259:[[102,102,105],256],64260:[[102,102,108],256],64261:[[383,116],256],64262:[[115,116],256],64275:[[1396,1398],256],64276:[[1396,1381],256],64277:[[1396,1387],256],64278:[[1406,1398],256],64279:[[1396,1389],256],64285:[[1497,1460],512],64286:[,26],64287:[[1522,1463],512],64288:[[1506],256],64289:[[1488],256],64290:[[1491],256],64291:[[1492],256],64292:[[1499],256],64293:[[1500],256],64294:[[1501],256],64295:[[1512],256],64296:[[1514],256],64297:[[43],256],64298:[[1513,1473],512],64299:[[1513,1474],512],64300:[[64329,1473],512],64301:[[64329,1474],512],64302:[[1488,1463],512],64303:[[1488,1464],512],64304:[[1488,1468],512],64305:[[1489,1468],512],64306:[[1490,1468],512],64307:[[1491,1468],512],64308:[[1492,1468],512],64309:[[1493,1468],512],64310:[[1494,1468],512],64312:[[1496,1468],512],64313:[[1497,1468],512],64314:[[1498,1468],512],64315:[[1499,1468],512],64316:[[1500,1468],512],64318:[[1502,1468],512],64320:[[1504,1468],512],64321:[[1505,1468],512],64323:[[1507,1468],512],64324:[[1508,1468],512],64326:[[1510,1468],512],64327:[[1511,1468],512],64328:[[1512,1468],512],64329:[[1513,1468],512],64330:[[1514,1468],512],64331:[[1493,1465],512],64332:[[1489,1471],512],64333:[[1499,1471],512],64334:[[1508,1471],512],64335:[[1488,1500],256],64336:[[1649],256],64337:[[1649],256],64338:[[1659],256],64339:[[1659],256],64340:[[1659],256],64341:[[1659],256],64342:[[1662],256],64343:[[1662],256],64344:[[1662],256],64345:[[1662],256],64346:[[1664],256],64347:[[1664],256],64348:[[1664],256],64349:[[1664],256],64350:[[1658],256],64351:[[1658],256],64352:[[1658],256],64353:[[1658],256],64354:[[1663],256],64355:[[1663],256],64356:[[1663],256],64357:[[1663],256],64358:[[1657],256],64359:[[1657],256],64360:[[1657],256],64361:[[1657],256],64362:[[1700],256],64363:[[1700],256],64364:[[1700],256],64365:[[1700],256],64366:[[1702],256],64367:[[1702],256],64368:[[1702],256],64369:[[1702],256],64370:[[1668],256],64371:[[1668],256],64372:[[1668],256],64373:[[1668],256],64374:[[1667],256],64375:[[1667],256],64376:[[1667],256],64377:[[1667],256],64378:[[1670],256],64379:[[1670],256],64380:[[1670],256],64381:[[1670],256],64382:[[1671],256],64383:[[1671],256],64384:[[1671],256],64385:[[1671],256],64386:[[1677],256],64387:[[1677],256],64388:[[1676],256],64389:[[1676],256],64390:[[1678],256],64391:[[1678],256],64392:[[1672],256],64393:[[1672],256],64394:[[1688],256],64395:[[1688],256],64396:[[1681],256],64397:[[1681],256],64398:[[1705],256],64399:[[1705],256],64400:[[1705],256],64401:[[1705],256],64402:[[1711],256],64403:[[1711],256],64404:[[1711],256],64405:[[1711],256],64406:[[1715],256],64407:[[1715],256],64408:[[1715],256],64409:[[1715],256],64410:[[1713],256],64411:[[1713],256],64412:[[1713],256],64413:[[1713],256],64414:[[1722],256],64415:[[1722],256],64416:[[1723],256],64417:[[1723],256],64418:[[1723],256],64419:[[1723],256],64420:[[1728],256],64421:[[1728],256],64422:[[1729],256],64423:[[1729],256],64424:[[1729],256],64425:[[1729],256],64426:[[1726],256],64427:[[1726],256],64428:[[1726],256],64429:[[1726],256],64430:[[1746],256],64431:[[1746],256],64432:[[1747],256],64433:[[1747],256],64467:[[1709],256],64468:[[1709],256],64469:[[1709],256],64470:[[1709],256],64471:[[1735],256],64472:[[1735],256],64473:[[1734],256],64474:[[1734],256],64475:[[1736],256],64476:[[1736],256],64477:[[1655],256],64478:[[1739],256],64479:[[1739],256],64480:[[1733],256],64481:[[1733],256],64482:[[1737],256],64483:[[1737],256],64484:[[1744],256],64485:[[1744],256],64486:[[1744],256],64487:[[1744],256],64488:[[1609],256],64489:[[1609],256],64490:[[1574,1575],256],64491:[[1574,1575],256],64492:[[1574,1749],256],64493:[[1574,1749],256],64494:[[1574,1608],256],64495:[[1574,1608],256],64496:[[1574,1735],256],64497:[[1574,1735],256],64498:[[1574,1734],256],64499:[[1574,1734],256],64500:[[1574,1736],256],64501:[[1574,1736],256],64502:[[1574,1744],256],64503:[[1574,1744],256],64504:[[1574,1744],256],64505:[[1574,1609],256],64506:[[1574,1609],256],64507:[[1574,1609],256],64508:[[1740],256],64509:[[1740],256],64510:[[1740],256],64511:[[1740],256]},
64512:{64512:[[1574,1580],256],64513:[[1574,1581],256],64514:[[1574,1605],256],64515:[[1574,1609],256],64516:[[1574,1610],256],64517:[[1576,1580],256],64518:[[1576,1581],256],64519:[[1576,1582],256],64520:[[1576,1605],256],64521:[[1576,1609],256],64522:[[1576,1610],256],64523:[[1578,1580],256],64524:[[1578,1581],256],64525:[[1578,1582],256],64526:[[1578,1605],256],64527:[[1578,1609],256],64528:[[1578,1610],256],64529:[[1579,1580],256],64530:[[1579,1605],256],64531:[[1579,1609],256],64532:[[1579,1610],256],64533:[[1580,1581],256],64534:[[1580,1605],256],64535:[[1581,1580],256],64536:[[1581,1605],256],64537:[[1582,1580],256],64538:[[1582,1581],256],64539:[[1582,1605],256],64540:[[1587,1580],256],64541:[[1587,1581],256],64542:[[1587,1582],256],64543:[[1587,1605],256],64544:[[1589,1581],256],64545:[[1589,1605],256],64546:[[1590,1580],256],64547:[[1590,1581],256],64548:[[1590,1582],256],64549:[[1590,1605],256],64550:[[1591,1581],256],64551:[[1591,1605],256],64552:[[1592,1605],256],64553:[[1593,1580],256],64554:[[1593,1605],256],64555:[[1594,1580],256],64556:[[1594,1605],256],64557:[[1601,1580],256],64558:[[1601,1581],256],64559:[[1601,1582],256],64560:[[1601,1605],256],64561:[[1601,1609],256],64562:[[1601,1610],256],64563:[[1602,1581],256],64564:[[1602,1605],256],64565:[[1602,1609],256],64566:[[1602,1610],256],64567:[[1603,1575],256],64568:[[1603,1580],256],64569:[[1603,1581],256],64570:[[1603,1582],256],64571:[[1603,1604],256],64572:[[1603,1605],256],64573:[[1603,1609],256],64574:[[1603,1610],256],64575:[[1604,1580],256],64576:[[1604,1581],256],64577:[[1604,1582],256],64578:[[1604,1605],256],64579:[[1604,1609],256],64580:[[1604,1610],256],64581:[[1605,1580],256],64582:[[1605,1581],256],64583:[[1605,1582],256],64584:[[1605,1605],256],64585:[[1605,1609],256],64586:[[1605,1610],256],64587:[[1606,1580],256],64588:[[1606,1581],256],64589:[[1606,1582],256],64590:[[1606,1605],256],64591:[[1606,1609],256],64592:[[1606,1610],256],64593:[[1607,1580],256],64594:[[1607,1605],256],64595:[[1607,1609],256],64596:[[1607,1610],256],64597:[[1610,1580],256],64598:[[1610,1581],256],64599:[[1610,1582],256],64600:[[1610,1605],256],64601:[[1610,1609],256],64602:[[1610,1610],256],64603:[[1584,1648],256],64604:[[1585,1648],256],64605:[[1609,1648],256],64606:[[32,1612,1617],256],64607:[[32,1613,1617],256],64608:[[32,1614,1617],256],64609:[[32,1615,1617],256],64610:[[32,1616,1617],256],64611:[[32,1617,1648],256],64612:[[1574,1585],256],64613:[[1574,1586],256],64614:[[1574,1605],256],64615:[[1574,1606],256],64616:[[1574,1609],256],64617:[[1574,1610],256],64618:[[1576,1585],256],64619:[[1576,1586],256],64620:[[1576,1605],256],64621:[[1576,1606],256],64622:[[1576,1609],256],64623:[[1576,1610],256],64624:[[1578,1585],256],64625:[[1578,1586],256],64626:[[1578,1605],256],64627:[[1578,1606],256],64628:[[1578,1609],256],64629:[[1578,1610],256],64630:[[1579,1585],256],64631:[[1579,1586],256],64632:[[1579,1605],256],64633:[[1579,1606],256],64634:[[1579,1609],256],64635:[[1579,1610],256],64636:[[1601,1609],256],64637:[[1601,1610],256],64638:[[1602,1609],256],64639:[[1602,1610],256],64640:[[1603,1575],256],64641:[[1603,1604],256],64642:[[1603,1605],256],64643:[[1603,1609],256],64644:[[1603,1610],256],64645:[[1604,1605],256],64646:[[1604,1609],256],64647:[[1604,1610],256],64648:[[1605,1575],256],64649:[[1605,1605],256],64650:[[1606,1585],256],64651:[[1606,1586],256],64652:[[1606,1605],256],64653:[[1606,1606],256],64654:[[1606,1609],256],64655:[[1606,1610],256],64656:[[1609,1648],256],64657:[[1610,1585],256],64658:[[1610,1586],256],64659:[[1610,1605],256],64660:[[1610,1606],256],64661:[[1610,1609],256],64662:[[1610,1610],256],64663:[[1574,1580],256],64664:[[1574,1581],256],64665:[[1574,1582],256],64666:[[1574,1605],256],64667:[[1574,1607],256],64668:[[1576,1580],256],64669:[[1576,1581],256],64670:[[1576,1582],256],64671:[[1576,1605],256],64672:[[1576,1607],256],64673:[[1578,1580],256],64674:[[1578,1581],256],64675:[[1578,1582],256],64676:[[1578,1605],256],64677:[[1578,1607],256],64678:[[1579,1605],256],64679:[[1580,1581],256],64680:[[1580,1605],256],64681:[[1581,1580],256],64682:[[1581,1605],256],64683:[[1582,1580],256],64684:[[1582,1605],256],64685:[[1587,1580],256],64686:[[1587,1581],256],64687:[[1587,1582],256],64688:[[1587,1605],256],64689:[[1589,1581],256],64690:[[1589,1582],256],64691:[[1589,1605],256],64692:[[1590,1580],256],64693:[[1590,1581],256],64694:[[1590,1582],256],64695:[[1590,1605],256],64696:[[1591,1581],256],64697:[[1592,1605],256],64698:[[1593,1580],256],64699:[[1593,1605],256],64700:[[1594,1580],256],64701:[[1594,1605],256],64702:[[1601,1580],256],64703:[[1601,1581],256],64704:[[1601,1582],256],64705:[[1601,1605],256],64706:[[1602,1581],256],64707:[[1602,1605],256],64708:[[1603,1580],256],64709:[[1603,1581],256],64710:[[1603,1582],256],64711:[[1603,1604],256],64712:[[1603,1605],256],64713:[[1604,1580],256],64714:[[1604,1581],256],64715:[[1604,1582],256],64716:[[1604,1605],256],64717:[[1604,1607],256],64718:[[1605,1580],256],64719:[[1605,1581],256],64720:[[1605,1582],256],64721:[[1605,1605],256],64722:[[1606,1580],256],64723:[[1606,1581],256],64724:[[1606,1582],256],64725:[[1606,1605],256],64726:[[1606,1607],256],64727:[[1607,1580],256],64728:[[1607,1605],256],64729:[[1607,1648],256],64730:[[1610,1580],256],64731:[[1610,1581],256],64732:[[1610,1582],256],64733:[[1610,1605],256],64734:[[1610,1607],256],64735:[[1574,1605],256],64736:[[1574,1607],256],64737:[[1576,1605],256],64738:[[1576,1607],256],64739:[[1578,1605],256],64740:[[1578,1607],256],64741:[[1579,1605],256],64742:[[1579,1607],256],64743:[[1587,1605],256],64744:[[1587,1607],256],64745:[[1588,1605],256],64746:[[1588,1607],256],64747:[[1603,1604],256],64748:[[1603,1605],256],64749:[[1604,1605],256],64750:[[1606,1605],256],64751:[[1606,1607],256],64752:[[1610,1605],256],64753:[[1610,1607],256],64754:[[1600,1614,1617],256],64755:[[1600,1615,1617],256],64756:[[1600,1616,1617],256],64757:[[1591,1609],256],64758:[[1591,1610],256],64759:[[1593,1609],256],64760:[[1593,1610],256],64761:[[1594,1609],256],64762:[[1594,1610],256],64763:[[1587,1609],256],64764:[[1587,1610],256],64765:[[1588,1609],256],64766:[[1588,1610],256],64767:[[1581,1609],256]},
64768:{64768:[[1581,1610],256],64769:[[1580,1609],256],64770:[[1580,1610],256],64771:[[1582,1609],256],64772:[[1582,1610],256],64773:[[1589,1609],256],64774:[[1589,1610],256],64775:[[1590,1609],256],64776:[[1590,1610],256],64777:[[1588,1580],256],64778:[[1588,1581],256],64779:[[1588,1582],256],64780:[[1588,1605],256],64781:[[1588,1585],256],64782:[[1587,1585],256],64783:[[1589,1585],256],64784:[[1590,1585],256],64785:[[1591,1609],256],64786:[[1591,1610],256],64787:[[1593,1609],256],64788:[[1593,1610],256],64789:[[1594,1609],256],64790:[[1594,1610],256],64791:[[1587,1609],256],64792:[[1587,1610],256],64793:[[1588,1609],256],64794:[[1588,1610],256],64795:[[1581,1609],256],64796:[[1581,1610],256],64797:[[1580,1609],256],64798:[[1580,1610],256],64799:[[1582,1609],256],64800:[[1582,1610],256],64801:[[1589,1609],256],64802:[[1589,1610],256],64803:[[1590,1609],256],64804:[[1590,1610],256],64805:[[1588,1580],256],64806:[[1588,1581],256],64807:[[1588,1582],256],64808:[[1588,1605],256],64809:[[1588,1585],256],64810:[[1587,1585],256],64811:[[1589,1585],256],64812:[[1590,1585],256],64813:[[1588,1580],256],64814:[[1588,1581],256],64815:[[1588,1582],256],64816:[[1588,1605],256],64817:[[1587,1607],256],64818:[[1588,1607],256],64819:[[1591,1605],256],64820:[[1587,1580],256],64821:[[1587,1581],256],64822:[[1587,1582],256],64823:[[1588,1580],256],64824:[[1588,1581],256],64825:[[1588,1582],256],64826:[[1591,1605],256],64827:[[1592,1605],256],64828:[[1575,1611],256],64829:[[1575,1611],256],64848:[[1578,1580,1605],256],64849:[[1578,1581,1580],256],64850:[[1578,1581,1580],256],64851:[[1578,1581,1605],256],64852:[[1578,1582,1605],256],64853:[[1578,1605,1580],256],64854:[[1578,1605,1581],256],64855:[[1578,1605,1582],256],64856:[[1580,1605,1581],256],64857:[[1580,1605,1581],256],64858:[[1581,1605,1610],256],64859:[[1581,1605,1609],256],64860:[[1587,1581,1580],256],64861:[[1587,1580,1581],256],64862:[[1587,1580,1609],256],64863:[[1587,1605,1581],256],64864:[[1587,1605,1581],256],64865:[[1587,1605,1580],256],64866:[[1587,1605,1605],256],64867:[[1587,1605,1605],256],64868:[[1589,1581,1581],256],64869:[[1589,1581,1581],256],64870:[[1589,1605,1605],256],64871:[[1588,1581,1605],256],64872:[[1588,1581,1605],256],64873:[[1588,1580,1610],256],64874:[[1588,1605,1582],256],64875:[[1588,1605,1582],256],64876:[[1588,1605,1605],256],64877:[[1588,1605,1605],256],64878:[[1590,1581,1609],256],64879:[[1590,1582,1605],256],64880:[[1590,1582,1605],256],64881:[[1591,1605,1581],256],64882:[[1591,1605,1581],256],64883:[[1591,1605,1605],256],64884:[[1591,1605,1610],256],64885:[[1593,1580,1605],256],64886:[[1593,1605,1605],256],64887:[[1593,1605,1605],256],64888:[[1593,1605,1609],256],64889:[[1594,1605,1605],256],64890:[[1594,1605,1610],256],64891:[[1594,1605,1609],256],64892:[[1601,1582,1605],256],64893:[[1601,1582,1605],256],64894:[[1602,1605,1581],256],64895:[[1602,1605,1605],256],64896:[[1604,1581,1605],256],64897:[[1604,1581,1610],256],64898:[[1604,1581,1609],256],64899:[[1604,1580,1580],256],64900:[[1604,1580,1580],256],64901:[[1604,1582,1605],256],64902:[[1604,1582,1605],256],64903:[[1604,1605,1581],256],64904:[[1604,1605,1581],256],64905:[[1605,1581,1580],256],64906:[[1605,1581,1605],256],64907:[[1605,1581,1610],256],64908:[[1605,1580,1581],256],64909:[[1605,1580,1605],256],64910:[[1605,1582,1580],256],64911:[[1605,1582,1605],256],64914:[[1605,1580,1582],256],64915:[[1607,1605,1580],256],64916:[[1607,1605,1605],256],64917:[[1606,1581,1605],256],64918:[[1606,1581,1609],256],64919:[[1606,1580,1605],256],64920:[[1606,1580,1605],256],64921:[[1606,1580,1609],256],64922:[[1606,1605,1610],256],64923:[[1606,1605,1609],256],64924:[[1610,1605,1605],256],64925:[[1610,1605,1605],256],64926:[[1576,1582,1610],256],64927:[[1578,1580,1610],256],64928:[[1578,1580,1609],256],64929:[[1578,1582,1610],256],64930:[[1578,1582,1609],256],64931:[[1578,1605,1610],256],64932:[[1578,1605,1609],256],64933:[[1580,1605,1610],256],64934:[[1580,1581,1609],256],64935:[[1580,1605,1609],256],64936:[[1587,1582,1609],256],64937:[[1589,1581,1610],256],64938:[[1588,1581,1610],256],64939:[[1590,1581,1610],256],64940:[[1604,1580,1610],256],64941:[[1604,1605,1610],256],64942:[[1610,1581,1610],256],64943:[[1610,1580,1610],256],64944:[[1610,1605,1610],256],64945:[[1605,1605,1610],256],64946:[[1602,1605,1610],256],64947:[[1606,1581,1610],256],64948:[[1602,1605,1581],256],64949:[[1604,1581,1605],256],64950:[[1593,1605,1610],256],64951:[[1603,1605,1610],256],64952:[[1606,1580,1581],256],64953:[[1605,1582,1610],256],64954:[[1604,1580,1605],256],64955:[[1603,1605,1605],256],64956:[[1604,1580,1605],256],64957:[[1606,1580,1581],256],64958:[[1580,1581,1610],256],64959:[[1581,1580,1610],256],64960:[[1605,1580,1610],256],64961:[[1601,1605,1610],256],64962:[[1576,1581,1610],256],64963:[[1603,1605,1605],256],64964:[[1593,1580,1605],256],64965:[[1589,1605,1605],256],64966:[[1587,1582,1610],256],64967:[[1606,1580,1610],256],65008:[[1589,1604,1746],256],65009:[[1602,1604,1746],256],65010:[[1575,1604,1604,1607],256],65011:[[1575,1603,1576,1585],256],65012:[[1605,1581,1605,1583],256],65013:[[1589,1604,1593,1605],256],65014:[[1585,1587,1608,1604],256],65015:[[1593,1604,1610,1607],256],65016:[[1608,1587,1604,1605],256],65017:[[1589,1604,1609],256],65018:[[1589,1604,1609,32,1575,1604,1604,1607,32,1593,1604,1610,1607,32,1608,1587,1604,1605],256],65019:[[1580,1604,32,1580,1604,1575,1604,1607],256],65020:[[1585,1740,1575,1604],256]},
65024:{65040:[[44],256],65041:[[12289],256],65042:[[12290],256],65043:[[58],256],65044:[[59],256],65045:[[33],256],65046:[[63],256],65047:[[12310],256],65048:[[12311],256],65049:[[8230],256],65056:[,230],65057:[,230],65058:[,230],65059:[,230],65060:[,230],65061:[,230],65062:[,230],65063:[,220],65064:[,220],65065:[,220],65066:[,220],65067:[,220],65068:[,220],65069:[,220],65072:[[8229],256],65073:[[8212],256],65074:[[8211],256],65075:[[95],256],65076:[[95],256],65077:[[40],256],65078:[[41],256],65079:[[123],256],65080:[[125],256],65081:[[12308],256],65082:[[12309],256],65083:[[12304],256],65084:[[12305],256],65085:[[12298],256],65086:[[12299],256],65087:[[12296],256],65088:[[12297],256],65089:[[12300],256],65090:[[12301],256],65091:[[12302],256],65092:[[12303],256],65095:[[91],256],65096:[[93],256],65097:[[8254],256],65098:[[8254],256],65099:[[8254],256],65100:[[8254],256],65101:[[95],256],65102:[[95],256],65103:[[95],256],65104:[[44],256],65105:[[12289],256],65106:[[46],256],65108:[[59],256],65109:[[58],256],65110:[[63],256],65111:[[33],256],65112:[[8212],256],65113:[[40],256],65114:[[41],256],65115:[[123],256],65116:[[125],256],65117:[[12308],256],65118:[[12309],256],65119:[[35],256],65120:[[38],256],65121:[[42],256],65122:[[43],256],65123:[[45],256],65124:[[60],256],65125:[[62],256],65126:[[61],256],65128:[[92],256],65129:[[36],256],65130:[[37],256],65131:[[64],256],65136:[[32,1611],256],65137:[[1600,1611],256],65138:[[32,1612],256],65140:[[32,1613],256],65142:[[32,1614],256],65143:[[1600,1614],256],65144:[[32,1615],256],65145:[[1600,1615],256],65146:[[32,1616],256],65147:[[1600,1616],256],65148:[[32,1617],256],65149:[[1600,1617],256],65150:[[32,1618],256],65151:[[1600,1618],256],65152:[[1569],256],65153:[[1570],256],65154:[[1570],256],65155:[[1571],256],65156:[[1571],256],65157:[[1572],256],65158:[[1572],256],65159:[[1573],256],65160:[[1573],256],65161:[[1574],256],65162:[[1574],256],65163:[[1574],256],65164:[[1574],256],65165:[[1575],256],65166:[[1575],256],65167:[[1576],256],65168:[[1576],256],65169:[[1576],256],65170:[[1576],256],65171:[[1577],256],65172:[[1577],256],65173:[[1578],256],65174:[[1578],256],65175:[[1578],256],65176:[[1578],256],65177:[[1579],256],65178:[[1579],256],65179:[[1579],256],65180:[[1579],256],65181:[[1580],256],65182:[[1580],256],65183:[[1580],256],65184:[[1580],256],65185:[[1581],256],65186:[[1581],256],65187:[[1581],256],65188:[[1581],256],65189:[[1582],256],65190:[[1582],256],65191:[[1582],256],65192:[[1582],256],65193:[[1583],256],65194:[[1583],256],65195:[[1584],256],65196:[[1584],256],65197:[[1585],256],65198:[[1585],256],65199:[[1586],256],65200:[[1586],256],65201:[[1587],256],65202:[[1587],256],65203:[[1587],256],65204:[[1587],256],65205:[[1588],256],65206:[[1588],256],65207:[[1588],256],65208:[[1588],256],65209:[[1589],256],65210:[[1589],256],65211:[[1589],256],65212:[[1589],256],65213:[[1590],256],65214:[[1590],256],65215:[[1590],256],65216:[[1590],256],65217:[[1591],256],65218:[[1591],256],65219:[[1591],256],65220:[[1591],256],65221:[[1592],256],65222:[[1592],256],65223:[[1592],256],65224:[[1592],256],65225:[[1593],256],65226:[[1593],256],65227:[[1593],256],65228:[[1593],256],65229:[[1594],256],65230:[[1594],256],65231:[[1594],256],65232:[[1594],256],65233:[[1601],256],65234:[[1601],256],65235:[[1601],256],65236:[[1601],256],65237:[[1602],256],65238:[[1602],256],65239:[[1602],256],65240:[[1602],256],65241:[[1603],256],65242:[[1603],256],65243:[[1603],256],65244:[[1603],256],65245:[[1604],256],65246:[[1604],256],65247:[[1604],256],65248:[[1604],256],65249:[[1605],256],65250:[[1605],256],65251:[[1605],256],65252:[[1605],256],65253:[[1606],256],65254:[[1606],256],65255:[[1606],256],65256:[[1606],256],65257:[[1607],256],65258:[[1607],256],65259:[[1607],256],65260:[[1607],256],65261:[[1608],256],65262:[[1608],256],65263:[[1609],256],65264:[[1609],256],65265:[[1610],256],65266:[[1610],256],65267:[[1610],256],65268:[[1610],256],65269:[[1604,1570],256],65270:[[1604,1570],256],65271:[[1604,1571],256],65272:[[1604,1571],256],65273:[[1604,1573],256],65274:[[1604,1573],256],65275:[[1604,1575],256],65276:[[1604,1575],256]},
65280:{65281:[[33],256],65282:[[34],256],65283:[[35],256],65284:[[36],256],65285:[[37],256],65286:[[38],256],65287:[[39],256],65288:[[40],256],65289:[[41],256],65290:[[42],256],65291:[[43],256],65292:[[44],256],65293:[[45],256],65294:[[46],256],65295:[[47],256],65296:[[48],256],65297:[[49],256],65298:[[50],256],65299:[[51],256],65300:[[52],256],65301:[[53],256],65302:[[54],256],65303:[[55],256],65304:[[56],256],65305:[[57],256],65306:[[58],256],65307:[[59],256],65308:[[60],256],65309:[[61],256],65310:[[62],256],65311:[[63],256],65312:[[64],256],65313:[[65],256],65314:[[66],256],65315:[[67],256],65316:[[68],256],65317:[[69],256],65318:[[70],256],65319:[[71],256],65320:[[72],256],65321:[[73],256],65322:[[74],256],65323:[[75],256],65324:[[76],256],65325:[[77],256],65326:[[78],256],65327:[[79],256],65328:[[80],256],65329:[[81],256],65330:[[82],256],65331:[[83],256],65332:[[84],256],65333:[[85],256],65334:[[86],256],65335:[[87],256],65336:[[88],256],65337:[[89],256],65338:[[90],256],65339:[[91],256],65340:[[92],256],65341:[[93],256],65342:[[94],256],65343:[[95],256],65344:[[96],256],65345:[[97],256],65346:[[98],256],65347:[[99],256],65348:[[100],256],65349:[[101],256],65350:[[102],256],65351:[[103],256],65352:[[104],256],65353:[[105],256],65354:[[106],256],65355:[[107],256],65356:[[108],256],65357:[[109],256],65358:[[110],256],65359:[[111],256],65360:[[112],256],65361:[[113],256],65362:[[114],256],65363:[[115],256],65364:[[116],256],65365:[[117],256],65366:[[118],256],65367:[[119],256],65368:[[120],256],65369:[[121],256],65370:[[122],256],65371:[[123],256],65372:[[124],256],65373:[[125],256],65374:[[126],256],65375:[[10629],256],65376:[[10630],256],65377:[[12290],256],65378:[[12300],256],65379:[[12301],256],65380:[[12289],256],65381:[[12539],256],65382:[[12530],256],65383:[[12449],256],65384:[[12451],256],65385:[[12453],256],65386:[[12455],256],65387:[[12457],256],65388:[[12515],256],65389:[[12517],256],65390:[[12519],256],65391:[[12483],256],65392:[[12540],256],65393:[[12450],256],65394:[[12452],256],65395:[[12454],256],65396:[[12456],256],65397:[[12458],256],65398:[[12459],256],65399:[[12461],256],65400:[[12463],256],65401:[[12465],256],65402:[[12467],256],65403:[[12469],256],65404:[[12471],256],65405:[[12473],256],65406:[[12475],256],65407:[[12477],256],65408:[[12479],256],65409:[[12481],256],65410:[[12484],256],65411:[[12486],256],65412:[[12488],256],65413:[[12490],256],65414:[[12491],256],65415:[[12492],256],65416:[[12493],256],65417:[[12494],256],65418:[[12495],256],65419:[[12498],256],65420:[[12501],256],65421:[[12504],256],65422:[[12507],256],65423:[[12510],256],65424:[[12511],256],65425:[[12512],256],65426:[[12513],256],65427:[[12514],256],65428:[[12516],256],65429:[[12518],256],65430:[[12520],256],65431:[[12521],256],65432:[[12522],256],65433:[[12523],256],65434:[[12524],256],65435:[[12525],256],65436:[[12527],256],65437:[[12531],256],65438:[[12441],256],65439:[[12442],256],65440:[[12644],256],65441:[[12593],256],65442:[[12594],256],65443:[[12595],256],65444:[[12596],256],65445:[[12597],256],65446:[[12598],256],65447:[[12599],256],65448:[[12600],256],65449:[[12601],256],65450:[[12602],256],65451:[[12603],256],65452:[[12604],256],65453:[[12605],256],65454:[[12606],256],65455:[[12607],256],65456:[[12608],256],65457:[[12609],256],65458:[[12610],256],65459:[[12611],256],65460:[[12612],256],65461:[[12613],256],65462:[[12614],256],65463:[[12615],256],65464:[[12616],256],65465:[[12617],256],65466:[[12618],256],65467:[[12619],256],65468:[[12620],256],65469:[[12621],256],65470:[[12622],256],65474:[[12623],256],65475:[[12624],256],65476:[[12625],256],65477:[[12626],256],65478:[[12627],256],65479:[[12628],256],65482:[[12629],256],65483:[[12630],256],65484:[[12631],256],65485:[[12632],256],65486:[[12633],256],65487:[[12634],256],65490:[[12635],256],65491:[[12636],256],65492:[[12637],256],65493:[[12638],256],65494:[[12639],256],65495:[[12640],256],65498:[[12641],256],65499:[[12642],256],65500:[[12643],256],65504:[[162],256],65505:[[163],256],65506:[[172],256],65507:[[175],256],65508:[[166],256],65509:[[165],256],65510:[[8361],256],65512:[[9474],256],65513:[[8592],256],65514:[[8593],256],65515:[[8594],256],65516:[[8595],256],65517:[[9632],256],65518:[[9675],256]}

};

   /***** Module to export */
   var unorm = {
      nfc: nfc,
      nfd: nfd,
      nfkc: nfkc,
      nfkd: nfkd
   };

   /*globals module:true,define:true*/

   // CommonJS
   if (typeof module === "object") {
      module.exports = unorm;

   // AMD
   } else if (typeof define === "function" && define.amd) {
      define("unorm", function () {
         return unorm;
      });

   // Global
   } else {
      root.unorm = unorm;
   }

   /***** Export as shim for String::normalize method *****/
   /*
      http://wiki.ecmascript.org/doku.php?id=harmony:specification_drafts#november_8_2013_draft_rev_21

      21.1.3.12 String.prototype.normalize(form="NFC")
      When the normalize method is called with one argument form, the following steps are taken:

      1. Let O be CheckObjectCoercible(this value).
      2. Let S be ToString(O).
      3. ReturnIfAbrupt(S).
      4. If form is not provided or undefined let form be "NFC".
      5. Let f be ToString(form).
      6. ReturnIfAbrupt(f).
      7. If f is not one of "NFC", "NFD", "NFKC", or "NFKD", then throw a RangeError Exception.
      8. Let ns be the String value is the result of normalizing S into the normalization form named by f as specified in Unicode Standard Annex #15, UnicodeNormalizatoin Forms.
      9. Return ns.

      The length property of the normalize method is 0.

      *NOTE* The normalize function is intentionally generic; it does not require that its this value be a String object. Therefore it can be transferred to other kinds of objects for use as a method.
   */
    unorm.shimApplied = false;

   if (!String.prototype.normalize) {
      Object.defineProperty(String.prototype, "normalize", {
         enumerable: false,
         configurable: true,
         writable: true,
         value: function normalize (/*form*/) {
            
            var str = "" + this;
            var form = arguments[0] === undefined ? "NFC" : arguments[0];

            if (this === null || this === undefined) {
               throw new TypeError("Cannot call method on " + Object.prototype.toString.call(this));
            }

            if (form === "NFC") {
               return unorm.nfc(str);
            } else if (form === "NFD") {
               return unorm.nfd(str);
            } else if (form === "NFKC") {
               return unorm.nfkc(str);
            } else if (form === "NFKD") {
               return unorm.nfkd(str);
            } else {
               throw new RangeError("Invalid normalization form: " + form);
            }
         }
      });

      unorm.shimApplied = true;
   }
}(this));
}}["(module unorm/lib/unorm.js)"],
"ep_etherpad-lite/static/js/contentcollector.js": {"(module ep_etherpad-lite/static/js/contentcollector.js)": function (require, exports, module) {'use strict';
/**
 * This code is mostly from the old Etherpad. Please help us to comment this code.
 * This helps other people to understand this code better and helps them to improve it.
 * TL;DR COMMENTS ON THIS FILE ARE HIGHLY APPRECIATED
 */

// THIS FILE IS ALSO AN APPJET MODULE: etherpad.collab.ace.contentcollector
// %APPJET%: import("etherpad.collab.ace.easysync2.Changeset");
// %APPJET%: import("etherpad.admin.plugins");
/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const _MAX_LIST_LEVEL = 16;

const AttributeMap = require('./AttributeMap');
const UNorm = require('unorm');
const Changeset = require('./Changeset');
const hooks = require('./pluginfw/hooks');

const sanitizeUnicode = (s) => UNorm.nfc(s);
const tagName = (n) => n.tagName && n.tagName.toLowerCase();
// supportedElems are Supported natively within Etherpad and don't require a plugin
const supportedElems = new Set([
  'author',
  'b',
  'bold',
  'br',
  'div',
  'font',
  'i',
  'insertorder',
  'italic',
  'li',
  'lmkr',
  'ol',
  'p',
  'pre',
  'strong',
  's',
  'span',
  'u',
  'ul',
]);

const makeContentCollector = (collectStyles, abrowser, apool, className2Author) => {
  const _blockElems = {
    div: 1,
    p: 1,
    pre: 1,
    li: 1,
  };

  hooks.callAll('ccRegisterBlockElements').forEach((element) => {
    _blockElems[element] = 1;
    supportedElems.add(element);
  });

  const isBlockElement = (n) => !!_blockElems[tagName(n) || ''];

  const textify = (str) => sanitizeUnicode(
      str.replace(/(\n | \n)/g, ' ')
          .replace(/[\n\r ]/g, ' ')
          .replace(/\xa0/g, ' ')
          .replace(/\t/g, '        '));

  const getAssoc = (node, name) => node[`_magicdom_${name}`];

  const lines = (() => {
    const textArray = [];
    const attribsArray = [];
    let attribsBuilder = null;
    const op = new Changeset.Op('+');
    const self = {
      length: () => textArray.length,
      atColumnZero: () => textArray[textArray.length - 1] === '',
      startNew: () => {
        textArray.push('');
        self.flush(true);
        attribsBuilder = Changeset.smartOpAssembler();
      },
      textOfLine: (i) => textArray[i],
      appendText: (txt, attrString = '') => {
        textArray[textArray.length - 1] += txt;
        op.attribs = attrString;
        op.chars = txt.length;
        attribsBuilder.append(op);
      },
      textLines: () => textArray.slice(),
      attribLines: () => attribsArray,
      // call flush only when you're done
      flush: (withNewline) => {
        if (attribsBuilder) {
          attribsArray.push(attribsBuilder.toString());
          attribsBuilder = null;
        }
      },
    };
    self.startNew();
    return self;
  })();
  const cc = {};

  const _ensureColumnZero = (state) => {
    if (!lines.atColumnZero()) {
      cc.startNewLine(state);
    }
  };
  let selection, startPoint, endPoint;
  let selStart = [-1, -1];
  let selEnd = [-1, -1];
  const _isEmpty = (node, state) => {
    // consider clean blank lines pasted in IE to be empty
    if (node.childNodes.length === 0) return true;
    if (node.childNodes.length === 1 &&
        getAssoc(node, 'shouldBeEmpty') &&
        node.innerHTML === '&nbsp;' &&
        !getAssoc(node, 'unpasted')) {
      if (state) {
        const child = node.childNodes[0];
        _reachPoint(child, 0, state);
        _reachPoint(child, 1, state);
      }
      return true;
    }
    return false;
  };

  const _pointHere = (charsAfter, state) => {
    const ln = lines.length() - 1;
    let chr = lines.textOfLine(ln).length;
    if (chr === 0 && Object.keys(state.lineAttributes).length !== 0) {
      chr += 1; // listMarker
    }
    chr += charsAfter;
    return [ln, chr];
  };

  const _reachBlockPoint = (nd, idx, state) => {
    if (nd.nodeType !== nd.TEXT_NODE) _reachPoint(nd, idx, state);
  };

  const _reachPoint = (nd, idx, state) => {
    if (startPoint && nd === startPoint.node && startPoint.index === idx) {
      selStart = _pointHere(0, state);
    }
    if (endPoint && nd === endPoint.node && endPoint.index === idx) {
      selEnd = _pointHere(0, state);
    }
  };
  cc.incrementFlag = (state, flagName) => {
    state.flags[flagName] = (state.flags[flagName] || 0) + 1;
  };
  cc.decrementFlag = (state, flagName) => {
    state.flags[flagName]--;
  };
  cc.incrementAttrib = (state, attribName) => {
    if (!state.attribs[attribName]) {
      state.attribs[attribName] = 1;
    } else {
      state.attribs[attribName]++;
    }
    _recalcAttribString(state);
  };
  cc.decrementAttrib = (state, attribName) => {
    state.attribs[attribName]--;
    _recalcAttribString(state);
  };

  const _enterList = (state, listType) => {
    if (!listType) return;
    const oldListType = state.lineAttributes.list;
    if (listType !== 'none') {
      state.listNesting = (state.listNesting || 0) + 1;
      // reminder that listType can be "number2", "number3" etc.
      if (listType.indexOf('number') !== -1) {
        state.start = (state.start || 0) + 1;
      }
    }

    if (listType === 'none') {
      delete state.lineAttributes.list;
    } else {
      state.lineAttributes.list = listType;
    }
    _recalcAttribString(state);
    return oldListType;
  };

  const _exitList = (state, oldListType) => {
    if (state.lineAttributes.list) {
      state.listNesting--;
    }
    if (oldListType && oldListType !== 'none') {
      state.lineAttributes.list = oldListType;
    } else {
      delete state.lineAttributes.list;
      delete state.lineAttributes.start;
    }
    _recalcAttribString(state);
  };

  const _enterAuthor = (state, author) => {
    const oldAuthor = state.author;
    state.authorLevel = (state.authorLevel || 0) + 1;
    state.author = author;
    _recalcAttribString(state);
    return oldAuthor;
  };

  const _exitAuthor = (state, oldAuthor) => {
    state.authorLevel--;
    state.author = oldAuthor;
    _recalcAttribString(state);
  };

  const _recalcAttribString = (state) => {
    const attribs = new AttributeMap(apool);
    for (const [a, count] of Object.entries(state.attribs)) {
      if (!count) continue;
      // The following splitting of the attribute name is a workaround
      // to enable the content collector to store key-value attributes
      // see https://github.com/ether/etherpad-lite/issues/2567 for more information
      // in long term the contentcollector should be refactored to get rid of this workaround
      //
      // TODO: This approach doesn't support changing existing values: if both 'foo::bar' and
      // 'foo::baz' are in state.attribs then the last one encountered while iterating will win.
      const ATTRIBUTE_SPLIT_STRING = '::';

      // see if attributeString is splittable
      const attributeSplits = a.split(ATTRIBUTE_SPLIT_STRING);
      if (attributeSplits.length > 1) {
        // the attribute name follows the convention key::value
        // so save it as a key value attribute
        const [k, v] = attributeSplits;
        if (v) attribs.set(k, v);
      } else {
        // the "normal" case, the attribute is just a switch
        // so set it true
        attribs.set(a, 'true');
      }
    }
    if (state.authorLevel > 0) {
      if (apool.putAttrib(['author', state.author], true) >= 0) {
        // require that author already be in pool
        // (don't add authors from other documents, etc.)
        if (state.author) attribs.set('author', state.author);
      }
    }
    state.attribString = attribs.toString();
  };

  const _produceLineAttributesMarker = (state) => {
    // TODO: This has to go to AttributeManager.
    const attribs = new AttributeMap(apool)
        .set('lmkr', '1')
        .set('insertorder', 'first')
        // TODO: Converting all falsy values in state.lineAttributes into removals is awkward.
        // Better would be to never add 0, false, null, or undefined to state.lineAttributes in the
        // first place (I'm looking at you, state.lineAttributes.start).
        .update(Object.entries(state.lineAttributes).map(([k, v]) => [k, v || '']), true);
    lines.appendText('*', attribs.toString());
  };
  cc.startNewLine = (state) => {
    if (state) {
      const atBeginningOfLine = lines.textOfLine(lines.length() - 1).length === 0;
      if (atBeginningOfLine && Object.keys(state.lineAttributes).length !== 0) {
        _produceLineAttributesMarker(state);
      }
    }
    lines.startNew();
  };
  cc.notifySelection = (sel) => {
    if (sel) {
      selection = sel;
      startPoint = selection.startPoint;
      endPoint = selection.endPoint;
    }
  };
  cc.doAttrib = (state, na) => {
    state.localAttribs = (state.localAttribs || []);
    state.localAttribs.push(na);
    cc.incrementAttrib(state, na);
  };
  cc.collectContent = function (node, state) {
    let unsupportedElements = null;
    if (!state) {
      state = {
        flags: { /* name -> nesting counter*/
        },
        localAttribs: null,
        attribs: { /* name -> nesting counter*/
        },
        attribString: '',
        // lineAttributes maintain a map from attributes to attribute values set on a line
        lineAttributes: {
          /*
          example:
          'list': 'bullet1',
          */
        },
        unsupportedElements: new Set(),
      };
      unsupportedElements = state.unsupportedElements;
    }
    const localAttribs = state.localAttribs;
    state.localAttribs = null;
    const isBlock = isBlockElement(node);
    if (!isBlock && node.name && (node.name !== 'body')) {
      if (!supportedElems.has(node.name)) state.unsupportedElements.add(node.name);
    }
    const isEmpty = _isEmpty(node, state);
    if (isBlock) _ensureColumnZero(state);
    const startLine = lines.length() - 1;
    _reachBlockPoint(node, 0, state);

    if (node.nodeType === node.TEXT_NODE) {
      const tname = node.parentNode.getAttribute('name');
      const context = {cc: this, state, tname, node, text: node.nodeValue};
      // Hook functions may either return a string (deprecated) or modify context.text. If any hook
      // function modifies context.text then all returned strings are ignored. If no hook functions
      // modify context.text, the first hook function to return a string wins.
      const [hookTxt] =
          hooks.callAll('collectContentLineText', context).filter((s) => typeof s === 'string');
      let txt = context.text === node.nodeValue && hookTxt != null ? hookTxt : context.text;

      let rest = '';
      let x = 0; // offset into original text
      if (txt.length === 0) {
        if (startPoint && node === startPoint.node) {
          selStart = _pointHere(0, state);
        }
        if (endPoint && node === endPoint.node) {
          selEnd = _pointHere(0, state);
        }
      }
      while (txt.length > 0) {
        let consumed = 0;
        if (state.flags.preMode) {
          const firstLine = txt.split('\n', 1)[0];
          consumed = firstLine.length + 1;
          rest = txt.substring(consumed);
          txt = firstLine;
        } else { /* will only run this loop body once */
        }
        if (startPoint && node === startPoint.node && startPoint.index - x <= txt.length) {
          selStart = _pointHere(startPoint.index - x, state);
        }
        if (endPoint && node === endPoint.node && endPoint.index - x <= txt.length) {
          selEnd = _pointHere(endPoint.index - x, state);
        }
        let txt2 = txt;
        if ((!state.flags.preMode) && /^[\r\n]*$/.exec(txt)) {
          // prevents textnodes containing just "\n" from being significant
          // in safari when pasting text, now that we convert them to
          // spaces instead of removing them, because in other cases
          // removing "\n" from pasted HTML will collapse words together.
          txt2 = '';
        }
        const atBeginningOfLine = lines.textOfLine(lines.length() - 1).length === 0;
        if (atBeginningOfLine) {
          // newlines in the source mustn't become spaces at beginning of line box
          txt2 = txt2.replace(/^\n*/, '');
        }
        if (atBeginningOfLine && Object.keys(state.lineAttributes).length !== 0) {
          _produceLineAttributesMarker(state);
        }
        lines.appendText(textify(txt2), state.attribString);
        x += consumed;
        txt = rest;
        if (txt.length > 0) {
          cc.startNewLine(state);
        }
      }
    } else if (node.nodeType === node.ELEMENT_NODE) {
      const tname = tagName(node) || '';

      if (tname === 'img') {
        hooks.callAll('collectContentImage', {
          cc,
          state,
          tname,
          styl: null,
          cls: null,
          node,
        });
      } else {
        // THIS SEEMS VERY HACKY! -- Please submit a better fix!
        delete state.lineAttributes.img;
      }

      if (tname === 'br') {
        this.breakLine = true;
        const tvalue = node.getAttribute('value');
        const [startNewLine = true] = hooks.callAll('collectContentLineBreak', {
          cc: this,
          state,
          tname,
          tvalue,
          styl: null,
          cls: null,
        });
        if (startNewLine) {
          cc.startNewLine(state);
        }
      } else if (tname === 'script' || tname === 'style') {
        // ignore
      } else if (!isEmpty) {
        let styl = node.getAttribute('style');
        let cls = node.getAttribute('class');
        let isPre = (tname === 'pre');
        if ((!isPre) && abrowser && abrowser.safari) {
          isPre = (styl && /\bwhite-space:\s*pre\b/i.exec(styl));
        }
        if (isPre) cc.incrementFlag(state, 'preMode');
        let oldListTypeOrNull = null;
        let oldAuthorOrNull = null;

        // LibreOffice Writer puts in weird items during import or copy/paste, we should drop them.
        if (cls === 'Numbering_20_Symbols' || cls === 'Bullet_20_Symbols') {
          styl = null;
          cls = null;

          // We have to return here but this could break things in the future,
          // for now it shows how to fix the problem
          return;
        }
        if (collectStyles) {
          hooks.callAll('collectContentPre', {
            cc,
            state,
            tname,
            styl,
            cls,
          });
          if (tname === 'b' ||
              (styl && /\bfont-weight:\s*bold\b/i.exec(styl)) ||
              tname === 'strong') {
            cc.doAttrib(state, 'bold');
          }
          if (tname === 'i' ||
              (styl && /\bfont-style:\s*italic\b/i.exec(styl)) ||
              tname === 'em') {
            cc.doAttrib(state, 'italic');
          }
          if (tname === 'u' ||
              (styl && /\btext-decoration:\s*underline\b/i.exec(styl)) ||
              tname === 'ins') {
            cc.doAttrib(state, 'underline');
          }
          if (tname === 's' ||
              (styl && /\btext-decoration:\s*line-through\b/i.exec(styl)) ||
              tname === 'del') {
            cc.doAttrib(state, 'strikethrough');
          }
          if (tname === 'ul' || tname === 'ol') {
            let type = node.getAttribute('class');
            const rr = cls && /(?:^| )list-([a-z]+[0-9]+)\b/.exec(cls);
            // lists do not need to have a type, so before we make a wrong guess
            // check if we find a better hint within the node's children
            if (!rr && !type) {
              for (const child of node.childNodes) {
                if (tagName(child) !== 'ul') continue;
                type = child.getAttribute('class');
                if (type) break;
              }
            }
            if (rr && rr[1]) {
              type = rr[1];
            } else {
              if (tname === 'ul') {
                const cls = node.getAttribute('class');
                if ((type && type.match('indent')) || (cls && cls.match('indent'))) {
                  type = 'indent';
                } else {
                  type = 'bullet';
                }
              } else {
                type = 'number';
              }
              type += String(Math.min(_MAX_LIST_LEVEL, (state.listNesting || 0) + 1));
            }
            oldListTypeOrNull = (_enterList(state, type) || 'none');
          } else if ((tname === 'div' || tname === 'p') && cls && cls.match(/(?:^| )ace-line\b/)) {
            // This has undesirable behavior in Chrome but is right in other browsers.
            // See https://github.com/ether/etherpad-lite/issues/2412 for reasoning
            if (!abrowser.chrome) oldListTypeOrNull = (_enterList(state, undefined) || 'none');
          } else if (tname === 'li') {
            state.lineAttributes.start = state.start || 0;
            _recalcAttribString(state);
            if (state.lineAttributes.list.indexOf('number') !== -1) {
              /*
               Nested OLs are not --> <ol><li>1</li><ol>nested</ol></ol>
               They are           --> <ol><li>1</li><li><ol><li>nested</li></ol></li></ol>
               Note how the <ol> item has to be inside a <li>
               Because of this we don't increment the start number
              */
              if (node.parentNode && tagName(node.parentNode) !== 'ol') {
                /*
                TODO: start number has to increment based on indentLevel(numberX)
                This means we have to build an object IE
                {
                 1: 4
                 2: 3
                 3: 5
                }
                But the browser seems to handle it fine using CSS..  Why can't we do the same
                with exports?  We can..  But let's leave this comment in because it might be useful
                in the future..
                */
                state.start++; // not if it's parent is an OL or UL.
              }
            }
            // UL list items never modify the start value.
            if (node.parentNode && tagName(node.parentNode) === 'ul') {
              state.start++;
              // TODO, this is hacky.
              // Because if the first item is an UL it will increment a list no?
              // A much more graceful way would be to say, ul increases if it's within an OL
              // But I don't know a way to do that because we're only aware of the previous Line
              // As the concept of parent's doesn't exist when processing each domline...
            }
          } else {
            // Below needs more testin if it's neccesary as _exitList should take care of this.
            // delete state.start;
            // delete state.listNesting;
            // _recalcAttribString(state);
          }
          if (className2Author && cls) {
            const classes = cls.match(/\S+/g);
            if (classes && classes.length > 0) {
              for (let i = 0; i < classes.length; i++) {
                const c = classes[i];
                const a = className2Author(c);
                if (a) {
                  oldAuthorOrNull = (_enterAuthor(state, a) || 'none');
                  break;
                }
              }
            }
          }
        }

        for (const c of node.childNodes) {
          cc.collectContent(c, state);
        }

        if (collectStyles) {
          hooks.callAll('collectContentPost', {
            cc,
            state,
            tname,
            styl,
            cls,
          });
        }

        if (isPre) cc.decrementFlag(state, 'preMode');
        if (state.localAttribs) {
          for (let i = 0; i < state.localAttribs.length; i++) {
            cc.decrementAttrib(state, state.localAttribs[i]);
          }
        }
        if (oldListTypeOrNull) {
          _exitList(state, oldListTypeOrNull);
        }
        if (oldAuthorOrNull) {
          _exitAuthor(state, oldAuthorOrNull);
        }
      }
    }
    _reachBlockPoint(node, 1, state);
    if (isBlock) {
      if (lines.length() - 1 === startLine) {
        // added additional check to resolve https://github.com/JohnMcLear/ep_copy_paste_images/issues/20
        // this does mean that images etc can't be pasted on lists but imho that's fine

        // If we're doing an export event we need to start a new lines
        // Export events don't have window available.
        // commented out to solve #2412 - https://github.com/ether/etherpad-lite/issues/2412
        if ((state.lineAttributes && !state.lineAttributes.list) || typeof window === 'undefined') {
          cc.startNewLine(state);
        }
      } else {
        _ensureColumnZero(state);
      }
    }
    state.localAttribs = localAttribs;
    if (unsupportedElements && unsupportedElements.size) {
      console.warn('Ignoring unsupported elements (you might want to install a plugin): ' +
                   `${[...unsupportedElements].join(', ')}`);
    }
  };
  // can pass a falsy value for end of doc
  cc.notifyNextNode = (node) => {
    // an "empty block" won't end a line; this addresses an issue in IE with
    // typing into a blank line at the end of the document.  typed text
    // goes into the body, and the empty line div still looks clean.
    // it is incorporated as dirty by the rule that a dirty region has
    // to end a line.
    if ((!node) || (isBlockElement(node) && !_isEmpty(node))) {
      _ensureColumnZero(null);
    }
  };
  // each returns [line, char] or [-1,-1]
  const getSelectionStart = () => selStart;
  const getSelectionEnd = () => selEnd;

  // returns array of strings for lines found, last entry will be "" if
  // last line is complete (i.e. if a following span should be on a new line).
  // can be called at any point
  cc.getLines = () => lines.textLines();

  cc.finish = () => {
    lines.flush();
    const lineAttribs = lines.attribLines();
    const lineStrings = cc.getLines();

    lineStrings.length--;
    lineAttribs.length--;

    const ss = getSelectionStart();
    const se = getSelectionEnd();

    const fixLongLines = () => {
      // design mode does not deal with with really long lines!
      const lineLimit = 2000; // chars
      const buffer = 10; // chars allowed over before wrapping
      let linesWrapped = 0;
      let numLinesAfter = 0;
      for (let i = lineStrings.length - 1; i >= 0; i--) {
        let oldString = lineStrings[i];
        let oldAttribString = lineAttribs[i];
        if (oldString.length > lineLimit + buffer) {
          const newStrings = [];
          const newAttribStrings = [];
          while (oldString.length > lineLimit) {
            // var semiloc = oldString.lastIndexOf(';', lineLimit-1);
            // var lengthToTake = (semiloc >= 0 ? (semiloc+1) : lineLimit);
            const lengthToTake = lineLimit;
            newStrings.push(oldString.substring(0, lengthToTake));
            oldString = oldString.substring(lengthToTake);
            newAttribStrings.push(Changeset.subattribution(oldAttribString, 0, lengthToTake));
            oldAttribString = Changeset.subattribution(oldAttribString, lengthToTake);
          }
          if (oldString.length > 0) {
            newStrings.push(oldString);
            newAttribStrings.push(oldAttribString);
          }

          const fixLineNumber = (lineChar) => {
            if (lineChar[0] < 0) return;
            let n = lineChar[0];
            let c = lineChar[1];
            if (n > i) {
              n += (newStrings.length - 1);
            } else if (n === i) {
              let a = 0;
              while (c > newStrings[a].length) {
                c -= newStrings[a].length;
                a++;
              }
              n += a;
            }
            lineChar[0] = n;
            lineChar[1] = c;
          };
          fixLineNumber(ss);
          fixLineNumber(se);
          linesWrapped++;
          numLinesAfter += newStrings.length;
          lineStrings.splice(i, 1, ...newStrings);
          lineAttribs.splice(i, 1, ...newAttribStrings);
        }
      }
      return {
        linesWrapped,
        numLinesAfter,
      };
    };
    const wrapData = fixLongLines();

    return {
      selStart: ss,
      selEnd: se,
      linesWrapped: wrapData.linesWrapped,
      numLinesAfter: wrapData.numLinesAfter,
      lines: lineStrings,
      lineAttribs,
    };
  };

  return cc;
};

exports.sanitizeUnicode = sanitizeUnicode;
exports.makeContentCollector = makeContentCollector;
exports.supportedElems = supportedElems;
}}["(module ep_etherpad-lite/static/js/contentcollector.js)"],
"ep_etherpad-lite/static/js/changesettracker.js": {"(module ep_etherpad-lite/static/js/changesettracker.js)": function (require, exports, module) {'use strict';

/**
 * This code is mostly from the old Etherpad. Please help us to comment this code.
 * This helps other people to understand this code better and helps them to improve it.
 * TL;DR COMMENTS ON THIS FILE ARE HIGHLY APPRECIATED
 */

/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const AttributeMap = require('./AttributeMap');
const AttributePool = require('./AttributePool');
const Changeset = require('./Changeset');

const makeChangesetTracker = (scheduler, apool, aceCallbacksProvider) => {
  // latest official text from server
  let baseAText = Changeset.makeAText('\n');
  // changes applied to baseText that have been submitted
  let submittedChangeset = null;
  // changes applied to submittedChangeset since it was prepared
  let userChangeset = Changeset.identity(1);
  // is the changesetTracker enabled
  let tracking = false;
  // stack state flag so that when we change the rep we don't
  // handle the notification recursively.  When setting, always
  // unset in a "finally" block.  When set to true, the setter
  // takes change of userChangeset.
  let applyingNonUserChanges = false;

  let changeCallback = null;

  let changeCallbackTimeout = null;

  const setChangeCallbackTimeout = () => {
    // can call this multiple times per call-stack, because
    // we only schedule a call to changeCallback if it exists
    // and if there isn't a timeout already scheduled.
    if (changeCallback && changeCallbackTimeout == null) {
      changeCallbackTimeout = scheduler.setTimeout(() => {
        try {
          changeCallback();
        } catch (pseudoError) {
          // as empty as my soul
        } finally {
          changeCallbackTimeout = null;
        }
      }, 0);
    }
  };

  let self;
  return self = {
    isTracking: () => tracking,
    setBaseText: (text) => {
      self.setBaseAttributedText(Changeset.makeAText(text), null);
    },
    setBaseAttributedText: (atext, apoolJsonObj) => {
      aceCallbacksProvider.withCallbacks('setBaseText', (callbacks) => {
        tracking = true;
        baseAText = Changeset.cloneAText(atext);
        if (apoolJsonObj) {
          const wireApool = (new AttributePool()).fromJsonable(apoolJsonObj);
          baseAText.attribs = Changeset.moveOpsToNewPool(baseAText.attribs, wireApool, apool);
        }
        submittedChangeset = null;
        userChangeset = Changeset.identity(atext.text.length);
        applyingNonUserChanges = true;
        try {
          callbacks.setDocumentAttributedText(atext);
        } finally {
          applyingNonUserChanges = false;
        }
      });
    },
    composeUserChangeset: (c) => {
      if (!tracking) return;
      if (applyingNonUserChanges) return;
      if (Changeset.isIdentity(c)) return;
      userChangeset = Changeset.compose(userChangeset, c, apool);

      setChangeCallbackTimeout();
    },
    applyChangesToBase: (c, optAuthor, apoolJsonObj) => {
      if (!tracking) return;

      aceCallbacksProvider.withCallbacks('applyChangesToBase', (callbacks) => {
        if (apoolJsonObj) {
          const wireApool = (new AttributePool()).fromJsonable(apoolJsonObj);
          c = Changeset.moveOpsToNewPool(c, wireApool, apool);
        }

        baseAText = Changeset.applyToAText(c, baseAText, apool);

        let c2 = c;
        if (submittedChangeset) {
          const oldSubmittedChangeset = submittedChangeset;
          submittedChangeset = Changeset.follow(c, oldSubmittedChangeset, false, apool);
          c2 = Changeset.follow(oldSubmittedChangeset, c, true, apool);
        }

        const preferInsertingAfterUserChanges = true;
        const oldUserChangeset = userChangeset;
        userChangeset = Changeset.follow(
            c2, oldUserChangeset, preferInsertingAfterUserChanges, apool);
        const postChange = Changeset.follow(
            oldUserChangeset, c2, !preferInsertingAfterUserChanges, apool);

        const preferInsertionAfterCaret = true; // (optAuthor && optAuthor > thisAuthor);
        applyingNonUserChanges = true;
        try {
          callbacks.applyChangesetToDocument(postChange, preferInsertionAfterCaret);
        } finally {
          applyingNonUserChanges = false;
        }
      });
    },
    prepareUserChangeset: () => {
      // If there are user changes to submit, 'changeset' will be the
      // changeset, else it will be null.
      let toSubmit;
      if (submittedChangeset) {
        // submission must have been canceled, prepare new changeset
        // that includes old submittedChangeset
        toSubmit = Changeset.compose(submittedChangeset, userChangeset, apool);
      } else {
        // Get my authorID
        const authorId = parent.parent.pad.myUserInfo.userId;

        // Sanitize authorship: Replace all author attributes with this user's author ID in case the
        // text was copied from another author.
        const cs = Changeset.unpack(userChangeset);
        const assem = Changeset.mergingOpAssembler();

        for (const op of Changeset.deserializeOps(cs.ops)) {
          if (op.opcode === '+') {
            const attribs = AttributeMap.fromString(op.attribs, apool);
            const oldAuthorId = attribs.get('author');
            if (oldAuthorId != null && oldAuthorId !== authorId) {
              attribs.set('author', authorId);
              op.attribs = attribs.toString();
            }
          }
          assem.append(op);
        }
        assem.endDocument();
        userChangeset = Changeset.pack(cs.oldLen, cs.newLen, assem.toString(), cs.charBank);
        Changeset.checkRep(userChangeset);

        if (Changeset.isIdentity(userChangeset)) toSubmit = null;
        else toSubmit = userChangeset;
      }

      let cs = null;
      if (toSubmit) {
        submittedChangeset = toSubmit;
        userChangeset = Changeset.identity(Changeset.newLen(toSubmit));

        cs = toSubmit;
      }
      let wireApool = null;
      if (cs) {
        const forWire = Changeset.prepareForWire(cs, apool);
        wireApool = forWire.pool.toJsonable();
        cs = forWire.translated;
      }

      const data = {
        changeset: cs,
        apool: wireApool,
      };
      return data;
    },
    applyPreparedChangesetToBase: () => {
      if (!submittedChangeset) {
        // violation of protocol; use prepareUserChangeset first
        throw new Error('applySubmittedChangesToBase: no submitted changes to apply');
      }
      // bumpDebug("applying committed changeset: "+submittedChangeset.encodeToString(false));
      baseAText = Changeset.applyToAText(submittedChangeset, baseAText, apool);
      submittedChangeset = null;
    },
    setUserChangeNotificationCallback: (callback) => {
      changeCallback = callback;
    },
    hasUncommittedChanges: () => !!(submittedChangeset || (!Changeset.isIdentity(userChangeset))),
  };
};

exports.makeChangesetTracker = makeChangesetTracker;
}}["(module ep_etherpad-lite/static/js/changesettracker.js)"],
"ep_etherpad-lite/static/js/linestylefilter.js": {"(module ep_etherpad-lite/static/js/linestylefilter.js)": function (require, exports, module) {'use strict';

/**
 * This code is mostly from the old Etherpad. Please help us to comment this code.
 * This helps other people to understand this code better and helps them to improve it.
 * TL;DR COMMENTS ON THIS FILE ARE HIGHLY APPRECIATED
 */

// THIS FILE IS ALSO AN APPJET MODULE: etherpad.collab.ace.linestylefilter
// %APPJET%: import("etherpad.collab.ace.easysync2.Changeset");
// %APPJET%: import("etherpad.admin.plugins");
/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// requires: easysync2.Changeset
// requires: top
// requires: plugins
// requires: undefined

const Changeset = require('./Changeset');
const attributes = require('./attributes');
const hooks = require('./pluginfw/hooks');
const linestylefilter = {};
const AttributeManager = require('./AttributeManager');
const padutils = require('./pad_utils').padutils;

linestylefilter.ATTRIB_CLASSES = {
  bold: 'tag:b',
  italic: 'tag:i',
  underline: 'tag:u',
  strikethrough: 'tag:s',
};

const lineAttributeMarker = 'lineAttribMarker';
exports.lineAttributeMarker = lineAttributeMarker;

linestylefilter.getAuthorClassName = (author) => `author-${author.replace(/[^a-y0-9]/g, (c) => {
  if (c === '.') return '-';
  return `z${c.charCodeAt(0)}z`;
})}`;

// lineLength is without newline; aline includes newline,
// but may be falsy if lineLength == 0
linestylefilter.getLineStyleFilter = (lineLength, aline, textAndClassFunc, apool) => {
  // Plugin Hook to add more Attrib Classes
  for (const attribClasses of hooks.callAll('aceAttribClasses', linestylefilter.ATTRIB_CLASSES)) {
    Object.assign(linestylefilter.ATTRIB_CLASSES, attribClasses);
  }

  if (lineLength === 0) return textAndClassFunc;

  const nextAfterAuthorColors = textAndClassFunc;

  const authorColorFunc = (() => {
    const lineEnd = lineLength;
    let curIndex = 0;
    let extraClasses;
    let leftInAuthor;

    const attribsToClasses = (attribs) => {
      let classes = '';
      let isLineAttribMarker = false;

      for (const [key, value] of attributes.attribsFromString(attribs, apool)) {
        if (!key || !value) continue;
        if (!isLineAttribMarker && AttributeManager.lineAttributes.indexOf(key) >= 0) {
          isLineAttribMarker = true;
        }
        if (key === 'author') {
          classes += ` ${linestylefilter.getAuthorClassName(value)}`;
        } else if (key === 'list') {
          classes += ` list:${value}`;
        } else if (key === 'start') {
          // Needed to introduce the correct Ordered list item start number on import
          classes += ` start:${value}`;
        } else if (linestylefilter.ATTRIB_CLASSES[key]) {
          classes += ` ${linestylefilter.ATTRIB_CLASSES[key]}`;
        } else {
          const results = hooks.callAll('aceAttribsToClasses', {linestylefilter, key, value});
          classes += ` ${results.join(' ')}`;
        }
      }

      if (isLineAttribMarker) classes += ` ${lineAttributeMarker}`;
      return classes.substring(1);
    };

    const attrOps = Changeset.deserializeOps(aline);
    let attrOpsNext = attrOps.next();
    let nextOp, nextOpClasses;

    const goNextOp = () => {
      nextOp = attrOpsNext.done ? new Changeset.Op() : attrOpsNext.value;
      if (!attrOpsNext.done) attrOpsNext = attrOps.next();
      nextOpClasses = (nextOp.opcode && attribsToClasses(nextOp.attribs));
    };
    goNextOp();

    const nextClasses = () => {
      if (curIndex < lineEnd) {
        extraClasses = nextOpClasses;
        leftInAuthor = nextOp.chars;
        goNextOp();
        while (nextOp.opcode && nextOpClasses === extraClasses) {
          leftInAuthor += nextOp.chars;
          goNextOp();
        }
      }
    };
    nextClasses();

    return (txt, cls) => {
      const disableAuthColorForThisLine = hooks.callAll('disableAuthorColorsForThisLine', {
        linestylefilter,
        text: txt,
        class: cls,
      });
      const disableAuthors = (disableAuthColorForThisLine == null ||
        disableAuthColorForThisLine.length === 0) ? false : disableAuthColorForThisLine[0];
      while (txt.length > 0) {
        if (leftInAuthor <= 0 || disableAuthors) {
          // prevent infinite loop if something funny's going on
          return nextAfterAuthorColors(txt, cls);
        }
        let spanSize = txt.length;
        if (spanSize > leftInAuthor) {
          spanSize = leftInAuthor;
        }
        const curTxt = txt.substring(0, spanSize);
        txt = txt.substring(spanSize);
        nextAfterAuthorColors(curTxt, (cls && `${cls} `) + extraClasses);
        curIndex += spanSize;
        leftInAuthor -= spanSize;
        if (leftInAuthor === 0) {
          nextClasses();
        }
      }
    };
  })();
  return authorColorFunc;
};

linestylefilter.getAtSignSplitterFilter = (lineText, textAndClassFunc) => {
  const at = /@/g;
  at.lastIndex = 0;
  let splitPoints = null;
  let execResult;
  while ((execResult = at.exec(lineText))) {
    if (!splitPoints) {
      splitPoints = [];
    }
    splitPoints.push(execResult.index);
  }

  if (!splitPoints) return textAndClassFunc;

  return linestylefilter.textAndClassFuncSplitter(textAndClassFunc, splitPoints);
};

linestylefilter.getRegexpFilter = (regExp, tag) => (lineText, textAndClassFunc) => {
  regExp.lastIndex = 0;
  let regExpMatchs = null;
  let splitPoints = null;
  let execResult;
  while ((execResult = regExp.exec(lineText))) {
    if (!regExpMatchs) {
      regExpMatchs = [];
      splitPoints = [];
    }
    const startIndex = execResult.index;
    const regExpMatch = execResult[0];
    regExpMatchs.push([startIndex, regExpMatch]);
    splitPoints.push(startIndex, startIndex + regExpMatch.length);
  }

  if (!regExpMatchs) return textAndClassFunc;

  const regExpMatchForIndex = (idx) => {
    for (let k = 0; k < regExpMatchs.length; k++) {
      const u = regExpMatchs[k];
      if (idx >= u[0] && idx < u[0] + u[1].length) {
        return u[1];
      }
    }
    return false;
  };

  const handleRegExpMatchsAfterSplit = (() => {
    let curIndex = 0;
    return (txt, cls) => {
      const txtlen = txt.length;
      let newCls = cls;
      const regExpMatch = regExpMatchForIndex(curIndex);
      if (regExpMatch) {
        newCls += ` ${tag}:${regExpMatch}`;
      }
      textAndClassFunc(txt, newCls);
      curIndex += txtlen;
    };
  })();

  return linestylefilter.textAndClassFuncSplitter(handleRegExpMatchsAfterSplit, splitPoints);
};


linestylefilter.getURLFilter = linestylefilter.getRegexpFilter(padutils.urlRegex, 'url');

linestylefilter.textAndClassFuncSplitter = (func, splitPointsOpt) => {
  let nextPointIndex = 0;
  let idx = 0;

  // don't split at 0
  while (splitPointsOpt &&
      nextPointIndex < splitPointsOpt.length &&
      splitPointsOpt[nextPointIndex] === 0) {
    nextPointIndex++;
  }

  const spanHandler = (txt, cls) => {
    if ((!splitPointsOpt) || nextPointIndex >= splitPointsOpt.length) {
      func(txt, cls);
      idx += txt.length;
    } else {
      const splitPoints = splitPointsOpt;
      const pointLocInSpan = splitPoints[nextPointIndex] - idx;
      const txtlen = txt.length;
      if (pointLocInSpan >= txtlen) {
        func(txt, cls);
        idx += txt.length;
        if (pointLocInSpan === txtlen) {
          nextPointIndex++;
        }
      } else {
        if (pointLocInSpan > 0) {
          func(txt.substring(0, pointLocInSpan), cls);
          idx += pointLocInSpan;
        }
        nextPointIndex++;
        // recurse
        spanHandler(txt.substring(pointLocInSpan), cls);
      }
    }
  };
  return spanHandler;
};

linestylefilter.getFilterStack = (lineText, textAndClassFunc, abrowser) => {
  let func = linestylefilter.getURLFilter(lineText, textAndClassFunc);

  const hookFilters = hooks.callAll('aceGetFilterStack', {
    linestylefilter,
    browser: abrowser,
  });
  hookFilters.map((hookFilter) => {
    func = hookFilter(lineText, func);
  });

  return func;
};

// domLineObj is like that returned by domline.createDomLine
linestylefilter.populateDomLine = (textLine, aline, apool, domLineObj) => {
  // remove final newline from text if any
  let text = textLine;
  if (text.slice(-1) === '\n') {
    text = text.substring(0, text.length - 1);
  }

  const textAndClassFunc = (tokenText, tokenClass) => {
    domLineObj.appendSpan(tokenText, tokenClass);
  };

  let func = linestylefilter.getFilterStack(text, textAndClassFunc);
  func = linestylefilter.getLineStyleFilter(text.length, aline, func, apool);
  func(text, '');
};

exports.linestylefilter = linestylefilter;
}}["(module ep_etherpad-lite/static/js/linestylefilter.js)"],
"ep_etherpad-lite/static/js/domline.js": {"(module ep_etherpad-lite/static/js/domline.js)": function (require, exports, module) {'use strict';

// THIS FILE IS ALSO AN APPJET MODULE: etherpad.collab.ace.domline
// %APPJET%: import("etherpad.admin.plugins");
/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// requires: top
// requires: plugins
// requires: undefined

const Security = require('./security');
const hooks = require('./pluginfw/hooks');
const _ = require('./underscore');
const lineAttributeMarker = require('./linestylefilter').lineAttributeMarker;
const noop = () => {};


const domline = {};

domline.addToLineClass = (lineClass, cls) => {
  // an "empty span" at any point can be used to add classes to
  // the line, using line:className.  otherwise, we ignore
  // the span.
  cls.replace(/\S+/g, (c) => {
    if (c.indexOf('line:') === 0) {
      // add class to line
      lineClass = (lineClass ? `${lineClass} ` : '') + c.substring(5);
    }
  });
  return lineClass;
};

// if "document" is falsy we don't create a DOM node, just
// an object with innerHTML and className
domline.createDomLine = (nonEmpty, doesWrap, optBrowser, optDocument) => {
  const result = {
    node: null,
    appendSpan: noop,
    prepareForAdd: noop,
    notifyAdded: noop,
    clearSpans: noop,
    finishUpdate: noop,
    lineMarker: 0,
  };

  const document = optDocument;

  if (document) {
    result.node = document.createElement('div');
    // JAWS and NVDA screen reader compatibility. Only needed if in a real browser.
    result.node.setAttribute('aria-live', 'assertive');
  } else {
    result.node = {
      innerHTML: '',
      className: '',
    };
  }

  let html = [];
  let preHtml = '';
  let postHtml = '';
  let curHTML = null;

  const processSpaces = (s) => domline.processSpaces(s, doesWrap);
  const perTextNodeProcess = (doesWrap ? _.identity : processSpaces);
  const perHtmlLineProcess = (doesWrap ? processSpaces : _.identity);
  let lineClass = 'ace-line';

  result.appendSpan = (txt, cls) => {
    let processedMarker = false;
    // Handle lineAttributeMarker, if present
    if (cls.indexOf(lineAttributeMarker) >= 0) {
      let listType = /(?:^| )list:(\S+)/.exec(cls);
      const start = /(?:^| )start:(\S+)/.exec(cls);

      _.map(hooks.callAll('aceDomLinePreProcessLineAttributes', {
        domline,
        cls,
      }), (modifier) => {
        preHtml += modifier.preHtml;
        postHtml += modifier.postHtml;
        processedMarker |= modifier.processedMarker;
      });
      if (listType) {
        listType = listType[1];
        if (listType) {
          if (listType.indexOf('number') < 0) {
            preHtml += `<ul class="list-${Security.escapeHTMLAttribute(listType)}"><li>`;
            postHtml = `</li></ul>${postHtml}`;
          } else {
            if (start) { // is it a start of a list with more than one item in?
              if (Number.parseInt(start[1]) === 1) { // if its the first one at this level?
                // Add start class to DIV node
                lineClass = `${lineClass} ` + `list-start-${listType}`;
              }
              preHtml +=
                `<ol start=${start[1]} class="list-${Security.escapeHTMLAttribute(listType)}"><li>`;
            } else {
              // Handles pasted contents into existing lists
              preHtml += `<ol class="list-${Security.escapeHTMLAttribute(listType)}"><li>`;
            }
            postHtml += '</li></ol>';
          }
        }
        processedMarker = true;
      }
      _.map(hooks.callAll('aceDomLineProcessLineAttributes', {
        domline,
        cls,
      }), (modifier) => {
        preHtml += modifier.preHtml;
        postHtml += modifier.postHtml;
        processedMarker |= modifier.processedMarker;
      });
      if (processedMarker) {
        result.lineMarker += txt.length;
        return; // don't append any text
      }
    }
    let href = null;
    let simpleTags = null;
    if (cls.indexOf('url') >= 0) {
      cls = cls.replace(/(^| )url:(\S+)/g, (x0, space, url) => {
        href = url;
        return `${space}url`;
      });
    }
    if (cls.indexOf('tag') >= 0) {
      cls = cls.replace(/(^| )tag:(\S+)/g, (x0, space, tag) => {
        if (!simpleTags) simpleTags = [];
        simpleTags.push(tag.toLowerCase());
        return space + tag;
      });
    }

    let extraOpenTags = '';
    let extraCloseTags = '';

    _.map(hooks.callAll('aceCreateDomLine', {
      domline,
      cls,
    }), (modifier) => {
      cls = modifier.cls;
      extraOpenTags += modifier.extraOpenTags;
      extraCloseTags = modifier.extraCloseTags + extraCloseTags;
    });

    if ((!txt) && cls) {
      lineClass = domline.addToLineClass(lineClass, cls);
    } else if (txt) {
      if (href) {
        const urn_schemes = new RegExp('^(about|geo|mailto|tel):');
        // if the url doesn't include a protocol prefix, assume http
        if (!~href.indexOf('://') && !urn_schemes.test(href)) {
          href = `http://${href}`;
        }
        // Using rel="noreferrer" stops leaking the URL/location of the pad when
        // clicking links in the document.
        // Not all browsers understand this attribute, but it's part of the HTML5 standard.
        // https://html.spec.whatwg.org/multipage/links.html#link-type-noreferrer
        // Additionally, we do rel="noopener" to ensure a higher level of referrer security.
        // https://html.spec.whatwg.org/multipage/links.html#link-type-noopener
        // https://mathiasbynens.github.io/rel-noopener/
        // https://github.com/ether/etherpad-lite/pull/3636
        const escapedHref = Security.escapeHTMLAttribute(href);
        extraOpenTags = `${extraOpenTags}<a href="${escapedHref}" rel="noreferrer noopener">`;
        extraCloseTags = `</a>${extraCloseTags}`;
      }
      if (simpleTags) {
        simpleTags.sort();
        extraOpenTags = `${extraOpenTags}<${simpleTags.join('><')}>`;
        simpleTags.reverse();
        extraCloseTags = `</${simpleTags.join('></')}>${extraCloseTags}`;
      }
      html.push(
          '<span class="', Security.escapeHTMLAttribute(cls || ''),
          '">',
          extraOpenTags,
          perTextNodeProcess(Security.escapeHTML(txt)),
          extraCloseTags,
          '</span>');
    }
  };
  result.clearSpans = () => {
    html = [];
    lineClass = 'ace-line';
    result.lineMarker = 0;
  };

  const writeHTML = () => {
    let newHTML = perHtmlLineProcess(html.join(''));
    if (!newHTML) {
      if ((!document) || (!optBrowser)) {
        newHTML += '&nbsp;';
      } else {
        newHTML += '<br/>';
      }
    }
    if (nonEmpty) {
      newHTML = (preHtml || '') + newHTML + (postHtml || '');
    }
    html = preHtml = postHtml = ''; // free memory
    if (newHTML !== curHTML) {
      curHTML = newHTML;
      result.node.innerHTML = curHTML;
    }
    if (lineClass != null) result.node.className = lineClass;

    hooks.callAll('acePostWriteDomLineHTML', {
      node: result.node,
    });
  };
  result.prepareForAdd = writeHTML;
  result.finishUpdate = writeHTML;
  return result;
};

domline.processSpaces = (s, doesWrap) => {
  if (s.indexOf('<') < 0 && !doesWrap) {
    // short-cut
    return s.replace(/ /g, '&nbsp;');
  }
  const parts = [];
  s.replace(/<[^>]*>?| |[^ <]+/g, (m) => {
    parts.push(m);
  });
  if (doesWrap) {
    let endOfLine = true;
    let beforeSpace = false;
    // last space in a run is normal, others are nbsp,
    // end of line is nbsp
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      if (p === ' ') {
        if (endOfLine || beforeSpace) parts[i] = '&nbsp;';
        endOfLine = false;
        beforeSpace = true;
      } else if (p.charAt(0) !== '<') {
        endOfLine = false;
        beforeSpace = false;
      }
    }
    // beginning of line is nbsp
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      if (p === ' ') {
        parts[i] = '&nbsp;';
        break;
      } else if (p.charAt(0) !== '<') {
        break;
      }
    }
  } else {
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i];
      if (p === ' ') {
        parts[i] = '&nbsp;';
      }
    }
  }
  return parts.join('');
};

exports.domline = domline;
}}["(module ep_etherpad-lite/static/js/domline.js)"],
"ep_etherpad-lite/static/js/AttributeManager.js": {"(module ep_etherpad-lite/static/js/AttributeManager.js)": function (require, exports, module) {'use strict';

const AttributeMap = require('./AttributeMap');
const Changeset = require('./Changeset');
const ChangesetUtils = require('./ChangesetUtils');
const attributes = require('./attributes');
const _ = require('./underscore');

const lineMarkerAttribute = 'lmkr';

// Some of these attributes are kept for compatibility purposes.
// Not sure if we need all of them
const DEFAULT_LINE_ATTRIBUTES = ['author', 'lmkr', 'insertorder', 'start'];

// If one of these attributes are set to the first character of a
// line it is considered as a line attribute marker i.e. attributes
// set on this marker are applied to the whole line.
// The list attribute is only maintained for compatibility reasons
const lineAttributes = [lineMarkerAttribute, 'list'];

/*
  The Attribute manager builds changesets based on a document
  representation for setting and removing range or line-based attributes.

  @param rep the document representation to be used
  @param applyChangesetCallback this callback will be called
    once a changeset has been built.


  A document representation contains
  - an array `alines` containing 1 attributes string for each line
  - an Attribute pool `apool`
  - a SkipList `lines` containing the text lines of the document.
*/

const AttributeManager = function (rep, applyChangesetCallback) {
  this.rep = rep;
  this.applyChangesetCallback = applyChangesetCallback;
  this.author = '';

  // If the first char in a line has one of the following attributes
  // it will be considered as a line marker
};

AttributeManager.DEFAULT_LINE_ATTRIBUTES = DEFAULT_LINE_ATTRIBUTES;
AttributeManager.lineAttributes = lineAttributes;

AttributeManager.prototype = _(AttributeManager.prototype).extend({

  applyChangeset(changeset) {
    if (!this.applyChangesetCallback) return changeset;

    const cs = changeset.toString();
    if (!Changeset.isIdentity(cs)) {
      this.applyChangesetCallback(cs);
    }

    return changeset;
  },

  /*
    Sets attributes on a range
    @param start [row, col] tuple pointing to the start of the range
    @param end [row, col] tuple pointing to the end of the range
    @param attribs: an array of attributes
  */
  setAttributesOnRange(start, end, attribs) {
    if (start[0] < 0) throw new RangeError('selection start line number is negative');
    if (start[1] < 0) throw new RangeError('selection start column number is negative');
    if (end[0] < 0) throw new RangeError('selection end line number is negative');
    if (end[1] < 0) throw new RangeError('selection end column number is negative');
    if (start[0] > end[0] || (start[0] === end[0] && start[1] > end[1])) {
      throw new RangeError('selection ends before it starts');
    }

    // instead of applying the attributes to the whole range at once, we need to apply them
    // line by line, to be able to disregard the "*" used as line marker. For more details,
    // see https://github.com/ether/etherpad-lite/issues/2772
    let allChangesets;
    for (let row = start[0]; row <= end[0]; row++) {
      const [startCol, endCol] = this._findRowRange(row, start, end);
      const rowChangeset = this._setAttributesOnRangeByLine(row, startCol, endCol, attribs);

      // compose changesets of all rows into a single changeset
      // as the range might not be continuous
      // due to the presence of line markers on the rows
      if (allChangesets) {
        allChangesets = Changeset.compose(
            allChangesets.toString(), rowChangeset.toString(), this.rep.apool);
      } else {
        allChangesets = rowChangeset;
      }
    }

    return this.applyChangeset(allChangesets);
  },

  _findRowRange(row, start, end) {
    if (row < start[0] || row > end[0]) throw new RangeError(`line ${row} not in selection`);
    if (row >= this.rep.lines.length()) throw new RangeError(`selected line ${row} does not exist`);

    // Subtract 1 for the end-of-line '\n' (it is never selected).
    const lineLength =
        this.rep.lines.offsetOfIndex(row + 1) - this.rep.lines.offsetOfIndex(row) - 1;
    const markerWidth = this.lineHasMarker(row) ? 1 : 0;
    if (lineLength - markerWidth < 0) throw new Error(`line ${row} has negative length`);

    if (start[1] < 0) throw new RangeError('selection starts at negative column');
    const startCol = Math.max(markerWidth, row === start[0] ? start[1] : 0);
    if (startCol > lineLength) throw new RangeError('selection starts after line end');

    if (end[1] < 0) throw new RangeError('selection ends at negative column');
    const endCol = Math.max(markerWidth, row === end[0] ? end[1] : lineLength);
    if (endCol > lineLength) throw new RangeError('selection ends after line end');
    if (startCol > endCol) throw new RangeError('selection ends before it starts');

    return [startCol, endCol];
  },

  /**
   * Sets attributes on a range, by line
   * @param row the row where range is
   * @param startCol column where range starts
   * @param endCol column where range ends (one past the last selected column)
   * @param attribs an array of attributes
   */
  _setAttributesOnRangeByLine(row, startCol, endCol, attribs) {
    const builder = Changeset.builder(this.rep.lines.totalWidth());
    ChangesetUtils.buildKeepToStartOfRange(this.rep, builder, [row, startCol]);
    ChangesetUtils.buildKeepRange(
        this.rep, builder, [row, startCol], [row, endCol], attribs, this.rep.apool);
    return builder;
  },

  /*
    Returns if the line already has a line marker
    @param lineNum: the number of the line
  */
  lineHasMarker(lineNum) {
    return lineAttributes.find(
        (attribute) => this.getAttributeOnLine(lineNum, attribute) !== '') !== undefined;
  },

  /*
    Gets a specified attribute on a line
    @param lineNum: the number of the line to set the attribute for
    @param attributeKey: the name of the attribute to get, e.g. list
  */
  getAttributeOnLine(lineNum, attributeName) {
    // get  `attributeName` attribute of first char of line
    const aline = this.rep.alines[lineNum];
    if (!aline) return '';
    const [op] = Changeset.deserializeOps(aline);
    if (op == null) return '';
    return AttributeMap.fromString(op.attribs, this.rep.apool).get(attributeName) || '';
  },

  /*
    Gets all attributes on a line
    @param lineNum: the number of the line to get the attribute for
  */
  getAttributesOnLine(lineNum) {
    // get attributes of first char of line
    const aline = this.rep.alines[lineNum];
    if (!aline) return [];
    const [op] = Changeset.deserializeOps(aline);
    if (op == null) return [];
    return [...attributes.attribsFromString(op.attribs, this.rep.apool)];
  },

  /*
    Gets a given attribute on a selection
    @param attributeName
    @param prevChar
    returns true or false if an attribute is visible in range
  */
  getAttributeOnSelection(attributeName, prevChar) {
    const rep = this.rep;
    if (!(rep.selStart && rep.selEnd)) return;
    // If we're looking for the caret attribute not the selection
    // has the user already got a selection or is this purely a caret location?
    const isNotSelection = (rep.selStart[0] === rep.selEnd[0] && rep.selEnd[1] === rep.selStart[1]);
    if (isNotSelection) {
      if (prevChar) {
        // If it's not the start of the line
        if (rep.selStart[1] !== 0) {
          rep.selStart[1]--;
        }
      }
    }

    const withIt = new AttributeMap(rep.apool).set(attributeName, 'true').toString();
    const withItRegex = new RegExp(`${withIt.replace(/\*/g, '\\*')}(\\*|$)`);
    const hasIt = (attribs) => withItRegex.test(attribs);

    const rangeHasAttrib = (selStart, selEnd) => {
      // if range is collapsed -> no attribs in range
      if (selStart[1] === selEnd[1] && selStart[0] === selEnd[0]) return false;

      if (selStart[0] !== selEnd[0]) { // -> More than one line selected
        // from selStart to the end of the first line
        let hasAttrib = rangeHasAttrib(
            selStart, [selStart[0], rep.lines.atIndex(selStart[0]).text.length]);

        // for all lines in between
        for (let n = selStart[0] + 1; n < selEnd[0]; n++) {
          hasAttrib = hasAttrib && rangeHasAttrib([n, 0], [n, rep.lines.atIndex(n).text.length]);
        }

        // for the last, potentially partial, line
        hasAttrib = hasAttrib && rangeHasAttrib([selEnd[0], 0], [selEnd[0], selEnd[1]]);

        return hasAttrib;
      }

      // Logic tells us we now have a range on a single line

      const lineNum = selStart[0];
      const start = selStart[1];
      const end = selEnd[1];
      let hasAttrib = true;

      let indexIntoLine = 0;
      for (const op of Changeset.deserializeOps(rep.alines[lineNum])) {
        const opStartInLine = indexIntoLine;
        const opEndInLine = opStartInLine + op.chars;
        if (!hasIt(op.attribs)) {
          // does op overlap selection?
          if (!(opEndInLine <= start || opStartInLine >= end)) {
            // since it's overlapping but hasn't got the attrib -> range hasn't got it
            hasAttrib = false;
            break;
          }
        }
        indexIntoLine = opEndInLine;
      }

      return hasAttrib;
    };
    return rangeHasAttrib(rep.selStart, rep.selEnd);
  },

  /*
    Gets all attributes at a position containing line number and column
    @param lineNumber starting with zero
    @param column starting with zero
    returns a list of attributes in the format
    [ ["key","value"], ["key","value"], ...  ]
  */
  getAttributesOnPosition(lineNumber, column) {
    // get all attributes of the line
    const aline = this.rep.alines[lineNumber];

    if (!aline) {
      return [];
    }

    // we need to sum up how much characters each operations take until the wanted position
    let currentPointer = 0;

    for (const currentOperation of Changeset.deserializeOps(aline)) {
      currentPointer += currentOperation.chars;
      if (currentPointer <= column) continue;
      return [...attributes.attribsFromString(currentOperation.attribs, this.rep.apool)];
    }
    return [];
  },

  /*
    Gets all attributes at caret position
    if the user selected a range, the start of the selection is taken
    returns a list of attributes in the format
    [ ["key","value"], ["key","value"], ...  ]
  */
  getAttributesOnCaret() {
    return this.getAttributesOnPosition(this.rep.selStart[0], this.rep.selStart[1]);
  },

  /*
    Sets a specified attribute on a line
    @param lineNum: the number of the line to set the attribute for
    @param attributeKey: the name of the attribute to set, e.g. list
    @param attributeValue: an optional parameter to pass to the attribute (e.g. indention level)

  */
  setAttributeOnLine(lineNum, attributeName, attributeValue) {
    let loc = [0, 0];
    const builder = Changeset.builder(this.rep.lines.totalWidth());
    const hasMarker = this.lineHasMarker(lineNum);

    ChangesetUtils.buildKeepRange(this.rep, builder, loc, (loc = [lineNum, 0]));

    if (hasMarker) {
      ChangesetUtils.buildKeepRange(this.rep, builder, loc, (loc = [lineNum, 1]), [
        [attributeName, attributeValue],
      ], this.rep.apool);
    } else {
      // add a line marker
      builder.insert('*', [
        ['author', this.author],
        ['insertorder', 'first'],
        [lineMarkerAttribute, '1'],
        [attributeName, attributeValue],
      ], this.rep.apool);
    }

    return this.applyChangeset(builder);
  },

  /**
   * Removes a specified attribute on a line
   *  @param lineNum the number of the affected line
   *  @param attributeName the name of the attribute to remove, e.g. list
   *  @param attributeValue if given only attributes with equal value will be removed
   */
  removeAttributeOnLine(lineNum, attributeName, attributeValue) {
    const builder = Changeset.builder(this.rep.lines.totalWidth());
    const hasMarker = this.lineHasMarker(lineNum);
    let found = false;

    const attribs = this.getAttributesOnLine(lineNum).map((attrib) => {
      if (attrib[0] === attributeName && (!attributeValue || attrib[0] === attributeValue)) {
        found = true;
        return [attrib[0], ''];
      } else if (attrib[0] === 'author') {
        // update last author to make changes to line attributes on this line
        return [attrib[0], this.author];
      }
      return attrib;
    });

    if (!found) {
      return;
    }

    ChangesetUtils.buildKeepToStartOfRange(this.rep, builder, [lineNum, 0]);

    const countAttribsWithMarker = _.chain(attribs).filter((a) => !!a[1])
        .map((a) => a[0]).difference(DEFAULT_LINE_ATTRIBUTES).size().value();

    // if we have marker and any of attributes don't need to have marker. we need delete it
    if (hasMarker && !countAttribsWithMarker) {
      ChangesetUtils.buildRemoveRange(this.rep, builder, [lineNum, 0], [lineNum, 1]);
    } else {
      ChangesetUtils.buildKeepRange(
          this.rep, builder, [lineNum, 0], [lineNum, 1], attribs, this.rep.apool);
    }

    return this.applyChangeset(builder);
  },

  /*
     Toggles a line attribute for the specified line number
     If a line attribute with the specified name exists with any value it will be removed
     Otherwise it will be set to the given value
     @param lineNum: the number of the line to toggle the attribute for
     @param attributeKey: the name of the attribute to toggle, e.g. list
     @param attributeValue: the value to pass to the attribute (e.g. indention level)
  */
  toggleAttributeOnLine(lineNum, attributeName, attributeValue) {
    return this.getAttributeOnLine(lineNum, attributeName)
      ? this.removeAttributeOnLine(lineNum, attributeName)
      : this.setAttributeOnLine(lineNum, attributeName, attributeValue);
  },

  hasAttributeOnSelectionOrCaretPosition(attributeName) {
    const hasSelection = (
      (this.rep.selStart[0] !== this.rep.selEnd[0]) || (this.rep.selEnd[1] !== this.rep.selStart[1])
    );
    let hasAttrib;
    if (hasSelection) {
      hasAttrib = this.getAttributeOnSelection(attributeName);
    } else {
      const attributesOnCaretPosition = this.getAttributesOnCaret();
      const allAttribs = [].concat(...attributesOnCaretPosition); // flatten
      hasAttrib = allAttribs.includes(attributeName);
    }
    return hasAttrib;
  },
});

module.exports = AttributeManager;
}}["(module ep_etherpad-lite/static/js/AttributeManager.js)"],
"ep_etherpad-lite/static/js/AttributeMap.js": {"(module ep_etherpad-lite/static/js/AttributeMap.js)": function (require, exports, module) {'use strict';

const attributes = require('./attributes');

/**
 * A `[key, value]` pair of strings describing a text attribute.
 *
 * @typedef {[string, string]} Attribute
 */

/**
 * A concatenated sequence of zero or more attribute identifiers, each one represented by an
 * asterisk followed by a base-36 encoded attribute number.
 *
 * Examples: '', '*0', '*3*j*z*1q'
 *
 * @typedef {string} AttributeString
 */

/**
 * Convenience class to convert an Op's attribute string to/from a Map of key, value pairs.
 */
class AttributeMap extends Map {
  /**
   * Converts an attribute string into an AttributeMap.
   *
   * @param {AttributeString} str - The attribute string to convert into an AttributeMap.
   * @param {AttributePool} pool - Attribute pool.
   * @returns {AttributeMap}
   */
  static fromString(str, pool) {
    return new AttributeMap(pool).updateFromString(str);
  }

  /**
   * @param {AttributePool} pool - Attribute pool.
   */
  constructor(pool) {
    super();
    /** @public */
    this.pool = pool;
  }

  /**
   * @param {string} k - Attribute name.
   * @param {string} v - Attribute value.
   * @returns {AttributeMap} `this` (for chaining).
   */
  set(k, v) {
    k = k == null ? '' : String(k);
    v = v == null ? '' : String(v);
    this.pool.putAttrib([k, v]);
    return super.set(k, v);
  }

  toString() {
    return attributes.attribsToString(attributes.sort([...this]), this.pool);
  }

  /**
   * @param {Iterable<Attribute>} entries - [key, value] pairs to insert into this map.
   * @param {boolean} [emptyValueIsDelete] - If true and an entry's value is the empty string, the
   *     key is removed from this map (if present).
   * @returns {AttributeMap} `this` (for chaining).
   */
  update(entries, emptyValueIsDelete = false) {
    for (let [k, v] of entries) {
      k = k == null ? '' : String(k);
      v = v == null ? '' : String(v);
      if (!v && emptyValueIsDelete) {
        this.delete(k);
      } else {
        this.set(k, v);
      }
    }
    return this;
  }

  /**
   * @param {AttributeString} str - The attribute string identifying the attributes to insert into
   *     this map.
   * @param {boolean} [emptyValueIsDelete] - If true and an entry's value is the empty string, the
   *     key is removed from this map (if present).
   * @returns {AttributeMap} `this` (for chaining).
   */
  updateFromString(str, emptyValueIsDelete = false) {
    return this.update(attributes.attribsFromString(str, this.pool), emptyValueIsDelete);
  }
}

module.exports = AttributeMap;
}}["(module ep_etherpad-lite/static/js/AttributeMap.js)"],
"ep_etherpad-lite/static/js/attributes.js": {"(module ep_etherpad-lite/static/js/attributes.js)": function (require, exports, module) {'use strict';

// Low-level utilities for manipulating attribute strings. For a high-level API, see AttributeMap.

/**
 * A `[key, value]` pair of strings describing a text attribute.
 *
 * @typedef {[string, string]} Attribute
 */

/**
 * A concatenated sequence of zero or more attribute identifiers, each one represented by an
 * asterisk followed by a base-36 encoded attribute number.
 *
 * Examples: '', '*0', '*3*j*z*1q'
 *
 * @typedef {string} AttributeString
 */

/**
 * Converts an attribute string into a sequence of attribute identifier numbers.
 *
 * WARNING: This only works on attribute strings. It does NOT work on serialized operations or
 * changesets.
 *
 * @param {AttributeString} str - Attribute string.
 * @yields {number} The attribute numbers (to look up in the associated pool), in the order they
 *     appear in `str`.
 * @returns {Generator<number>}
 */
exports.decodeAttribString = function* (str) {
  const re = /\*([0-9a-z]+)|./gy;
  let match;
  while ((match = re.exec(str)) != null) {
    const [m, n] = match;
    if (n == null) throw new Error(`invalid character in attribute string: ${m}`);
    yield Number.parseInt(n, 36);
  }
};

const checkAttribNum = (n) => {
  if (typeof n !== 'number') throw new TypeError(`not a number: ${n}`);
  if (n < 0) throw new Error(`attribute number is negative: ${n}`);
  if (n !== Math.trunc(n)) throw new Error(`attribute number is not an integer: ${n}`);
};

/**
 * Inverse of `decodeAttribString`.
 *
 * @param {Iterable<number>} attribNums - Sequence of attribute numbers.
 * @returns {AttributeString}
 */
exports.encodeAttribString = (attribNums) => {
  let str = '';
  for (const n of attribNums) {
    checkAttribNum(n);
    str += `*${n.toString(36).toLowerCase()}`;
  }
  return str;
};

/**
 * Converts a sequence of attribute numbers into a sequence of attributes.
 *
 * @param {Iterable<number>} attribNums - Attribute numbers to look up in the pool.
 * @param {AttributePool} pool - Attribute pool.
 * @yields {Attribute} The identified attributes, in the same order as `attribNums`.
 * @returns {Generator<Attribute>}
 */
exports.attribsFromNums = function* (attribNums, pool) {
  for (const n of attribNums) {
    checkAttribNum(n);
    const attrib = pool.getAttrib(n);
    if (attrib == null) throw new Error(`attribute ${n} does not exist in pool`);
    yield attrib;
  }
};

/**
 * Inverse of `attribsFromNums`.
 *
 * @param {Iterable<Attribute>} attribs - Attributes. Any attributes not already in `pool` are
 *     inserted into `pool`. No checking is performed to ensure that the attributes are in the
 *     canonical order and that there are no duplicate keys. (Use an AttributeMap and/or `sort()` if
 *     required.)
 * @param {AttributePool} pool - Attribute pool.
 * @yields {number} The attribute number of each attribute in `attribs`, in order.
 * @returns {Generator<number>}
 */
exports.attribsToNums = function* (attribs, pool) {
  for (const attrib of attribs) yield pool.putAttrib(attrib);
};

/**
 * Convenience function that is equivalent to `attribsFromNums(decodeAttribString(str), pool)`.
 *
 * WARNING: This only works on attribute strings. It does NOT work on serialized operations or
 * changesets.
 *
 * @param {AttributeString} str - Attribute string.
 * @param {AttributePool} pool - Attribute pool.
 * @yields {Attribute} The attributes identified in `str`, in order.
 * @returns {Generator<Attribute>}
 */
exports.attribsFromString = function* (str, pool) {
  yield* exports.attribsFromNums(exports.decodeAttribString(str), pool);
};

/**
 * Inverse of `attribsFromString`.
 *
 * @param {Iterable<Attribute>} attribs - Attributes. The attributes to insert into the pool (if
 *     necessary) and encode. No checking is performed to ensure that the attributes are in the
 *     canonical order and that there are no duplicate keys. (Use an AttributeMap and/or `sort()` if
 *     required.)
 * @param {AttributePool} pool - Attribute pool.
 * @returns {AttributeString}
 */
exports.attribsToString =
    (attribs, pool) => exports.encodeAttribString(exports.attribsToNums(attribs, pool));

/**
 * Sorts the attributes in canonical order. The order of entries with the same attribute name is
 * unspecified.
 *
 * @param {Attribute[]} attribs - Attributes to sort in place.
 * @returns {Attribute[]} `attribs` (for chaining).
 */
exports.sort =
    (attribs) => attribs.sort(([keyA], [keyB]) => (keyA > keyB ? 1 : 0) - (keyA < keyB ? 1 : 0));
}}["(module ep_etherpad-lite/static/js/attributes.js)"],
"ep_etherpad-lite/static/js/scroll.js": {"(module ep_etherpad-lite/static/js/scroll.js)": function (require, exports, module) {'use strict';

/*
  This file handles scroll on edition or when user presses arrow keys.
  In this file we have two representations of line (browser and rep line).
  Rep Line = a line in the way is represented by Etherpad(rep) (each <div> is a line)
  Browser Line = each vertical line. A <div> can be break into more than one
  browser line.
*/
const caretPosition = require('./caretPosition');

function Scroll(outerWin) {
  // scroll settings
  this.scrollSettings = parent.parent.clientVars.scrollWhenFocusLineIsOutOfViewport;

  // DOM reference
  this.outerWin = outerWin;
  this.doc = this.outerWin.document;
  this.rootDocument = parent.parent.document;
}

Scroll.prototype.scrollWhenCaretIsInTheLastLineOfViewportWhenNecessary =
  function (rep, isScrollableEvent, innerHeight) {
  // are we placing the caret on the line at the bottom of viewport?
  // And if so, do we need to scroll the editor, as defined on the settings.json?
    const shouldScrollWhenCaretIsAtBottomOfViewport =
      this.scrollSettings.scrollWhenCaretIsInTheLastLineOfViewport;
    if (shouldScrollWhenCaretIsAtBottomOfViewport) {
      // avoid scrolling when selection includes multiple lines --
      // user can potentially be selecting more lines
      // than it fits on viewport
      const multipleLinesSelected = rep.selStart[0] !== rep.selEnd[0];

      // avoid scrolling when pad loads
      if (isScrollableEvent && !multipleLinesSelected && this._isCaretAtTheBottomOfViewport(rep)) {
        // when scrollWhenFocusLineIsOutOfViewport.percentage is 0, pixelsToScroll is 0
        const pixelsToScroll = this._getPixelsRelativeToPercentageOfViewport(innerHeight);
        this._scrollYPage(pixelsToScroll);
      }
    }
  };

Scroll.prototype.scrollWhenPressArrowKeys = function (arrowUp, rep, innerHeight) {
  // if percentageScrollArrowUp is 0, let the scroll to be handled as default, put the previous
  // rep line on the top of the viewport
  if (this._arrowUpWasPressedInTheFirstLineOfTheViewport(arrowUp, rep)) {
    const pixelsToScroll = this._getPixelsToScrollWhenUserPressesArrowUp(innerHeight);

    // by default, the browser scrolls to the middle of the viewport. To avoid the twist made
    // when we apply a second scroll, we made it immediately (without animation)
    this._scrollYPageWithoutAnimation(-pixelsToScroll);
  } else {
    this.scrollNodeVerticallyIntoView(rep, innerHeight);
  }
};

// Some plugins might set a minimum height to the editor (ex: ep_page_view), so checking
// if (caretLine() === rep.lines.length() - 1) is not enough. We need to check if there are
// other lines after caretLine(), and all of them are out of viewport.
Scroll.prototype._isCaretAtTheBottomOfViewport = function (rep) {
  // computing a line position using getBoundingClientRect() is expensive.
  // (obs: getBoundingClientRect() is called on caretPosition.getPosition())
  // To avoid that, we only call this function when it is possible that the
  // caret is in the bottom of viewport
  const caretLine = rep.selStart[0];
  const lineAfterCaretLine = caretLine + 1;
  const firstLineVisibleAfterCaretLine = caretPosition.getNextVisibleLine(lineAfterCaretLine, rep);
  const caretLineIsPartiallyVisibleOnViewport =
    this._isLinePartiallyVisibleOnViewport(caretLine, rep);
  const lineAfterCaretLineIsPartiallyVisibleOnViewport =
    this._isLinePartiallyVisibleOnViewport(firstLineVisibleAfterCaretLine, rep);
  if (caretLineIsPartiallyVisibleOnViewport || lineAfterCaretLineIsPartiallyVisibleOnViewport) {
    // check if the caret is in the bottom of the viewport
    const caretLinePosition = caretPosition.getPosition();
    const viewportBottom = this._getViewPortTopBottom().bottom;
    const nextLineBottom = caretPosition.getBottomOfNextBrowserLine(caretLinePosition, rep);
    const nextLineIsBelowViewportBottom = nextLineBottom > viewportBottom;
    return nextLineIsBelowViewportBottom;
  }
  return false;
};

Scroll.prototype._isLinePartiallyVisibleOnViewport = function (lineNumber, rep) {
  const lineNode = rep.lines.atIndex(lineNumber);
  const linePosition = this._getLineEntryTopBottom(lineNode);
  const lineTop = linePosition.top;
  const lineBottom = linePosition.bottom;
  const viewport = this._getViewPortTopBottom();
  const viewportBottom = viewport.bottom;
  const viewportTop = viewport.top;

  const topOfLineIsAboveOfViewportBottom = lineTop < viewportBottom;
  const bottomOfLineIsOnOrBelowOfViewportBottom = lineBottom >= viewportBottom;
  const topOfLineIsBelowViewportTop = lineTop >= viewportTop;
  const topOfLineIsAboveViewportBottom = lineTop <= viewportBottom;
  const bottomOfLineIsAboveViewportBottom = lineBottom <= viewportBottom;
  const bottomOfLineIsBelowViewportTop = lineBottom >= viewportTop;

  return (topOfLineIsAboveOfViewportBottom && bottomOfLineIsOnOrBelowOfViewportBottom) ||
    (topOfLineIsBelowViewportTop && topOfLineIsAboveViewportBottom) ||
    (bottomOfLineIsAboveViewportBottom && bottomOfLineIsBelowViewportTop);
};

Scroll.prototype._getViewPortTopBottom = function () {
  const theTop = this.getScrollY();
  const doc = this.doc;
  const height = doc.documentElement.clientHeight; // includes padding

  // we have to get the exactly height of the viewport.
  // So it has to subtract all the values which changes
  // the viewport height (E.g. padding, position top)
  const viewportExtraSpacesAndPosition =
    this._getEditorPositionTop() + this._getPaddingTopAddedWhenPageViewIsEnable();
  return {
    top: theTop,
    bottom: (theTop + height - viewportExtraSpacesAndPosition),
  };
};

Scroll.prototype._getEditorPositionTop = function () {
  const editor = parent.document.getElementsByTagName('iframe');
  const editorPositionTop = editor[0].offsetTop;
  return editorPositionTop;
};

// ep_page_view adds padding-top, which makes the viewport smaller
Scroll.prototype._getPaddingTopAddedWhenPageViewIsEnable = function () {
  const aceOuter = this.rootDocument.getElementsByName('ace_outer');
  const aceOuterPaddingTop = parseInt($(aceOuter).css('padding-top'));
  return aceOuterPaddingTop;
};

Scroll.prototype._getScrollXY = function () {
  const win = this.outerWin;
  const odoc = this.doc;
  if (typeof (win.pageYOffset) === 'number') {
    return {
      x: win.pageXOffset,
      y: win.pageYOffset,
    };
  }
  const docel = odoc.documentElement;
  if (docel && typeof (docel.scrollTop) === 'number') {
    return {
      x: docel.scrollLeft,
      y: docel.scrollTop,
    };
  }
};

Scroll.prototype.getScrollX = function () {
  return this._getScrollXY().x;
};

Scroll.prototype.getScrollY = function () {
  return this._getScrollXY().y;
};

Scroll.prototype.setScrollX = function (x) {
  this.outerWin.scrollTo(x, this.getScrollY());
};

Scroll.prototype.setScrollY = function (y) {
  this.outerWin.scrollTo(this.getScrollX(), y);
};

Scroll.prototype.setScrollXY = function (x, y) {
  this.outerWin.scrollTo(x, y);
};

Scroll.prototype._isCaretAtTheTopOfViewport = function (rep) {
  const caretLine = rep.selStart[0];
  const linePrevCaretLine = caretLine - 1;
  const firstLineVisibleBeforeCaretLine =
    caretPosition.getPreviousVisibleLine(linePrevCaretLine, rep);
  const caretLineIsPartiallyVisibleOnViewport =
    this._isLinePartiallyVisibleOnViewport(caretLine, rep);
  const lineBeforeCaretLineIsPartiallyVisibleOnViewport =
    this._isLinePartiallyVisibleOnViewport(firstLineVisibleBeforeCaretLine, rep);
  if (caretLineIsPartiallyVisibleOnViewport || lineBeforeCaretLineIsPartiallyVisibleOnViewport) {
    const caretLinePosition = caretPosition.getPosition(); // get the position of the browser line
    const viewportPosition = this._getViewPortTopBottom();
    const viewportTop = viewportPosition.top;
    const viewportBottom = viewportPosition.bottom;
    const caretLineIsBelowViewportTop = caretLinePosition.bottom >= viewportTop;
    const caretLineIsAboveViewportBottom = caretLinePosition.top < viewportBottom;
    const caretLineIsInsideOfViewport =
      caretLineIsBelowViewportTop && caretLineIsAboveViewportBottom;
    if (caretLineIsInsideOfViewport) {
      const prevLineTop = caretPosition.getPositionTopOfPreviousBrowserLine(caretLinePosition, rep);
      const previousLineIsAboveViewportTop = prevLineTop < viewportTop;
      return previousLineIsAboveViewportTop;
    }
  }
  return false;
};

// By default, when user makes an edition in a line out of viewport, this line goes
// to the edge of viewport. This function gets the extra pixels necessary to get the
// caret line in a position X relative to Y% viewport.
Scroll.prototype._getPixelsRelativeToPercentageOfViewport =
  function (innerHeight, aboveOfViewport) {
    let pixels = 0;
    const scrollPercentageRelativeToViewport = this._getPercentageToScroll(aboveOfViewport);
    if (scrollPercentageRelativeToViewport > 0 && scrollPercentageRelativeToViewport <= 1) {
      pixels = parseInt(innerHeight * scrollPercentageRelativeToViewport);
    }
    return pixels;
  };

// we use different percentages when change selection. It depends on if it is
// either above the top or below the bottom of the page
Scroll.prototype._getPercentageToScroll = function (aboveOfViewport) {
  let percentageToScroll = this.scrollSettings.percentage.editionBelowViewport;
  if (aboveOfViewport) {
    percentageToScroll = this.scrollSettings.percentage.editionAboveViewport;
  }
  return percentageToScroll;
};

Scroll.prototype._getPixelsToScrollWhenUserPressesArrowUp = function (innerHeight) {
  let pixels = 0;
  const percentageToScrollUp = this.scrollSettings.percentageToScrollWhenUserPressesArrowUp;
  if (percentageToScrollUp > 0 && percentageToScrollUp <= 1) {
    pixels = parseInt(innerHeight * percentageToScrollUp);
  }
  return pixels;
};

Scroll.prototype._scrollYPage = function (pixelsToScroll) {
  const durationOfAnimationToShowFocusline = this.scrollSettings.duration;
  if (durationOfAnimationToShowFocusline) {
    this._scrollYPageWithAnimation(pixelsToScroll, durationOfAnimationToShowFocusline);
  } else {
    this._scrollYPageWithoutAnimation(pixelsToScroll);
  }
};

Scroll.prototype._scrollYPageWithoutAnimation = function (pixelsToScroll) {
  this.outerWin.scrollBy(0, pixelsToScroll);
};

Scroll.prototype._scrollYPageWithAnimation =
  function (pixelsToScroll, durationOfAnimationToShowFocusline) {
    const outerDocBody = this.doc.getElementById('outerdocbody');

    // it works on later versions of Chrome
    const $outerDocBody = $(outerDocBody);
    this._triggerScrollWithAnimation(
        $outerDocBody, pixelsToScroll, durationOfAnimationToShowFocusline);

    // it works on Firefox and earlier versions of Chrome
    const $outerDocBodyParent = $outerDocBody.parent();
    this._triggerScrollWithAnimation(
        $outerDocBodyParent, pixelsToScroll, durationOfAnimationToShowFocusline);
  };

// using a custom queue and clearing it, we avoid creating a queue of scroll animations.
// So if this function is called twice quickly, only the last one runs.
Scroll.prototype._triggerScrollWithAnimation =
  function ($elem, pixelsToScroll, durationOfAnimationToShowFocusline) {
    // clear the queue of animation
    $elem.stop('scrollanimation');
    $elem.animate({
      scrollTop: `+=${pixelsToScroll}`,
    }, {
      duration: durationOfAnimationToShowFocusline,
      queue: 'scrollanimation',
    }).dequeue('scrollanimation');
  };

// scrollAmountWhenFocusLineIsOutOfViewport is set to 0 (default), scroll it the minimum distance
// needed to be completely in view. If the value is greater than 0 and less than or equal to 1,
// besides of scrolling the minimum needed to be visible, it scrolls additionally
// (viewport height * scrollAmountWhenFocusLineIsOutOfViewport) pixels
Scroll.prototype.scrollNodeVerticallyIntoView = function (rep, innerHeight) {
  const viewport = this._getViewPortTopBottom();

  // when the selection changes outside of the viewport the browser automatically scrolls the line
  // to inside of the viewport. Tested on IE, Firefox, Chrome in releases from 2015 until now
  // So, when the line scrolled gets outside of the viewport we let the browser handle it.
  const linePosition = caretPosition.getPosition();
  if (linePosition) {
    const distanceOfTopOfViewport = linePosition.top - viewport.top;
    const distanceOfBottomOfViewport = viewport.bottom - linePosition.bottom - linePosition.height;
    const caretIsAboveOfViewport = distanceOfTopOfViewport < 0;
    const caretIsBelowOfViewport = distanceOfBottomOfViewport < 0;
    if (caretIsAboveOfViewport) {
      const pixelsToScroll =
        distanceOfTopOfViewport - this._getPixelsRelativeToPercentageOfViewport(innerHeight, true);
      this._scrollYPage(pixelsToScroll);
    } else if (caretIsBelowOfViewport) {
      // setTimeout is required here as line might not be fully rendered onto the pad
      setTimeout(() => {
        const outer = window.parent;
        // scroll to the very end of the pad outer
        outer.scrollTo(0, outer[0].innerHeight);
      }, 150);
      // if the above setTimeout and functionality is removed then hitting an enter
      // key while on the last line wont be an optimal user experience
      // Details at: https://github.com/ether/etherpad-lite/pull/4639/files
    }
  }
};

Scroll.prototype._partOfRepLineIsOutOfViewport = function (viewportPosition, rep) {
  const focusLine = (rep.selFocusAtStart ? rep.selStart[0] : rep.selEnd[0]);
  const line = rep.lines.atIndex(focusLine);
  const linePosition = this._getLineEntryTopBottom(line);
  const lineIsAboveOfViewport = linePosition.top < viewportPosition.top;
  const lineIsBelowOfViewport = linePosition.bottom > viewportPosition.bottom;

  return lineIsBelowOfViewport || lineIsAboveOfViewport;
};

Scroll.prototype._getLineEntryTopBottom = function (entry, destObj) {
  const dom = entry.lineNode;
  const top = dom.offsetTop;
  const height = dom.offsetHeight;
  const obj = (destObj || {});
  obj.top = top;
  obj.bottom = (top + height);
  return obj;
};

Scroll.prototype._arrowUpWasPressedInTheFirstLineOfTheViewport = function (arrowUp, rep) {
  const percentageScrollArrowUp = this.scrollSettings.percentageToScrollWhenUserPressesArrowUp;
  return percentageScrollArrowUp && arrowUp && this._isCaretAtTheTopOfViewport(rep);
};

Scroll.prototype.getVisibleLineRange = function (rep) {
  const viewport = this._getViewPortTopBottom();
  // console.log("viewport top/bottom: %o", viewport);
  const obj = {};
  const self = this;
  const start = rep.lines.search((e) => self._getLineEntryTopBottom(e, obj).bottom > viewport.top);
  // return the first line that the top position is greater or equal than
  // the viewport. That is the first line that is below the viewport bottom.
  // So the line that is in the bottom of the viewport is the very previous one.
  let end = rep.lines.search((e) => self._getLineEntryTopBottom(e, obj).top >= viewport.bottom);
  if (end < start) end = start; // unlikely
  // top.console.log(start+","+(end -1));
  return [start, end - 1];
};

Scroll.prototype.getVisibleCharRange = function (rep) {
  const lineRange = this.getVisibleLineRange(rep);
  return [rep.lines.offsetOfIndex(lineRange[0]), rep.lines.offsetOfIndex(lineRange[1])];
};

exports.init = (outerWin) => new Scroll(outerWin);
}}["(module ep_etherpad-lite/static/js/scroll.js)"],
"ep_etherpad-lite/static/js/caretPosition.js": {"(module ep_etherpad-lite/static/js/caretPosition.js)": function (require, exports, module) {'use strict';

// One rep.line(div) can be broken in more than one line in the browser.
// This function is useful to get the caret position of the line as
// is represented by the browser
exports.getPosition = () => {
  const range = getSelectionRange();
  if (!range || $(range.endContainer).closest('body')[0].id !== 'innerdocbody') return null;
  // When there's a <br> or any element that has no height, we can't get the dimension of the
  // element where the caret is. As we can't get the element height, we create a text node to get
  // the dimensions on the position.
  const clonedRange = createSelectionRange(range);
  const shadowCaret = $(document.createTextNode('|'));
  clonedRange.insertNode(shadowCaret[0]);
  clonedRange.selectNode(shadowCaret[0]);
  const line = getPositionOfElementOrSelection(clonedRange);
  shadowCaret.remove();
  return line;
};

const createSelectionRange = (range) => {
  const clonedRange = range.cloneRange();

  // we set the selection start and end to avoid error when user selects a text bigger than
  // the viewport height and uses the arrow keys to expand the selection. In this particular
  // case is necessary to know where the selections ends because both edges of the selection
  // is out of the viewport but we only use the end of it to calculate if it needs to scroll
  clonedRange.setStart(range.endContainer, range.endOffset);
  clonedRange.setEnd(range.endContainer, range.endOffset);
  return clonedRange;
};

const getPositionOfRepLineAtOffset = (node, offset) => {
  // it is not a text node, so we cannot make a selection
  if (node.tagName === 'BR' || node.tagName === 'EMPTY') {
    return getPositionOfElementOrSelection(node);
  }

  while (node.length === 0 && node.nextSibling) {
    node = node.nextSibling;
  }

  const newRange = new Range();
  newRange.setStart(node, offset);
  newRange.setEnd(node, offset);
  const linePosition = getPositionOfElementOrSelection(newRange);
  newRange.detach(); // performance sake
  return linePosition;
};

const getPositionOfElementOrSelection = (element) => {
  const rect = element.getBoundingClientRect();
  const linePosition = {
    bottom: rect.bottom,
    height: rect.height,
    top: rect.top,
  };
  return linePosition;
};

// here we have two possibilities:
// [1] the line before the caret line has the same type, so both of them has the same margin,
// padding height, etc. So, we can use the caret line to make calculation necessary to know
// where is the top of the previous line
// [2] the line before is part of another rep line. It's possible this line has different margins
// height. So we have to get the exactly position of the line
exports.getPositionTopOfPreviousBrowserLine = (caretLinePosition, rep) => {
  let previousLineTop = caretLinePosition.top - caretLinePosition.height; // [1]
  const isCaretLineFirstBrowserLine = caretLineIsFirstBrowserLine(caretLinePosition.top, rep);

  // the caret is in the beginning of a rep line, so the previous browser line
  // is the last line browser line of the a rep line
  if (isCaretLineFirstBrowserLine) { // [2]
    const lineBeforeCaretLine = rep.selStart[0] - 1;
    const firstLineVisibleBeforeCaretLine = getPreviousVisibleLine(lineBeforeCaretLine, rep);
    const linePosition =
      getDimensionOfLastBrowserLineOfRepLine(firstLineVisibleBeforeCaretLine, rep);
    previousLineTop = linePosition.top;
  }
  return previousLineTop;
};

const caretLineIsFirstBrowserLine = (caretLineTop, rep) => {
  const caretRepLine = rep.selStart[0];
  const lineNode = rep.lines.atIndex(caretRepLine).lineNode;
  const firstRootNode = getFirstRootChildNode(lineNode);

  // to get the position of the node we get the position of the first char
  const positionOfFirstRootNode = getPositionOfRepLineAtOffset(firstRootNode, 1);
  return positionOfFirstRootNode.top === caretLineTop;
};

// find the first root node, usually it is a text node
const getFirstRootChildNode = (node) => {
  if (!node.firstChild) {
    return node;
  } else {
    return getFirstRootChildNode(node.firstChild);
  }
};

const getDimensionOfLastBrowserLineOfRepLine = (line, rep) => {
  const lineNode = rep.lines.atIndex(line).lineNode;
  const lastRootChildNode = getLastRootChildNode(lineNode);

  // we get the position of the line in the last char of it
  const lastRootChildNodePosition =
    getPositionOfRepLineAtOffset(lastRootChildNode.node, lastRootChildNode.length);
  return lastRootChildNodePosition;
};

const getLastRootChildNode = (node) => {
  if (!node.lastChild) {
    return {
      node,
      length: node.length,
    };
  } else {
    return getLastRootChildNode(node.lastChild);
  }
};

// here we have two possibilities:
// [1] The next line is part of the same rep line of the caret line, so we have the same dimensions.
// So, we can use the caret line to calculate the bottom of the line.
// [2] the next line is part of another rep line.
// It's possible this line has different dimensions, so we have to get the exactly dimension of it
exports.getBottomOfNextBrowserLine = (caretLinePosition, rep) => {
  let nextLineBottom = caretLinePosition.bottom + caretLinePosition.height; // [1]
  const isCaretLineLastBrowserLine =
    caretLineIsLastBrowserLineOfRepLine(caretLinePosition.top, rep);

  // the caret is at the end of a rep line, so we can get the next browser line dimension
  // using the position of the first char of the next rep line
  if (isCaretLineLastBrowserLine) { // [2]
    const nextLineAfterCaretLine = rep.selStart[0] + 1;
    const firstNextLineVisibleAfterCaretLine = getNextVisibleLine(nextLineAfterCaretLine, rep);
    const linePosition =
      getDimensionOfFirstBrowserLineOfRepLine(firstNextLineVisibleAfterCaretLine, rep);
    nextLineBottom = linePosition.bottom;
  }
  return nextLineBottom;
};

const caretLineIsLastBrowserLineOfRepLine = (caretLineTop, rep) => {
  const caretRepLine = rep.selStart[0];
  const lineNode = rep.lines.atIndex(caretRepLine).lineNode;
  const lastRootChildNode = getLastRootChildNode(lineNode);

  // we take a rep line and get the position of the last char of it
  const lastRootChildNodePosition =
    getPositionOfRepLineAtOffset(lastRootChildNode.node, lastRootChildNode.length);
  return lastRootChildNodePosition.top === caretLineTop;
};

const getPreviousVisibleLine = (line, rep) => {
  const firstLineOfPad = 0;
  if (line <= firstLineOfPad) {
    return firstLineOfPad;
  } else if (isLineVisible(line, rep)) {
    return line;
  } else {
    return getPreviousVisibleLine(line - 1, rep);
  }
};


exports.getPreviousVisibleLine = getPreviousVisibleLine;

const getNextVisibleLine = (line, rep) => {
  const lastLineOfThePad = rep.lines.length() - 1;
  if (line >= lastLineOfThePad) {
    return lastLineOfThePad;
  } else if (isLineVisible(line, rep)) {
    return line;
  } else {
    return getNextVisibleLine(line + 1, rep);
  }
};
exports.getNextVisibleLine = getNextVisibleLine;

const isLineVisible = (line, rep) => rep.lines.atIndex(line).lineNode.offsetHeight > 0;

const getDimensionOfFirstBrowserLineOfRepLine = (line, rep) => {
  const lineNode = rep.lines.atIndex(line).lineNode;
  const firstRootChildNode = getFirstRootChildNode(lineNode);

  // we can get the position of the line, getting the position of the first char of the rep line
  const firstRootChildNodePosition = getPositionOfRepLineAtOffset(firstRootChildNode, 1);
  return firstRootChildNodePosition;
};

const getSelectionRange = () => {
  if (!window.getSelection) {
    return;
  }
  const selection = window.getSelection();
  if (selection && selection.type !== 'None' && selection.rangeCount > 0) {
    return selection.getRangeAt(0);
  } else {
    return null;
  }
};
}}["(module ep_etherpad-lite/static/js/caretPosition.js)"],
"ep_etherpad-lite/static/js/pad_utils.js": {"(module ep_etherpad-lite/static/js/pad_utils.js)": function (require, exports, module) {'use strict';

/**
 * This code is mostly from the old Etherpad. Please help us to comment this code.
 * This helps other people to understand this code better and helps them to improve it.
 * TL;DR COMMENTS ON THIS FILE ARE HIGHLY APPRECIATED
 */

/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const Security = require('./security');

/**
 * Generates a random String with the given length. Is needed to generate the Author, Group,
 * readonly, session Ids
 */
const randomString = (len) => {
  const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  let randomstring = '';
  len = len || 20;
  for (let i = 0; i < len; i++) {
    const rnum = Math.floor(Math.random() * chars.length);
    randomstring += chars.substring(rnum, rnum + 1);
  }
  return randomstring;
};

// Set of "letter or digit" chars is based on section 20.5.16 of the original Java Language Spec.
const wordCharRegex = new RegExp(`[${[
  '\u0030-\u0039',
  '\u0041-\u005A',
  '\u0061-\u007A',
  '\u00C0-\u00D6',
  '\u00D8-\u00F6',
  '\u00F8-\u00FF',
  '\u0100-\u1FFF',
  '\u3040-\u9FFF',
  '\uF900-\uFDFF',
  '\uFE70-\uFEFE',
  '\uFF10-\uFF19',
  '\uFF21-\uFF3A',
  '\uFF41-\uFF5A',
  '\uFF66-\uFFDC',
].join('')}]`);

const urlRegex = (() => {
  // TODO: wordCharRegex matches many characters that are not permitted in URIs. Are they included
  // here as an attempt to support IRIs? (See https://tools.ietf.org/html/rfc3987.)
  const urlChar = `[-:@_.,~%+/?=&#!;()\\[\\]$'*${wordCharRegex.source.slice(1, -1)}]`;
  // Matches a single character that should not be considered part of the URL if it is the last
  // character that matches urlChar.
  const postUrlPunct = '[:.,;?!)\\]\'*]';
  // Schemes that must be followed by ://
  const withAuth = `(?:${[
    '(?:x-)?man',
    'afp',
    'file',
    'ftps?',
    'gopher',
    'https?',
    'nfs',
    'sftp',
    'smb',
    'txmt',
  ].join('|')})://`;
  // Schemes that do not need to be followed by ://
  const withoutAuth = `(?:${[
    'about',
    'geo',
    'mailto',
    'tel',
  ].join('|')}):`;
  return new RegExp(
      `(?:${withAuth}|${withoutAuth}|www\\.)${urlChar}*(?!${postUrlPunct})${urlChar}`, 'g');
})();

// https://stackoverflow.com/a/68957976
const base64url = /^(?=(?:.{4})*$)[A-Za-z0-9_-]*(?:[AQgw]==|[AEIMQUYcgkosw048]=)?$/;

const padutils = {
  /**
   * Prints a warning message followed by a stack trace (to make it easier to figure out what code
   * is using the deprecated function).
   *
   * Identical deprecation warnings (as determined by the stack trace, if available) are rate
   * limited to avoid log spam.
   *
   * Most browsers include UI widget to examine the stack at the time of the warning, but this
   * includes the stack in the log message for a couple of reasons:
   *   - This makes it possible to see the stack if the code runs in Node.js.
   *   - Users are more likely to paste the stack in bug reports they might file.
   *
   * @param {...*} args - Passed to `padutils.warnDeprecated.logger.warn` (or `console.warn` if no
   *     logger is set), with a stack trace appended if available.
   */
  warnDeprecated: (...args) => {
    if (padutils.warnDeprecated.disabledForTestingOnly) return;
    const err = new Error();
    if (Error.captureStackTrace) Error.captureStackTrace(err, padutils.warnDeprecated);
    err.name = '';
    // Rate limit identical deprecation warnings (as determined by the stack) to avoid log spam.
    if (typeof err.stack === 'string') {
      if (padutils.warnDeprecated._rl == null) {
        padutils.warnDeprecated._rl =
            {prevs: new Map(), now: () => Date.now(), period: 10 * 60 * 1000};
      }
      const rl = padutils.warnDeprecated._rl;
      const now = rl.now();
      const prev = rl.prevs.get(err.stack);
      if (prev != null && now - prev < rl.period) return;
      rl.prevs.set(err.stack, now);
    }
    if (err.stack) args.push(err.stack);
    (padutils.warnDeprecated.logger || console).warn(...args);
  },

  escapeHtml: (x) => Security.escapeHTML(String(x)),
  uniqueId: () => {
    const pad = require('./pad').pad; // Sidestep circular dependency
    // returns string that is exactly 'width' chars, padding with zeros and taking rightmost digits
    const encodeNum =
        (n, width) => (Array(width + 1).join('0') + Number(n).toString(35)).slice(-width);
    return [
      pad.getClientIp(),
      encodeNum(+new Date(), 7),
      encodeNum(Math.floor(Math.random() * 1e9), 4),
    ].join('.');
  },
  // e.g. "Thu Jun 18 2009 13:09"
  simpleDateTime: (date) => {
    const d = new Date(+date); // accept either number or date
    const dayOfWeek = (['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'])[d.getDay()];
    const month = ([
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ])[d.getMonth()];
    const dayOfMonth = d.getDate();
    const year = d.getFullYear();
    const hourmin = `${d.getHours()}:${(`0${d.getMinutes()}`).slice(-2)}`;
    return `${dayOfWeek} ${month} ${dayOfMonth} ${year} ${hourmin}`;
  },
  wordCharRegex,
  urlRegex,
  // returns null if no URLs, or [[startIndex1, url1], [startIndex2, url2], ...]
  findURLs: (text) => {
    // Copy padutils.urlRegex so that the use of .exec() below (which mutates the RegExp object)
    // does not break other concurrent uses of padutils.urlRegex.
    const urlRegex = new RegExp(padutils.urlRegex, 'g');
    urlRegex.lastIndex = 0;
    let urls = null;
    let execResult;
    // TODO: Switch to String.prototype.matchAll() after support for Node.js < 12.0.0 is dropped.
    while ((execResult = urlRegex.exec(text))) {
      urls = (urls || []);
      const startIndex = execResult.index;
      const url = execResult[0];
      urls.push([startIndex, url]);
    }
    return urls;
  },
  escapeHtmlWithClickableLinks: (text, target) => {
    let idx = 0;
    const pieces = [];
    const urls = padutils.findURLs(text);

    const advanceTo = (i) => {
      if (i > idx) {
        pieces.push(Security.escapeHTML(text.substring(idx, i)));
        idx = i;
      }
    };
    if (urls) {
      for (let j = 0; j < urls.length; j++) {
        const startIndex = urls[j][0];
        const href = urls[j][1];
        advanceTo(startIndex);
        // Using rel="noreferrer" stops leaking the URL/location of the pad when clicking links in
        // the document. Not all browsers understand this attribute, but it's part of the HTML5
        // standard. https://html.spec.whatwg.org/multipage/links.html#link-type-noreferrer
        // Additionally, we do rel="noopener" to ensure a higher level of referrer security.
        // https://html.spec.whatwg.org/multipage/links.html#link-type-noopener
        // https://mathiasbynens.github.io/rel-noopener/
        // https://github.com/ether/etherpad-lite/pull/3636
        pieces.push(
            '<a ',
            (target ? `target="${Security.escapeHTMLAttribute(target)}" ` : ''),
            'href="',
            Security.escapeHTMLAttribute(href),
            '" rel="noreferrer noopener">');
        advanceTo(startIndex + href.length);
        pieces.push('</a>');
      }
    }
    advanceTo(text.length);
    return pieces.join('');
  },
  bindEnterAndEscape: (node, onEnter, onEscape) => {
    // Use keypress instead of keyup in bindEnterAndEscape. Keyup event is fired on enter in IME
    // (Input Method Editor), But keypress is not. So, I changed to use keypress instead of keyup.
    // It is work on Windows (IE8, Chrome 6.0.472), CentOs (Firefox 3.0) and Mac OSX (Firefox
    // 3.6.10, Chrome 6.0.472, Safari 5.0).
    if (onEnter) {
      node.on('keypress', (evt) => {
        if (evt.which === 13) {
          onEnter(evt);
        }
      });
    }

    if (onEscape) {
      node.on('keydown', (evt) => {
        if (evt.which === 27) {
          onEscape(evt);
        }
      });
    }
  },
  timediff: (d) => {
    const pad = require('./pad').pad; // Sidestep circular dependency
    const format = (n, word) => {
      n = Math.round(n);
      return (`${n} ${word}${n !== 1 ? 's' : ''} ago`);
    };
    d = Math.max(0, (+(new Date()) - (+d) - pad.clientTimeOffset) / 1000);
    if (d < 60) {
      return format(d, 'second');
    }
    d /= 60;
    if (d < 60) {
      return format(d, 'minute');
    }
    d /= 60;
    if (d < 24) {
      return format(d, 'hour');
    }
    d /= 24;
    return format(d, 'day');
  },
  makeAnimationScheduler: (funcToAnimateOneStep, stepTime, stepsAtOnce) => {
    if (stepsAtOnce === undefined) {
      stepsAtOnce = 1;
    }

    let animationTimer = null;

    const scheduleAnimation = () => {
      if (!animationTimer) {
        animationTimer = window.setTimeout(() => {
          animationTimer = null;
          let n = stepsAtOnce;
          let moreToDo = true;
          while (moreToDo && n > 0) {
            moreToDo = funcToAnimateOneStep();
            n--;
          }
          if (moreToDo) {
            // more to do
            scheduleAnimation();
          }
        }, stepTime * stepsAtOnce);
      }
    };
    return {scheduleAnimation};
  },
  makeFieldLabeledWhenEmpty: (field, labelText) => {
    field = $(field);

    const clear = () => {
      field.addClass('editempty');
      field.val(labelText);
    };
    field.focus(() => {
      if (field.hasClass('editempty')) {
        field.val('');
      }
      field.removeClass('editempty');
    });
    field.on('blur', () => {
      if (!field.val()) {
        clear();
      }
    });
    return {
      clear,
    };
  },
  getCheckbox: (node) => $(node).is(':checked'),
  setCheckbox: (node, value) => {
    if (value) {
      $(node).attr('checked', 'checked');
    } else {
      $(node).prop('checked', false);
    }
  },
  bindCheckboxChange: (node, func) => {
    $(node).on('change', func);
  },
  encodeUserId: (userId) => userId.replace(/[^a-y0-9]/g, (c) => {
    if (c === '.') return '-';
    return `z${c.charCodeAt(0)}z`;
  }),
  decodeUserId: (encodedUserId) => encodedUserId.replace(/[a-y0-9]+|-|z.+?z/g, (cc) => {
    if (cc === '-') { return '.'; } else if (cc.charAt(0) === 'z') {
      return String.fromCharCode(Number(cc.slice(1, -1)));
    } else {
      return cc;
    }
  }),

  /**
   * Returns whether a string has the expected format to be used as a secret token identifying an
   * author. The format is defined as: 't.' followed by a non-empty base64url string (RFC 4648
   * section 5 with padding).
   *
   * Being strict about what constitutes a valid token enables unambiguous extensibility (e.g.,
   * conditional transformation of a token to a database key in a way that does not allow a
   * malicious user to impersonate another user).
   */
  isValidAuthorToken: (t) => {
    if (typeof t !== 'string' || !t.startsWith('t.')) return false;
    const v = t.slice(2);
    return v.length > 0 && base64url.test(v);
  },

  /**
   * Returns a string that can be used in the `token` cookie as a secret that authenticates a
   * particular author.
   */
  generateAuthorToken: () => `t.${randomString()}`,
};

let globalExceptionHandler = null;
padutils.setupGlobalExceptionHandler = () => {
  if (globalExceptionHandler == null) {
    require('./vendors/gritter');
    globalExceptionHandler = (e) => {
      let type;
      let err;
      let msg, url, linenumber;
      if (e instanceof ErrorEvent) {
        type = 'Uncaught exception';
        err = e.error || {};
        ({message: msg, filename: url, lineno: linenumber} = e);
      } else if (e instanceof PromiseRejectionEvent) {
        type = 'Unhandled Promise rejection';
        err = e.reason || {};
        ({message: msg = 'unknown', fileName: url = 'unknown', lineNumber: linenumber = -1} = err);
      } else {
        throw new Error(`unknown event: ${e.toString()}`);
      }
      if (err.name != null && msg !== err.name && !msg.startsWith(`${err.name}: `)) {
        msg = `${err.name}: ${msg}`;
      }
      const errorId = randomString(20);

      let msgAlreadyVisible = false;
      $('.gritter-item .error-msg').each(function () {
        if ($(this).text() === msg) {
          msgAlreadyVisible = true;
        }
      });

      if (!msgAlreadyVisible) {
        const txt = document.createTextNode.bind(document); // Convenience shorthand.
        const errorMsg = [
          $('<p>')
              .append($('<b>').text('Please press and hold Ctrl and press F5 to reload this page')),
          $('<p>')
              .text('If the problem persists, please send this error message to your webmaster:'),
          $('<div>').css('text-align', 'left').css('font-size', '.8em').css('margin-top', '1em')
              .append($('<b>').addClass('error-msg').text(msg)).append($('<br>'))
              .append(txt(`at ${url} at line ${linenumber}`)).append($('<br>'))
              .append(txt(`ErrorId: ${errorId}`)).append($('<br>'))
              .append(txt(type)).append($('<br>'))
              .append(txt(`URL: ${window.location.href}`)).append($('<br>'))
              .append(txt(`UserAgent: ${navigator.userAgent}`)).append($('<br>')),
        ];

        $.gritter.add({
          title: 'An error occurred',
          text: errorMsg,
          class_name: 'error',
          position: 'bottom',
          sticky: true,
        });
      }

      // send javascript errors to the server
      $.post('../jserror', {
        errorInfo: JSON.stringify({
          errorId,
          type,
          msg,
          url: window.location.href,
          source: url,
          linenumber,
          userAgent: navigator.userAgent,
          stack: err.stack,
        }),
      });
    };
    window.onerror = null; // Clear any pre-existing global error handler.
    window.addEventListener('error', globalExceptionHandler);
    window.addEventListener('unhandledrejection', globalExceptionHandler);
  }
};

padutils.binarySearch = require('./ace2_common').binarySearch;

// https://stackoverflow.com/a/42660748
const inThirdPartyIframe = () => {
  try {
    return (!window.top.location.hostname);
  } catch (e) {
    return true;
  }
};

// This file is included from Node so that it can reuse randomString, but Node doesn't have a global
// window object.
if (typeof window !== 'undefined') {
  exports.Cookies = require('js-cookie/dist/js.cookie').withAttributes({
    // Use `SameSite=Lax`, unless Etherpad is embedded in an iframe from another site in which case
    // use `SameSite=None`. For iframes from another site, only `None` has a chance of working
    // because the cookies are third-party (not same-site). Many browsers/users block third-party
    // cookies, but maybe blocked is better than definitely blocked (which would happen with `Lax`
    // or `Strict`). Note: `None` will not work unless secure is true.
    //
    // `Strict` is not used because it has few security benefits but significant usability drawbacks
    // vs. `Lax`. See https://stackoverflow.com/q/41841880 for discussion.
    sameSite: inThirdPartyIframe() ? 'None' : 'Lax',
    secure: window.location.protocol === 'https:',
  });
}
exports.randomString = randomString;
exports.padutils = padutils;
}}["(module ep_etherpad-lite/static/js/pad_utils.js)"],
"js-cookie/dist/js.cookie.js": {"(module js-cookie/dist/js.cookie.js)": function (require, exports, module) {/*! js-cookie v3.0.5 | MIT */
;
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, (function () {
    var current = global.Cookies;
    var exports = global.Cookies = factory();
    exports.noConflict = function () { global.Cookies = current; return exports; };
  })());
})(this, (function () { 'use strict';

  /* eslint-disable no-var */
  function assign (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        target[key] = source[key];
      }
    }
    return target
  }
  /* eslint-enable no-var */

  /* eslint-disable no-var */
  var defaultConverter = {
    read: function (value) {
      if (value[0] === '"') {
        value = value.slice(1, -1);
      }
      return value.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
    },
    write: function (value) {
      return encodeURIComponent(value).replace(
        /%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,
        decodeURIComponent
      )
    }
  };
  /* eslint-enable no-var */

  /* eslint-disable no-var */

  function init (converter, defaultAttributes) {
    function set (name, value, attributes) {
      if (typeof document === 'undefined') {
        return
      }

      attributes = assign({}, defaultAttributes, attributes);

      if (typeof attributes.expires === 'number') {
        attributes.expires = new Date(Date.now() + attributes.expires * 864e5);
      }
      if (attributes.expires) {
        attributes.expires = attributes.expires.toUTCString();
      }

      name = encodeURIComponent(name)
        .replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent)
        .replace(/[()]/g, escape);

      var stringifiedAttributes = '';
      for (var attributeName in attributes) {
        if (!attributes[attributeName]) {
          continue
        }

        stringifiedAttributes += '; ' + attributeName;

        if (attributes[attributeName] === true) {
          continue
        }

        // Considers RFC 6265 section 5.2:
        // ...
        // 3.  If the remaining unparsed-attributes contains a %x3B (";")
        //     character:
        // Consume the characters of the unparsed-attributes up to,
        // not including, the first %x3B (";") character.
        // ...
        stringifiedAttributes += '=' + attributes[attributeName].split(';')[0];
      }

      return (document.cookie =
        name + '=' + converter.write(value, name) + stringifiedAttributes)
    }

    function get (name) {
      if (typeof document === 'undefined' || (arguments.length && !name)) {
        return
      }

      // To prevent the for loop in the first place assign an empty array
      // in case there are no cookies at all.
      var cookies = document.cookie ? document.cookie.split('; ') : [];
      var jar = {};
      for (var i = 0; i < cookies.length; i++) {
        var parts = cookies[i].split('=');
        var value = parts.slice(1).join('=');

        try {
          var found = decodeURIComponent(parts[0]);
          jar[found] = converter.read(value, found);

          if (name === found) {
            break
          }
        } catch (e) {}
      }

      return name ? jar[name] : jar
    }

    return Object.create(
      {
        set,
        get,
        remove: function (name, attributes) {
          set(
            name,
            '',
            assign({}, attributes, {
              expires: -1
            })
          );
        },
        withAttributes: function (attributes) {
          return init(this.converter, assign({}, this.attributes, attributes))
        },
        withConverter: function (converter) {
          return init(assign({}, this.converter, converter), this.attributes)
        }
      },
      {
        attributes: { value: Object.freeze(defaultAttributes) },
        converter: { value: Object.freeze(converter) }
      }
    )
  }

  var api = init(defaultConverter, { path: '/' });
  /* eslint-enable no-var */

  return api;

}));
}}["(module js-cookie/dist/js.cookie.js)"],
"ep_etherpad-lite/static/js/security.js": {"(module ep_etherpad-lite/static/js/security.js)": function (require, exports, module) {'use strict';

/**
 * Copyright 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS-IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

module.exports = require('security');
}}["(module ep_etherpad-lite/static/js/security.js)"],
"security.js": null,
"ep_etherpad-lite/static/js/ace2_inner": null,
"ep_etherpad-lite/static/js/vendors/browser": null,
"ep_etherpad-lite/static/js/AttributePool": null,
"ep_etherpad-lite/static/js/Changeset": null,
"ep_etherpad-lite/static/js/ChangesetUtils": null,
"ep_etherpad-lite/static/js/skiplist": null,
"ep_etherpad-lite/static/js/colorutils": null,
"ep_etherpad-lite/static/js/undomodule": null,
"unorm/lib/unorm": null,
"ep_etherpad-lite/static/js/contentcollector": null,
"ep_etherpad-lite/static/js/changesettracker": null,
"ep_etherpad-lite/static/js/linestylefilter": null,
"ep_etherpad-lite/static/js/domline": null,
"ep_etherpad-lite/static/js/AttributeManager": null,
"ep_etherpad-lite/static/js/AttributeMap": null,
"ep_etherpad-lite/static/js/attributes": null,
"ep_etherpad-lite/static/js/scroll": null,
"ep_etherpad-lite/static/js/caretPosition": null,
"ep_etherpad-lite/static/js/pad_utils": null,
"js-cookie/dist/js.cookie": null,
"ep_etherpad-lite/static/js/security": null,
"security": null,
"ep_etherpad-lite/static/js/ace2_inner/index.js": null,
"ep_etherpad-lite/static/js/vendors/browser/index.js": null,
"ep_etherpad-lite/static/js/AttributePool/index.js": null,
"ep_etherpad-lite/static/js/Changeset/index.js": null,
"ep_etherpad-lite/static/js/ChangesetUtils/index.js": null,
"ep_etherpad-lite/static/js/skiplist/index.js": null,
"ep_etherpad-lite/static/js/colorutils/index.js": null,
"ep_etherpad-lite/static/js/undomodule/index.js": null,
"unorm/lib/unorm/index.js": null,
"ep_etherpad-lite/static/js/contentcollector/index.js": null,
"ep_etherpad-lite/static/js/changesettracker/index.js": null,
"ep_etherpad-lite/static/js/linestylefilter/index.js": null,
"ep_etherpad-lite/static/js/domline/index.js": null,
"ep_etherpad-lite/static/js/AttributeManager/index.js": null,
"ep_etherpad-lite/static/js/AttributeMap/index.js": null,
"ep_etherpad-lite/static/js/attributes/index.js": null,
"ep_etherpad-lite/static/js/scroll/index.js": null,
"ep_etherpad-lite/static/js/caretPosition/index.js": null,
"ep_etherpad-lite/static/js/pad_utils/index.js": null,
"js-cookie/dist/js.cookie/index.js": null,
"ep_etherpad-lite/static/js/security/index.js": null,
"security/index.js": {"(module security/index.js)": function (require, exports, module) {/*!

  Copyright (c) 2011 Chad Weider

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.

*/

var HTML_ENTITY_MAP = {
  '&': '&amp;'
, '<': '&lt;'
, '>': '&gt;'
, '"': '&quot;'
, "'": '&#x27;'
, '/': '&#x2F;'
};

// OSWASP Guidlines: &, <, >, ", ' plus forward slash.
var HTML_CHARACTERS_EXPRESSION = /[&"'<>\/]/gm;
function escapeHTML(text) {
  return text && text.replace(HTML_CHARACTERS_EXPRESSION, function (c) {
    return HTML_ENTITY_MAP[c] || c;
  });
}

// OSWASP Guidlines: escape all non alphanumeric characters in ASCII space.
var HTML_ATTRIBUTE_CHARACTERS_EXPRESSION =
    /[\x00-\x2F\x3A-\x40\x5B-\x60\x7B-\xFF]/gm;
function escapeHTMLAttribute(text) {
  return text && text.replace(HTML_ATTRIBUTE_CHARACTERS_EXPRESSION, function (c) {
    return HTML_ENTITY_MAP[c] || "&#x" + ('00' + c.charCodeAt(0).toString(16)).slice(-2) + ";";
  });
};

// OSWASP Guidlines: escape all non alphanumeric characters in ASCII space.
// Also include line breaks (for literal).
var JAVASCRIPT_CHARACTERS_EXPRESSION =
    /[\x00-\x2F\x3A-\x40\x5B-\x60\x7B-\xFF\u2028\u2029]/gm;
function encodeJavaScriptIdentifier(text) {
  return text && text.replace(JAVASCRIPT_CHARACTERS_EXPRESSION, function (c) {
    return "\\u" + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
  });
}
function encodeJavaScriptString(text) {
  return text && '"' + encodeJavaScriptIdentifier(text) + '"';
}

// This is not great, but it is useful.
var JSON_STRING_LITERAL_EXPRESSION =
    /"(?:\\.|[^"])*"/gm;
function encodeJavaScriptData(object) {
  return JSON.stringify(object).replace(JSON_STRING_LITERAL_EXPRESSION, function (string) {
    return encodeJavaScriptString(JSON.parse(string));
  });
}


// OSWASP Guidlines: escape all non alphanumeric characters in ASCII space.
var CSS_CHARACTERS_EXPRESSION =
    /[\x00-\x2F\x3A-\x40\x5B-\x60\x7B-\xFF]/gm;
function encodeCSSIdentifier(text) {
  return text && text.replace(CSS_CHARACTERS_EXPRESSION, function (c) {
    return "\\" + ('000000' + c.charCodeAt(0).toString(16)).slice(-6);
  });
}

function encodeCSSString(text) {
  return text && '"' + encodeCSSIdentifier(text) + '"';
}

exports.escapeHTML = escapeHTML;
exports.escapeHTMLAttribute = escapeHTMLAttribute;

exports.encodeJavaScriptIdentifier = encodeJavaScriptIdentifier;
exports.encodeJavaScriptString = encodeJavaScriptString;
exports.encodeJavaScriptData = encodeJavaScriptData;

exports.encodeCSSIdentifier = encodeCSSIdentifier;
exports.encodeCSSString = encodeCSSString;
}}["(module security/index.js)"],
});
