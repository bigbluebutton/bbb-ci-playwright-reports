require.define({"ep_cursortrace/static/js/css.js": {"(module ep_cursortrace/static/js/css.js)": function (require, exports, module) {'use strict';

exports.aceEditorCSS = (hookName, cb) => ['/ep_cursortrace/static/css/cursortrace.css'];
}}["(module ep_cursortrace/static/js/css.js)"],
});
